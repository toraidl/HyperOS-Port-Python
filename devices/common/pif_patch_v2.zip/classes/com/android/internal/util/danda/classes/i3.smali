.class public abstract Lcom/android/internal/util/danda/classes/i3;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lcom/android/internal/util/danda/classes/a5;

.field public static final b:Lcom/android/internal/util/danda/classes/a5;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Lcom/android/internal/util/danda/classes/a5;

    const-wide/16 v1, 0x2

    invoke-static {v1, v2}, Ljava/math/BigInteger;->valueOf(J)Ljava/math/BigInteger;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/a5;-><init>(Ljava/math/BigInteger;)V

    sput-object v0, Lcom/android/internal/util/danda/classes/i3;->a:Lcom/android/internal/util/danda/classes/a5;

    new-instance v0, Lcom/android/internal/util/danda/classes/a5;

    const-wide/16 v1, 0x3

    invoke-static {v1, v2}, Ljava/math/BigInteger;->valueOf(J)Ljava/math/BigInteger;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/a5;-><init>(Ljava/math/BigInteger;)V

    sput-object v0, Lcom/android/internal/util/danda/classes/i3;->b:Lcom/android/internal/util/danda/classes/a5;

    return-void
.end method

.method public static a([I)Lcom/android/internal/util/danda/classes/o3;
    .registers 4

    const/4 v0, 0x0

    aget v0, p0, v0

    if-nez v0, :cond_29

    const/4 v0, 0x1

    :goto_6
    array-length v1, p0

    if-ge v0, v1, :cond_1c

    aget v1, p0, v0

    add-int/lit8 v2, v0, -0x1

    aget v2, p0, v2

    if-le v1, v2, :cond_14

    add-int/lit8 v0, v0, 0x1

    goto :goto_6

    :cond_14
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Polynomial exponents must be montonically increasing"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1c
    new-instance v0, Lcom/android/internal/util/danda/classes/o3;

    new-instance v1, Lcom/android/internal/util/danda/classes/j3;

    invoke-direct {v1, p0}, Lcom/android/internal/util/danda/classes/j3;-><init>([I)V

    sget-object p0, Lcom/android/internal/util/danda/classes/i3;->a:Lcom/android/internal/util/danda/classes/a5;

    invoke-direct {v0, p0, v1}, Lcom/android/internal/util/danda/classes/o3;-><init>(Lcom/android/internal/util/danda/classes/a5;Lcom/android/internal/util/danda/classes/j3;)V

    return-object v0

    :cond_29
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Irreducible polynomials in GF(2) must have constant term"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

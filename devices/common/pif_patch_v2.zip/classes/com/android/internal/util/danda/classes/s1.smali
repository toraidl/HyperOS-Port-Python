.class public final Lcom/android/internal/util/danda/classes/s1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/e;
.implements Lcom/android/internal/util/danda/classes/s3;


# instance fields
.field public final m:Lcom/android/internal/util/danda/classes/y;


# direct methods
.method public constructor <init>(Lcom/android/internal/util/danda/classes/y;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/s1;->m:Lcom/android/internal/util/danda/classes/y;

    return-void
.end method


# virtual methods
.method public final b()Lcom/android/internal/util/danda/classes/t;
    .registers 5

    :try_start_0
    new-instance v0, Lcom/android/internal/util/danda/classes/r1;

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/s1;->m:Lcom/android/internal/util/danda/classes/y;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/y;->c()Lcom/android/internal/util/danda/classes/f;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/r1;-><init>(Lcom/android/internal/util/danda/classes/f;)V
    :try_end_b
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_b} :catch_c

    return-object v0

    :catch_c
    move-exception v0

    new-instance v1, Lcom/android/internal/util/danda/classes/h;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    invoke-direct {v1, v2, v0, v3}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v1
.end method

.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 5

    const-string v0, "unable to get DER object"

    const/4 v1, 0x0

    :try_start_3
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/s1;->b()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_7} :catch_f
    .catch Ljava/lang/IllegalArgumentException; {:try_start_3 .. :try_end_7} :catch_8

    return-object v0

    :catch_8
    move-exception v2

    new-instance v3, Lcom/android/internal/util/danda/classes/s;

    invoke-direct {v3, v0, v2, v1}, Lcom/android/internal/util/danda/classes/s;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v3

    :catch_f
    move-exception v2

    new-instance v3, Lcom/android/internal/util/danda/classes/s;

    invoke-direct {v3, v0, v2, v1}, Lcom/android/internal/util/danda/classes/s;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v3
.end method

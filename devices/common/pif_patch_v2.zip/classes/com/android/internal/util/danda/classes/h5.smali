.class public final Lcom/android/internal/util/danda/classes/h5;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"


# static fields
.field public static final q:Lcom/android/internal/util/danda/classes/d0;

.field public static final r:Lcom/android/internal/util/danda/classes/d0;

.field public static final s:Lcom/android/internal/util/danda/classes/k;

.field public static final t:Lcom/android/internal/util/danda/classes/k;


# instance fields
.field public m:Lcom/android/internal/util/danda/classes/d0;

.field public n:Lcom/android/internal/util/danda/classes/d0;

.field public o:Lcom/android/internal/util/danda/classes/k;

.field public p:Lcom/android/internal/util/danda/classes/k;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Lcom/android/internal/util/danda/classes/d0;

    sget-object v1, Lcom/android/internal/util/danda/classes/j4;->a:Lcom/android/internal/util/danda/classes/o;

    sget-object v2, Lcom/android/internal/util/danda/classes/y1;->m:Lcom/android/internal/util/danda/classes/y1;

    invoke-direct {v0, v1, v2}, Lcom/android/internal/util/danda/classes/d0;-><init>(Lcom/android/internal/util/danda/classes/o;Lcom/android/internal/util/danda/classes/e;)V

    sput-object v0, Lcom/android/internal/util/danda/classes/h5;->q:Lcom/android/internal/util/danda/classes/d0;

    new-instance v1, Lcom/android/internal/util/danda/classes/d0;

    sget-object v2, Lcom/android/internal/util/danda/classes/v4;->f:Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v2, v0}, Lcom/android/internal/util/danda/classes/d0;-><init>(Lcom/android/internal/util/danda/classes/o;Lcom/android/internal/util/danda/classes/e;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/h5;->r:Lcom/android/internal/util/danda/classes/d0;

    new-instance v0, Lcom/android/internal/util/danda/classes/k;

    const-wide/16 v1, 0x14

    invoke-direct {v0, v1, v2}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    sput-object v0, Lcom/android/internal/util/danda/classes/h5;->s:Lcom/android/internal/util/danda/classes/k;

    new-instance v0, Lcom/android/internal/util/danda/classes/k;

    const-wide/16 v1, 0x1

    invoke-direct {v0, v1, v2}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    sput-object v0, Lcom/android/internal/util/danda/classes/h5;->t:Lcom/android/internal/util/danda/classes/k;

    return-void
.end method

.method public static g(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/h5;
    .registers 6

    instance-of v0, p0, Lcom/android/internal/util/danda/classes/h5;

    if-eqz v0, :cond_7

    check-cast p0, Lcom/android/internal/util/danda/classes/h5;

    return-object p0

    :cond_7
    new-instance v0, Lcom/android/internal/util/danda/classes/h5;

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object p0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sget-object v1, Lcom/android/internal/util/danda/classes/h5;->q:Lcom/android/internal/util/danda/classes/d0;

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/h5;->m:Lcom/android/internal/util/danda/classes/d0;

    sget-object v1, Lcom/android/internal/util/danda/classes/h5;->r:Lcom/android/internal/util/danda/classes/d0;

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/h5;->n:Lcom/android/internal/util/danda/classes/d0;

    sget-object v1, Lcom/android/internal/util/danda/classes/h5;->s:Lcom/android/internal/util/danda/classes/k;

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/h5;->o:Lcom/android/internal/util/danda/classes/k;

    sget-object v1, Lcom/android/internal/util/danda/classes/h5;->t:Lcom/android/internal/util/danda/classes/k;

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/h5;->p:Lcom/android/internal/util/danda/classes/k;

    const/4 v1, 0x0

    :goto_21
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result v2

    if-eq v1, v2, :cond_70

    invoke-virtual {p0, v1}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v2

    check-cast v2, Lcom/android/internal/util/danda/classes/a0;

    iget v3, v2, Lcom/android/internal/util/danda/classes/a0;->m:I

    const/4 v4, 0x1

    if-eqz v3, :cond_63

    if-eq v3, v4, :cond_58

    const/4 v4, 0x2

    if-eq v3, v4, :cond_4d

    const/4 v4, 0x3

    if-ne v3, v4, :cond_45

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object v2

    invoke-static {v2}, Lcom/android/internal/util/danda/classes/k;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/k;

    move-result-object v2

    iput-object v2, v0, Lcom/android/internal/util/danda/classes/h5;->p:Lcom/android/internal/util/danda/classes/k;

    goto :goto_6d

    :cond_45
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "unknown tag"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_4d
    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object v2

    invoke-static {v2}, Lcom/android/internal/util/danda/classes/k;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/k;

    move-result-object v2

    iput-object v2, v0, Lcom/android/internal/util/danda/classes/h5;->o:Lcom/android/internal/util/danda/classes/k;

    goto :goto_6d

    :cond_58
    invoke-static {v2, v4}, Lcom/android/internal/util/danda/classes/u;->n(Lcom/android/internal/util/danda/classes/a0;Z)Lcom/android/internal/util/danda/classes/u;

    move-result-object v2

    invoke-static {v2}, Lcom/android/internal/util/danda/classes/d0;->g(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/d0;

    move-result-object v2

    iput-object v2, v0, Lcom/android/internal/util/danda/classes/h5;->n:Lcom/android/internal/util/danda/classes/d0;

    goto :goto_6d

    :cond_63
    invoke-static {v2, v4}, Lcom/android/internal/util/danda/classes/u;->n(Lcom/android/internal/util/danda/classes/a0;Z)Lcom/android/internal/util/danda/classes/u;

    move-result-object v2

    invoke-static {v2}, Lcom/android/internal/util/danda/classes/d0;->g(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/d0;

    move-result-object v2

    iput-object v2, v0, Lcom/android/internal/util/danda/classes/h5;->m:Lcom/android/internal/util/danda/classes/d0;

    :goto_6d
    add-int/lit8 v1, v1, 0x1

    goto :goto_21

    :cond_70
    return-object v0
.end method


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 7

    new-instance v0, Lcom/android/internal/util/danda/classes/f;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/h5;->m:Lcom/android/internal/util/danda/classes/d0;

    sget-object v3, Lcom/android/internal/util/danda/classes/h5;->q:Lcom/android/internal/util/danda/classes/d0;

    invoke-virtual {v2, v3}, Lcom/android/internal/util/danda/classes/m;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v4, 0x1

    if-nez v3, :cond_19

    new-instance v3, Lcom/android/internal/util/danda/classes/g2;

    invoke-direct {v3, v4, v1, v2}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v0, v3}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_19
    iget-object v2, p0, Lcom/android/internal/util/danda/classes/h5;->n:Lcom/android/internal/util/danda/classes/d0;

    sget-object v3, Lcom/android/internal/util/danda/classes/h5;->r:Lcom/android/internal/util/danda/classes/d0;

    invoke-virtual {v2, v3}, Lcom/android/internal/util/danda/classes/m;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2b

    new-instance v3, Lcom/android/internal/util/danda/classes/g2;

    invoke-direct {v3, v4, v4, v2}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v0, v3}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_2b
    iget-object v2, p0, Lcom/android/internal/util/danda/classes/h5;->o:Lcom/android/internal/util/danda/classes/k;

    sget-object v3, Lcom/android/internal/util/danda/classes/h5;->s:Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v2, v3}, Lcom/android/internal/util/danda/classes/t;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_3e

    new-instance v3, Lcom/android/internal/util/danda/classes/g2;

    const/4 v5, 0x2

    invoke-direct {v3, v4, v5, v2}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v0, v3}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_3e
    iget-object v2, p0, Lcom/android/internal/util/danda/classes/h5;->p:Lcom/android/internal/util/danda/classes/k;

    sget-object v3, Lcom/android/internal/util/danda/classes/h5;->t:Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v2, v3}, Lcom/android/internal/util/danda/classes/t;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_51

    new-instance v3, Lcom/android/internal/util/danda/classes/g2;

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5, v2}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v0, v3}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_51
    new-instance v2, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v2, v1, v0}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    return-object v2
.end method

.class public final Lcom/android/internal/util/danda/classes/e5;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"


# instance fields
.field public m:Lcom/android/internal/util/danda/classes/w;


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/e5;->m:Lcom/android/internal/util/danda/classes/w;

    return-object v0
.end method

.method public final g()Lcom/android/internal/util/danda/classes/k0;
    .registers 3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/e5;->m:Lcom/android/internal/util/danda/classes/w;

    iget-object v1, v0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v1}, Ljava/util/Vector;->size()I

    move-result v1

    if-nez v1, :cond_c

    const/4 v0, 0x0

    return-object v0

    :cond_c
    iget-object v0, v0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/internal/util/danda/classes/e;

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/k0;->g(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/k0;

    move-result-object v0

    return-object v0
.end method

.method public final h()[Lcom/android/internal/util/danda/classes/k0;
    .registers 6

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/e5;->m:Lcom/android/internal/util/danda/classes/w;

    iget-object v1, v0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v1}, Ljava/util/Vector;->size()I

    move-result v1

    new-array v2, v1, [Lcom/android/internal/util/danda/classes/k0;

    const/4 v3, 0x0

    :goto_b
    if-eq v3, v1, :cond_1e

    iget-object v4, v0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v4, v3}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/internal/util/danda/classes/e;

    invoke-static {v4}, Lcom/android/internal/util/danda/classes/k0;->g(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/k0;

    move-result-object v4

    aput-object v4, v2, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_b

    :cond_1e
    return-object v2
.end method

.method public final i()Z
    .registers 3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/e5;->m:Lcom/android/internal/util/danda/classes/w;

    iget-object v0, v0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    const/4 v1, 0x1

    if-le v0, v1, :cond_c

    goto :goto_d

    :cond_c
    const/4 v1, 0x0

    :goto_d
    return v1
.end method

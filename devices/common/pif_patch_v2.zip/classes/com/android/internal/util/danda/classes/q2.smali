.class public final Lcom/android/internal/util/danda/classes/q2;
.super Lcom/android/internal/util/danda/classes/e4;
.source "SourceFile"


# static fields
.field public static final e:[B


# instance fields
.field public final c:I

.field public d:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/4 v0, 0x0

    new-array v0, v0, [B

    sput-object v0, Lcom/android/internal/util/danda/classes/q2;->e:[B

    return-void
.end method

.method public constructor <init>(ILjava/io/InputStream;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/android/internal/util/danda/classes/e4;-><init>(ILjava/io/InputStream;)V

    if-ltz p1, :cond_f

    iput p1, p0, Lcom/android/internal/util/danda/classes/q2;->c:I

    iput p1, p0, Lcom/android/internal/util/danda/classes/q2;->d:I

    if-nez p1, :cond_e

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/e4;->b()V

    :cond_e
    return-void

    :cond_f
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "negative lengths not allowed"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method public final a()I
    .registers 2

    iget v0, p0, Lcom/android/internal/util/danda/classes/q2;->d:I

    return v0
.end method

.method public final c()[B
    .registers 4

    iget v0, p0, Lcom/android/internal/util/danda/classes/q2;->d:I

    if-nez v0, :cond_7

    sget-object v0, Lcom/android/internal/util/danda/classes/q2;->e:[B

    return-object v0

    :cond_7
    new-array v1, v0, [B

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/e4;->a:Ljava/io/InputStream;

    invoke-static {v2, v1}, Lcom/android/internal/util/danda/classes/c0;->o(Ljava/io/InputStream;[B)I

    move-result v2

    sub-int/2addr v0, v2

    iput v0, p0, Lcom/android/internal/util/danda/classes/q2;->d:I

    if-nez v0, :cond_18

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/e4;->b()V

    return-object v1

    :cond_18
    new-instance v0, Ljava/io/EOFException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "DEF length "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v2, p0, Lcom/android/internal/util/danda/classes/q2;->c:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " object truncated by "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lcom/android/internal/util/danda/classes/q2;->d:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final read()I
    .registers 4

    iget v0, p0, Lcom/android/internal/util/danda/classes/q2;->d:I

    if-nez v0, :cond_6

    const/4 v0, -0x1

    return v0

    :cond_6
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/e4;->a:Ljava/io/InputStream;

    .line 1
    invoke-virtual {v0}, Ljava/io/InputStream;->read()I

    move-result v0

    if-ltz v0, :cond_1a

    iget v1, p0, Lcom/android/internal/util/danda/classes/q2;->d:I

    add-int/lit8 v1, v1, -0x1

    iput v1, p0, Lcom/android/internal/util/danda/classes/q2;->d:I

    if-nez v1, :cond_19

    .line 2
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/e4;->b()V

    :cond_19
    return v0

    .line 3
    :cond_1a
    new-instance v0, Ljava/io/EOFException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "DEF length "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v2, p0, Lcom/android/internal/util/danda/classes/q2;->c:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " object truncated by "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lcom/android/internal/util/danda/classes/q2;->d:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final read([BII)I
    .registers 5

    iget v0, p0, Lcom/android/internal/util/danda/classes/q2;->d:I

    if-nez v0, :cond_6

    const/4 p1, -0x1

    return p1

    .line 4
    :cond_6
    invoke-static {p3, v0}, Ljava/lang/Math;->min(II)I

    move-result p3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/e4;->a:Ljava/io/InputStream;

    .line 5
    invoke-virtual {v0, p1, p2, p3}, Ljava/io/InputStream;->read([BII)I

    move-result p1

    if-ltz p1, :cond_1d

    iget p2, p0, Lcom/android/internal/util/danda/classes/q2;->d:I

    sub-int/2addr p2, p1

    iput p2, p0, Lcom/android/internal/util/danda/classes/q2;->d:I

    if-nez p2, :cond_1c

    .line 6
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/e4;->b()V

    :cond_1c
    return p1

    .line 7
    :cond_1d
    new-instance p1, Ljava/io/EOFException;

    new-instance p2, Ljava/lang/StringBuilder;

    const-string p3, "DEF length "

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget p3, p0, Lcom/android/internal/util/danda/classes/q2;->c:I

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p3, " object truncated by "

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p3, p0, Lcom/android/internal/util/danda/classes/q2;->d:I

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.class public final Lcom/android/internal/util/danda/classes/l4;
.super Ljava/lang/Exception;
.source "SourceFile"


# instance fields
.field public a:Ljava/lang/Throwable;


# virtual methods
.method public final getCause()Ljava/lang/Throwable;
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/l4;->a:Ljava/lang/Throwable;

    return-object v0
.end method

.class public final Lcom/android/internal/util/danda/classes/b5;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"


# instance fields
.field public m:Lcom/android/internal/util/danda/classes/p;

.field public n:Lcom/android/internal/util/danda/classes/d0;

.field public o:Lcom/android/internal/util/danda/classes/w;


# direct methods
.method public constructor <init>(Lcom/android/internal/util/danda/classes/d0;Lcom/android/internal/util/danda/classes/m;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lcom/android/internal/util/danda/classes/a2;

    invoke-interface {p2}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object p2

    const-string v1, "DER"

    invoke-virtual {p2, v1}, Lcom/android/internal/util/danda/classes/m;->f(Ljava/lang/String;)[B

    move-result-object p2

    invoke-direct {v0, p2}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/b5;->m:Lcom/android/internal/util/danda/classes/p;

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/b5;->n:Lcom/android/internal/util/danda/classes/d0;

    const/4 p1, 0x0

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/b5;->o:Lcom/android/internal/util/danda/classes/w;

    return-void
.end method

.method public static g(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/b5;
    .registers 3

    instance-of v0, p0, Lcom/android/internal/util/danda/classes/b5;

    if-eqz v0, :cond_7

    check-cast p0, Lcom/android/internal/util/danda/classes/b5;

    return-object p0

    :cond_7
    if-eqz p0, :cond_55

    new-instance v0, Lcom/android/internal/util/danda/classes/b5;

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object p0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/u;->q()Ljava/util/Enumeration;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v1

    invoke-virtual {v1}, Ljava/math/BigInteger;->intValue()I

    move-result v1

    if-nez v1, :cond_4d

    invoke-interface {p0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/d0;->g(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/d0;

    move-result-object v1

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/b5;->n:Lcom/android/internal/util/danda/classes/d0;

    invoke-interface {p0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/p;->n(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/p;

    move-result-object v1

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/b5;->m:Lcom/android/internal/util/danda/classes/p;

    invoke-interface {p0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v1

    if-eqz v1, :cond_4c

    invoke-interface {p0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/android/internal/util/danda/classes/a0;

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/w;->n(Lcom/android/internal/util/danda/classes/a0;)Lcom/android/internal/util/danda/classes/w;

    move-result-object p0

    iput-object p0, v0, Lcom/android/internal/util/danda/classes/b5;->o:Lcom/android/internal/util/danda/classes/w;

    :cond_4c
    return-object v0

    :cond_4d
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "wrong version for private key info"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_55
    const/4 p0, 0x0

    return-object p0
.end method


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 6

    new-instance v0, Lcom/android/internal/util/danda/classes/f;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    new-instance v2, Lcom/android/internal/util/danda/classes/k;

    const-wide/16 v3, 0x0

    invoke-direct {v2, v3, v4}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/b5;->n:Lcom/android/internal/util/danda/classes/d0;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/b5;->m:Lcom/android/internal/util/danda/classes/p;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/b5;->o:Lcom/android/internal/util/danda/classes/w;

    if-eqz v2, :cond_26

    new-instance v3, Lcom/android/internal/util/danda/classes/g2;

    invoke-direct {v3, v1, v1, v2}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v0, v3}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_26
    new-instance v2, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v2, v1, v0}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    return-object v2
.end method

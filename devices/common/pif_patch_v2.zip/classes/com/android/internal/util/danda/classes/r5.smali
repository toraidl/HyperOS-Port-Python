.class public final Lcom/android/internal/util/danda/classes/r5;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"


# instance fields
.field public m:Lcom/android/internal/util/danda/classes/k;

.field public n:Lcom/android/internal/util/danda/classes/d0;

.field public o:Lcom/android/internal/util/danda/classes/x5;

.field public p:Lcom/android/internal/util/danda/classes/u5;

.field public q:Lcom/android/internal/util/danda/classes/u5;

.field public r:Lcom/android/internal/util/danda/classes/u;

.field public s:Lcom/android/internal/util/danda/classes/g3;


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 6

    new-instance v0, Lcom/android/internal/util/danda/classes/f;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/r5;->m:Lcom/android/internal/util/danda/classes/k;

    if-eqz v2, :cond_d

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_d
    iget-object v2, p0, Lcom/android/internal/util/danda/classes/r5;->n:Lcom/android/internal/util/danda/classes/d0;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/r5;->o:Lcom/android/internal/util/danda/classes/x5;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/r5;->p:Lcom/android/internal/util/danda/classes/u5;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/r5;->q:Lcom/android/internal/util/danda/classes/u5;

    if-eqz v2, :cond_23

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_23
    iget-object v2, p0, Lcom/android/internal/util/danda/classes/r5;->r:Lcom/android/internal/util/danda/classes/u;

    if-eqz v2, :cond_2a

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_2a
    iget-object v2, p0, Lcom/android/internal/util/danda/classes/r5;->s:Lcom/android/internal/util/danda/classes/g3;

    if-eqz v2, :cond_37

    new-instance v3, Lcom/android/internal/util/danda/classes/g2;

    const/4 v4, 0x1

    invoke-direct {v3, v4, v1, v2}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v0, v3}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_37
    new-instance v2, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v2, v1, v0}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    return-object v2
.end method

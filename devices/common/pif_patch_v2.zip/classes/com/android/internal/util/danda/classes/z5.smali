.class public final Lcom/android/internal/util/danda/classes/z5;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public b:I

.field public final c:C

.field public final d:Ljava/lang/StringBuffer;


# direct methods
.method public constructor <init>(Ljava/lang/String;C)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/z5;->d:Ljava/lang/StringBuffer;

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/z5;->a:Ljava/lang/String;

    const/4 p1, -0x1

    iput p1, p0, Lcom/android/internal/util/danda/classes/z5;->b:I

    iput-char p2, p0, Lcom/android/internal/util/danda/classes/z5;->c:C

    return-void
.end method


# virtual methods
.method public final a()Z
    .registers 3

    iget v0, p0, Lcom/android/internal/util/danda/classes/z5;->b:I

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/z5;->a:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    if-eq v0, v1, :cond_c

    const/4 v0, 0x1

    goto :goto_d

    :cond_c
    const/4 v0, 0x0

    :goto_d
    return v0
.end method

.method public final b()Ljava/lang/String;
    .registers 10

    iget v0, p0, Lcom/android/internal/util/danda/classes/z5;->b:I

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/z5;->a:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-ne v0, v2, :cond_c

    const/4 v0, 0x0

    return-object v0

    :cond_c
    iget v0, p0, Lcom/android/internal/util/danda/classes/z5;->b:I

    const/4 v2, 0x1

    add-int/2addr v0, v2

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/z5;->d:Ljava/lang/StringBuffer;

    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->setLength(I)V

    move v5, v4

    move v6, v5

    :goto_18
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v7

    if-eq v0, v7, :cond_4d

    invoke-virtual {v1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v7

    const/16 v8, 0x22

    if-ne v7, v8, :cond_2f

    if-nez v5, :cond_2a

    xor-int/lit8 v6, v6, 0x1

    :cond_2a
    invoke-virtual {v3, v7}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    :goto_2d
    move v5, v4

    goto :goto_4a

    :cond_2f
    if-nez v5, :cond_46

    if-eqz v6, :cond_34

    goto :goto_46

    :cond_34
    const/16 v8, 0x5c

    if-ne v7, v8, :cond_3d

    invoke-virtual {v3, v7}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    move v5, v2

    goto :goto_4a

    :cond_3d
    iget-char v8, p0, Lcom/android/internal/util/danda/classes/z5;->c:C

    if-ne v7, v8, :cond_42

    goto :goto_4d

    :cond_42
    invoke-virtual {v3, v7}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    goto :goto_4a

    :cond_46
    :goto_46
    invoke-virtual {v3, v7}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    goto :goto_2d

    :goto_4a
    add-int/lit8 v0, v0, 0x1

    goto :goto_18

    :cond_4d
    :goto_4d
    iput v0, p0, Lcom/android/internal/util/danda/classes/z5;->b:I

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.class public final Lcom/android/internal/util/danda/classes/b2;
.super Lcom/android/internal/util/danda/classes/f;
.source "SourceFile"


# instance fields
.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(Ljava/io/OutputStream;I)V
    .registers 3

    iput p2, p0, Lcom/android/internal/util/danda/classes/b2;->b:I

    invoke-direct {p0, p1}, Lcom/android/internal/util/danda/classes/f;-><init>(Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/b2;
    .registers 2

    iget v0, p0, Lcom/android/internal/util/danda/classes/b2;->b:I

    packed-switch v0, :pswitch_data_c

    invoke-super {p0}, Lcom/android/internal/util/danda/classes/f;->d()Lcom/android/internal/util/danda/classes/b2;

    move-result-object v0

    return-object v0

    :pswitch_a
    return-object p0

    nop

    :pswitch_data_c
    .packed-switch 0x0
        :pswitch_a
    .end packed-switch
.end method

.method public final e()Lcom/android/internal/util/danda/classes/b2;
    .registers 2

    iget v0, p0, Lcom/android/internal/util/danda/classes/b2;->b:I

    packed-switch v0, :pswitch_data_c

    invoke-super {p0}, Lcom/android/internal/util/danda/classes/f;->e()Lcom/android/internal/util/danda/classes/b2;

    move-result-object v0

    return-object v0

    :pswitch_a
    return-object p0

    nop

    :pswitch_data_c
    .packed-switch 0x0
        :pswitch_a
    .end packed-switch
.end method

.method public final k(Lcom/android/internal/util/danda/classes/e;)V
    .registers 4

    iget v0, p0, Lcom/android/internal/util/danda/classes/b2;->b:I

    const-string v1, "null object detected"

    packed-switch v0, :pswitch_data_30

    if-eqz p1, :cond_15

    invoke-interface {p1}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object p1

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/t;->m()Lcom/android/internal/util/danda/classes/t;

    move-result-object p1

    invoke-virtual {p1, p0}, Lcom/android/internal/util/danda/classes/t;->h(Lcom/android/internal/util/danda/classes/f;)V

    return-void

    :cond_15
    new-instance p1, Ljava/io/IOException;

    invoke-direct {p1, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :pswitch_1b
    if-eqz p1, :cond_29

    invoke-interface {p1}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object p1

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/t;->l()Lcom/android/internal/util/danda/classes/t;

    move-result-object p1

    invoke-virtual {p1, p0}, Lcom/android/internal/util/danda/classes/t;->h(Lcom/android/internal/util/danda/classes/f;)V

    return-void

    :cond_29
    new-instance p1, Ljava/io/IOException;

    invoke-direct {p1, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :pswitch_data_30
    .packed-switch 0x0
        :pswitch_1b
    .end packed-switch
.end method

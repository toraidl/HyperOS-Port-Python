.class public final Lcom/android/internal/util/danda/classes/y;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/io/InputStream;

.field public final b:I

.field public final c:[[B


# direct methods
.method public constructor <init>(ILcom/android/internal/util/danda/classes/e4;)V
    .registers 3

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lcom/android/internal/util/danda/classes/y;->a:Ljava/io/InputStream;

    iput p1, p0, Lcom/android/internal/util/danda/classes/y;->b:I

    const/16 p1, 0xb

    new-array p1, p1, [[B

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/y;->c:[[B

    return-void
.end method

.method public constructor <init>(Lcom/android/internal/util/danda/classes/q2;)V
    .registers 3

    .line 1
    invoke-static {p1}, Lcom/android/internal/util/danda/classes/n5;->c(Ljava/io/InputStream;)I

    move-result v0

    invoke-direct {p0, v0, p1}, Lcom/android/internal/util/danda/classes/y;-><init>(ILcom/android/internal/util/danda/classes/e4;)V

    return-void
.end method


# virtual methods
.method public final a()Lcom/android/internal/util/danda/classes/e;
    .registers 13

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y;->a:Ljava/io/InputStream;

    invoke-virtual {v0}, Ljava/io/InputStream;->read()I

    move-result v1

    const/4 v2, -0x1

    if-ne v1, v2, :cond_b

    const/4 v0, 0x0

    return-object v0

    :cond_b
    instance-of v2, v0, Lcom/android/internal/util/danda/classes/t3;

    const/4 v3, 0x0

    if-eqz v2, :cond_18

    move-object v2, v0

    check-cast v2, Lcom/android/internal/util/danda/classes/t3;

    iput-boolean v3, v2, Lcom/android/internal/util/danda/classes/t3;->f:Z

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/t3;->c()Z

    :cond_18
    invoke-static {v1, v0}, Lcom/android/internal/util/danda/classes/j;->g(ILjava/io/InputStream;)I

    move-result v2

    and-int/lit8 v4, v1, 0x20

    const/4 v5, 0x1

    if-eqz v4, :cond_23

    move v4, v5

    goto :goto_24

    :cond_23
    move v4, v3

    :goto_24
    iget v6, p0, Lcom/android/internal/util/danda/classes/y;->b:I

    invoke-static {v6, v0}, Lcom/android/internal/util/danda/classes/j;->e(ILjava/io/InputStream;)I

    move-result v7

    const/16 v8, 0x11

    const/16 v9, 0x10

    const/16 v10, 0x8

    const/4 v11, 0x4

    if-gez v7, :cond_93

    if-eqz v4, :cond_8b

    new-instance v4, Lcom/android/internal/util/danda/classes/t3;

    invoke-direct {v4, v6, v0}, Lcom/android/internal/util/danda/classes/t3;-><init>(ILjava/io/InputStream;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/y;

    invoke-direct {v0, v6, v4}, Lcom/android/internal/util/danda/classes/y;-><init>(ILcom/android/internal/util/danda/classes/e4;)V

    and-int/lit8 v4, v1, 0x40

    if-eqz v4, :cond_49

    new-instance v1, Lcom/android/internal/util/danda/classes/p0;

    invoke-direct {v1, v2, v0}, Lcom/android/internal/util/danda/classes/p0;-><init>(ILcom/android/internal/util/danda/classes/y;)V

    return-object v1

    :cond_49
    and-int/lit16 v1, v1, 0x80

    if-eqz v1, :cond_53

    new-instance v1, Lcom/android/internal/util/danda/classes/z0;

    invoke-direct {v1, v5, v2, v0}, Lcom/android/internal/util/danda/classes/z0;-><init>(ZILcom/android/internal/util/danda/classes/y;)V

    return-object v1

    :cond_53
    if-eq v2, v11, :cond_85

    if-eq v2, v10, :cond_7f

    if-eq v2, v9, :cond_79

    if-ne v2, v8, :cond_61

    new-instance v1, Lcom/android/internal/util/danda/classes/x0;

    invoke-direct {v1, v3, v0}, Lcom/android/internal/util/danda/classes/x0;-><init>(ILcom/android/internal/util/danda/classes/y;)V

    goto :goto_8a

    :cond_61
    new-instance v0, Lcom/android/internal/util/danda/classes/h;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v4, "unknown BER object encountered: 0x"

    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, v3}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;I)V

    throw v0

    :cond_79
    new-instance v1, Lcom/android/internal/util/danda/classes/v0;

    invoke-direct {v1, v3, v0}, Lcom/android/internal/util/danda/classes/v0;-><init>(ILcom/android/internal/util/danda/classes/y;)V

    goto :goto_8a

    :cond_7f
    new-instance v1, Lcom/android/internal/util/danda/classes/s1;

    invoke-direct {v1, v0}, Lcom/android/internal/util/danda/classes/s1;-><init>(Lcom/android/internal/util/danda/classes/y;)V

    goto :goto_8a

    :cond_85
    new-instance v1, Lcom/android/internal/util/danda/classes/t0;

    invoke-direct {v1, v0, v3}, Lcom/android/internal/util/danda/classes/t0;-><init>(Ljava/lang/Object;I)V

    :goto_8a
    return-object v1

    :cond_8b
    new-instance v0, Ljava/io/IOException;

    const-string v1, "indefinite-length primitive encoding encountered"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_93
    new-instance v6, Lcom/android/internal/util/danda/classes/q2;

    invoke-direct {v6, v7, v0}, Lcom/android/internal/util/danda/classes/q2;-><init>(ILjava/io/InputStream;)V

    and-int/lit8 v0, v1, 0x40

    if-eqz v0, :cond_a6

    new-instance v0, Lcom/android/internal/util/danda/classes/o0;

    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object v1

    invoke-direct {v0, v4, v2, v1}, Lcom/android/internal/util/danda/classes/o0;-><init>(ZI[B)V

    return-object v0

    :cond_a6
    and-int/lit16 v0, v1, 0x80

    if-eqz v0, :cond_b5

    new-instance v0, Lcom/android/internal/util/danda/classes/z0;

    new-instance v1, Lcom/android/internal/util/danda/classes/y;

    invoke-direct {v1, v6}, Lcom/android/internal/util/danda/classes/y;-><init>(Lcom/android/internal/util/danda/classes/q2;)V

    invoke-direct {v0, v4, v2, v1}, Lcom/android/internal/util/danda/classes/z0;-><init>(ZILcom/android/internal/util/danda/classes/y;)V

    return-object v0

    :cond_b5
    if-eqz v4, :cond_104

    if-eq v2, v11, :cond_f9

    if-eq v2, v10, :cond_ee

    if-eq v2, v9, :cond_e3

    if-ne v2, v8, :cond_ca

    new-instance v0, Lcom/android/internal/util/danda/classes/x0;

    new-instance v1, Lcom/android/internal/util/danda/classes/y;

    invoke-direct {v1, v6}, Lcom/android/internal/util/danda/classes/y;-><init>(Lcom/android/internal/util/danda/classes/q2;)V

    invoke-direct {v0, v5, v1}, Lcom/android/internal/util/danda/classes/x0;-><init>(ILcom/android/internal/util/danda/classes/y;)V

    return-object v0

    :cond_ca
    new-instance v0, Ljava/io/IOException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "unknown tag "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " encountered"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_e3
    new-instance v0, Lcom/android/internal/util/danda/classes/v0;

    new-instance v1, Lcom/android/internal/util/danda/classes/y;

    invoke-direct {v1, v6}, Lcom/android/internal/util/danda/classes/y;-><init>(Lcom/android/internal/util/danda/classes/q2;)V

    invoke-direct {v0, v5, v1}, Lcom/android/internal/util/danda/classes/v0;-><init>(ILcom/android/internal/util/danda/classes/y;)V

    return-object v0

    :cond_ee
    new-instance v0, Lcom/android/internal/util/danda/classes/s1;

    new-instance v1, Lcom/android/internal/util/danda/classes/y;

    invoke-direct {v1, v6}, Lcom/android/internal/util/danda/classes/y;-><init>(Lcom/android/internal/util/danda/classes/q2;)V

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/s1;-><init>(Lcom/android/internal/util/danda/classes/y;)V

    return-object v0

    :cond_f9
    new-instance v0, Lcom/android/internal/util/danda/classes/t0;

    new-instance v1, Lcom/android/internal/util/danda/classes/y;

    invoke-direct {v1, v6}, Lcom/android/internal/util/danda/classes/y;-><init>(Lcom/android/internal/util/danda/classes/q2;)V

    invoke-direct {v0, v1, v3}, Lcom/android/internal/util/danda/classes/t0;-><init>(Ljava/lang/Object;I)V

    return-object v0

    :cond_104
    if-eq v2, v11, :cond_116

    :try_start_106
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y;->c:[[B

    invoke-static {v2, v6, v0}, Lcom/android/internal/util/danda/classes/j;->c(ILcom/android/internal/util/danda/classes/q2;[[B)Lcom/android/internal/util/danda/classes/t;

    move-result-object v0
    :try_end_10c
    .catch Ljava/lang/IllegalArgumentException; {:try_start_106 .. :try_end_10c} :catch_10d

    return-object v0

    :catch_10d
    move-exception v0

    new-instance v1, Lcom/android/internal/util/danda/classes/h;

    const-string v2, "corrupted stream detected"

    invoke-direct {v1, v2, v0, v3}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v1

    :cond_116
    new-instance v0, Lcom/android/internal/util/danda/classes/t0;

    invoke-direct {v0, v6, v5}, Lcom/android/internal/util/danda/classes/t0;-><init>(Ljava/lang/Object;I)V

    return-object v0
.end method

.method public final b(ZI)Lcom/android/internal/util/danda/classes/a0;
    .registers 7

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y;->a:Ljava/io/InputStream;

    const/4 v1, 0x0

    if-nez p1, :cond_16

    check-cast v0, Lcom/android/internal/util/danda/classes/q2;

    new-instance p1, Lcom/android/internal/util/danda/classes/g2;

    new-instance v2, Lcom/android/internal/util/danda/classes/a2;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/q2;->c()[B

    move-result-object v0

    invoke-direct {v2, v0}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    invoke-direct {p1, v1, p2, v2}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    return-object p1

    :cond_16
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/y;->c()Lcom/android/internal/util/danda/classes/f;

    move-result-object p1

    instance-of v0, v0, Lcom/android/internal/util/danda/classes/t3;

    const/4 v2, 0x1

    if-eqz v0, :cond_46

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/f;->f()I

    move-result v0

    if-ne v0, v2, :cond_2f

    new-instance v0, Lcom/android/internal/util/danda/classes/y0;

    invoke-virtual {p1, v1}, Lcom/android/internal/util/danda/classes/f;->b(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object p1

    invoke-direct {v0, v2, p2, p1}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    goto :goto_45

    :cond_2f
    new-instance v0, Lcom/android/internal/util/danda/classes/y0;

    sget-object v3, Lcom/android/internal/util/danda/classes/q0;->a:Lcom/android/internal/util/danda/classes/u0;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/f;->f()I

    move-result v3

    if-ge v3, v2, :cond_3c

    sget-object p1, Lcom/android/internal/util/danda/classes/q0;->a:Lcom/android/internal/util/danda/classes/u0;

    goto :goto_42

    :cond_3c
    new-instance v2, Lcom/android/internal/util/danda/classes/u0;

    invoke-direct {v2, p1}, Lcom/android/internal/util/danda/classes/u;-><init>(Lcom/android/internal/util/danda/classes/f;)V

    move-object p1, v2

    :goto_42
    invoke-direct {v0, v1, p2, p1}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    :goto_45
    return-object v0

    :cond_46
    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/f;->f()I

    move-result v0

    if-ne v0, v2, :cond_56

    new-instance v0, Lcom/android/internal/util/danda/classes/g2;

    invoke-virtual {p1, v1}, Lcom/android/internal/util/danda/classes/f;->b(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object p1

    invoke-direct {v0, v2, p2, p1}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    goto :goto_6c

    :cond_56
    new-instance v0, Lcom/android/internal/util/danda/classes/g2;

    sget-object v3, Lcom/android/internal/util/danda/classes/t1;->a:Lcom/android/internal/util/danda/classes/d2;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/f;->f()I

    move-result v3

    if-ge v3, v2, :cond_63

    sget-object p1, Lcom/android/internal/util/danda/classes/t1;->a:Lcom/android/internal/util/danda/classes/d2;

    goto :goto_69

    :cond_63
    new-instance v3, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v3, v2, p1}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    move-object p1, v3

    :goto_69
    invoke-direct {v0, v1, p2, p1}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    :goto_6c
    return-object v0
.end method

.method public final c()Lcom/android/internal/util/danda/classes/f;
    .registers 4

    new-instance v0, Lcom/android/internal/util/danda/classes/f;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    :goto_6
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/y;->a()Lcom/android/internal/util/danda/classes/e;

    move-result-object v1

    if-eqz v1, :cond_22

    instance-of v2, v1, Lcom/android/internal/util/danda/classes/s3;

    if-eqz v2, :cond_1a

    check-cast v1, Lcom/android/internal/util/danda/classes/s3;

    invoke-interface {v1}, Lcom/android/internal/util/danda/classes/s3;->b()Lcom/android/internal/util/danda/classes/t;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    goto :goto_6

    :cond_1a
    invoke-interface {v1}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    goto :goto_6

    :cond_22
    return-object v0
.end method

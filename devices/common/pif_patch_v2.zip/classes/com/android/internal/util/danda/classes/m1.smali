.class public final Lcom/android/internal/util/danda/classes/m1;
.super Ljava/io/InputStream;
.source "SourceFile"


# instance fields
.field public final a:Lcom/android/internal/util/danda/classes/y;

.field public b:Z

.field public c:Ljava/io/InputStream;


# direct methods
.method public constructor <init>(Lcom/android/internal/util/danda/classes/y;)V
    .registers 3

    invoke-direct {p0}, Ljava/io/InputStream;-><init>()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/android/internal/util/danda/classes/m1;->b:Z

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/m1;->a:Lcom/android/internal/util/danda/classes/y;

    return-void
.end method


# virtual methods
.method public final read()I
    .registers 5

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/m1;->c:Ljava/io/InputStream;

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/m1;->a:Lcom/android/internal/util/danda/classes/y;

    const/4 v2, -0x1

    if-nez v0, :cond_1e

    iget-boolean v0, p0, Lcom/android/internal/util/danda/classes/m1;->b:Z

    if-nez v0, :cond_c

    return v2

    .line 6
    :cond_c
    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/y;->a()Lcom/android/internal/util/danda/classes/e;

    move-result-object v0

    check-cast v0, Lcom/android/internal/util/danda/classes/q;

    if-nez v0, :cond_15

    return v2

    :cond_15
    const/4 v3, 0x0

    iput-boolean v3, p0, Lcom/android/internal/util/danda/classes/m1;->b:Z

    .line 7
    invoke-interface {v0}, Lcom/android/internal/util/danda/classes/q;->c()Ljava/io/InputStream;

    move-result-object v0

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/m1;->c:Ljava/io/InputStream;

    :cond_1e
    :goto_1e
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/m1;->c:Ljava/io/InputStream;

    .line 8
    invoke-virtual {v0}, Ljava/io/InputStream;->read()I

    move-result v0

    if-ltz v0, :cond_27

    return v0

    .line 9
    :cond_27
    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/y;->a()Lcom/android/internal/util/danda/classes/e;

    move-result-object v0

    check-cast v0, Lcom/android/internal/util/danda/classes/q;

    if-nez v0, :cond_33

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/m1;->c:Ljava/io/InputStream;

    return v2

    .line 10
    :cond_33
    invoke-interface {v0}, Lcom/android/internal/util/danda/classes/q;->c()Ljava/io/InputStream;

    move-result-object v0

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/m1;->c:Ljava/io/InputStream;

    goto :goto_1e
.end method

.method public final read([BII)I
    .registers 10

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/m1;->c:Ljava/io/InputStream;

    const/4 v1, 0x0

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/m1;->a:Lcom/android/internal/util/danda/classes/y;

    const/4 v3, -0x1

    if-nez v0, :cond_1e

    iget-boolean v0, p0, Lcom/android/internal/util/danda/classes/m1;->b:Z

    if-nez v0, :cond_d

    return v3

    .line 1
    :cond_d
    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/y;->a()Lcom/android/internal/util/danda/classes/e;

    move-result-object v0

    check-cast v0, Lcom/android/internal/util/danda/classes/q;

    if-nez v0, :cond_16

    return v3

    :cond_16
    iput-boolean v1, p0, Lcom/android/internal/util/danda/classes/m1;->b:Z

    .line 2
    invoke-interface {v0}, Lcom/android/internal/util/danda/classes/q;->c()Ljava/io/InputStream;

    move-result-object v0

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/m1;->c:Ljava/io/InputStream;

    :cond_1e
    :goto_1e
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/m1;->c:Ljava/io/InputStream;

    add-int v4, p2, v1

    sub-int v5, p3, v1

    .line 3
    invoke-virtual {v0, p1, v4, v5}, Ljava/io/InputStream;->read([BII)I

    move-result v0

    if-ltz v0, :cond_2e

    add-int/2addr v1, v0

    if-ne v1, p3, :cond_1e

    return v1

    .line 4
    :cond_2e
    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/y;->a()Lcom/android/internal/util/danda/classes/e;

    move-result-object v0

    check-cast v0, Lcom/android/internal/util/danda/classes/q;

    if-nez v0, :cond_3f

    const/4 p1, 0x0

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/m1;->c:Ljava/io/InputStream;

    const/4 p1, 0x1

    if-ge v1, p1, :cond_3d

    goto :goto_3e

    :cond_3d
    move v3, v1

    :goto_3e
    return v3

    .line 5
    :cond_3f
    invoke-interface {v0}, Lcom/android/internal/util/danda/classes/q;->c()Ljava/io/InputStream;

    move-result-object v0

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/m1;->c:Ljava/io/InputStream;

    goto :goto_1e
.end method

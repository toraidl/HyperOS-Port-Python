.class public final Lcom/android/internal/util/danda/classes/c;
.super Lcom/android/internal/util/danda/classes/t;
.source "SourceFile"


# static fields
.field public static final n:[B

.field public static final o:[B

.field public static final p:Lcom/android/internal/util/danda/classes/c;

.field public static final q:Lcom/android/internal/util/danda/classes/c;


# instance fields
.field public final m:[B


# direct methods
.method static constructor <clinit>()V
    .registers 4

    const/4 v0, 0x1

    new-array v1, v0, [B

    const/4 v2, -0x1

    const/4 v3, 0x0

    aput-byte v2, v1, v3

    sput-object v1, Lcom/android/internal/util/danda/classes/c;->n:[B

    new-array v1, v0, [B

    aput-byte v3, v1, v3

    sput-object v1, Lcom/android/internal/util/danda/classes/c;->o:[B

    new-instance v1, Lcom/android/internal/util/danda/classes/c;

    invoke-direct {v1, v3}, Lcom/android/internal/util/danda/classes/c;-><init>(Z)V

    sput-object v1, Lcom/android/internal/util/danda/classes/c;->p:Lcom/android/internal/util/danda/classes/c;

    new-instance v1, Lcom/android/internal/util/danda/classes/c;

    invoke-direct {v1, v0}, Lcom/android/internal/util/danda/classes/c;-><init>(Z)V

    sput-object v1, Lcom/android/internal/util/danda/classes/c;->q:Lcom/android/internal/util/danda/classes/c;

    return-void
.end method

.method public constructor <init>(Z)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-eqz p1, :cond_8

    sget-object p1, Lcom/android/internal/util/danda/classes/c;->n:[B

    goto :goto_a

    :cond_8
    sget-object p1, Lcom/android/internal/util/danda/classes/c;->o:[B

    :goto_a
    iput-object p1, p0, Lcom/android/internal/util/danda/classes/c;->m:[B

    return-void
.end method

.method public constructor <init>([B)V
    .registers 4

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    array-length v0, p1

    const/4 v1, 0x1

    if-ne v0, v1, :cond_22

    const/4 v0, 0x0

    .line 4
    aget-byte v0, p1, v0

    if-nez v0, :cond_11

    sget-object p1, Lcom/android/internal/util/danda/classes/c;->o:[B

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/c;->m:[B

    goto :goto_21

    :cond_11
    const/16 v1, 0xff

    and-int/2addr v0, v1

    if-ne v0, v1, :cond_1b

    sget-object p1, Lcom/android/internal/util/danda/classes/c;->n:[B

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/c;->m:[B

    goto :goto_21

    .line 5
    :cond_1b
    invoke-static {p1}, Lcom/android/internal/util/danda/classes/c0;->g([B)[B

    move-result-object p1

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/c;->m:[B

    :goto_21
    return-void

    .line 6
    :cond_22
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "byte value should have 1 byte in it"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static n([B)Lcom/android/internal/util/danda/classes/c;
    .registers 3

    array-length v0, p0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1a

    const/4 v0, 0x0

    aget-byte v0, p0, v0

    if-nez v0, :cond_c

    sget-object p0, Lcom/android/internal/util/danda/classes/c;->p:Lcom/android/internal/util/danda/classes/c;

    return-object p0

    :cond_c
    const/16 v1, 0xff

    and-int/2addr v0, v1

    if-ne v0, v1, :cond_14

    sget-object p0, Lcom/android/internal/util/danda/classes/c;->q:Lcom/android/internal/util/danda/classes/c;

    return-object p0

    :cond_14
    new-instance v0, Lcom/android/internal/util/danda/classes/c;

    invoke-direct {v0, p0}, Lcom/android/internal/util/danda/classes/c;-><init>([B)V

    return-object v0

    :cond_1a
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "BOOLEAN value should have 1 byte in it"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static o(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/c;
    .registers 4

    if-eqz p0, :cond_41

    instance-of v0, p0, Lcom/android/internal/util/danda/classes/c;

    if-eqz v0, :cond_7

    goto :goto_41

    :cond_7
    instance-of v0, p0, [B

    if-eqz v0, :cond_2d

    check-cast p0, [B

    :try_start_d
    invoke-static {p0}, Lcom/android/internal/util/danda/classes/t;->j([B)Lcom/android/internal/util/danda/classes/t;

    move-result-object p0

    check-cast p0, Lcom/android/internal/util/danda/classes/c;
    :try_end_13
    .catch Ljava/io/IOException; {:try_start_d .. :try_end_13} :catch_14

    return-object p0

    :catch_14
    move-exception p0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "failed to construct boolean from byte[]: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2d
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const-string v1, "illegal object in getInstance: "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_41
    :goto_41
    check-cast p0, Lcom/android/internal/util/danda/classes/c;

    return-object p0
.end method

.method public static p(Lcom/android/internal/util/danda/classes/a0;)Lcom/android/internal/util/danda/classes/c;
    .registers 2

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object p0

    instance-of v0, p0, Lcom/android/internal/util/danda/classes/c;

    if-eqz v0, :cond_d

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/c;->o(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/c;

    move-result-object p0

    return-object p0

    :cond_d
    check-cast p0, Lcom/android/internal/util/danda/classes/p;

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/p;->o()[B

    move-result-object p0

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/c;->n([B)Lcom/android/internal/util/danda/classes/c;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final g(Lcom/android/internal/util/danda/classes/t;)Z
    .registers 4

    instance-of v0, p1, Lcom/android/internal/util/danda/classes/c;

    const/4 v1, 0x0

    if-eqz v0, :cond_12

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/c;->m:[B

    aget-byte v0, v0, v1

    check-cast p1, Lcom/android/internal/util/danda/classes/c;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/c;->m:[B

    aget-byte p1, p1, v1

    if-ne v0, p1, :cond_12

    const/4 v1, 0x1

    :cond_12
    return v1
.end method

.method public final h(Lcom/android/internal/util/danda/classes/f;)V
    .registers 4

    const/4 v0, 0x1

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/c;->m:[B

    invoke-virtual {p1, v0, v1}, Lcom/android/internal/util/danda/classes/f;->h(I[B)V

    return-void
.end method

.method public final hashCode()I
    .registers 3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/c;->m:[B

    const/4 v1, 0x0

    aget-byte v0, v0, v1

    return v0
.end method

.method public final i()I
    .registers 2

    const/4 v0, 0x3

    return v0
.end method

.method public final k()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public final q()Z
    .registers 3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/c;->m:[B

    const/4 v1, 0x0

    aget-byte v0, v0, v1

    if-eqz v0, :cond_8

    const/4 v1, 0x1

    :cond_8
    return v1
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/c;->m:[B

    const/4 v1, 0x0

    aget-byte v0, v0, v1

    if-eqz v0, :cond_a

    const-string v0, "TRUE"

    goto :goto_c

    :cond_a
    const-string v0, "FALSE"

    :goto_c
    return-object v0
.end method

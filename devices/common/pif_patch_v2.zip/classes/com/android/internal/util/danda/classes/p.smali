.class public abstract Lcom/android/internal/util/danda/classes/p;
.super Lcom/android/internal/util/danda/classes/t;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/q;


# instance fields
.field public final m:[B


# direct methods
.method public constructor <init>([B)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-eqz p1, :cond_8

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/p;->m:[B

    return-void

    :cond_8
    new-instance p1, Ljava/lang/NullPointerException;

    const-string v0, "string cannot be null"

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static n(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/p;
    .registers 4

    if-eqz p0, :cond_55

    instance-of v0, p0, Lcom/android/internal/util/danda/classes/p;

    if-eqz v0, :cond_7

    goto :goto_55

    :cond_7
    instance-of v0, p0, [B

    if-eqz v0, :cond_2f

    :try_start_b
    check-cast p0, [B

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/t;->j([B)Lcom/android/internal/util/danda/classes/t;

    move-result-object p0

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/p;->n(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/p;

    move-result-object p0
    :try_end_15
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_15} :catch_16

    return-object p0

    :catch_16
    move-exception p0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "failed to construct OCTET STRING from byte[]: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2f
    instance-of v0, p0, Lcom/android/internal/util/danda/classes/e;

    if-eqz v0, :cond_41

    move-object v0, p0

    check-cast v0, Lcom/android/internal/util/danda/classes/e;

    invoke-interface {v0}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    instance-of v1, v0, Lcom/android/internal/util/danda/classes/p;

    if-eqz v1, :cond_41

    check-cast v0, Lcom/android/internal/util/danda/classes/p;

    return-object v0

    :cond_41
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const-string v1, "illegal object in getInstance: "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_55
    :goto_55
    check-cast p0, Lcom/android/internal/util/danda/classes/p;

    return-object p0
.end method


# virtual methods
.method public final b()Lcom/android/internal/util/danda/classes/t;
    .registers 1

    return-object p0
.end method

.method public final c()Ljava/io/InputStream;
    .registers 3

    new-instance v0, Ljava/io/ByteArrayInputStream;

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/p;->m:[B

    invoke-direct {v0, v1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    return-object v0
.end method

.method public final g(Lcom/android/internal/util/danda/classes/t;)Z
    .registers 3

    instance-of v0, p1, Lcom/android/internal/util/danda/classes/p;

    if-nez v0, :cond_6

    const/4 p1, 0x0

    return p1

    :cond_6
    check-cast p1, Lcom/android/internal/util/danda/classes/p;

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/p;->m:[B

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/p;->m:[B

    invoke-static {v0, p1}, Lcom/android/internal/util/danda/classes/c0;->c([B[B)Z

    move-result p1

    return p1
.end method

.method public final hashCode()I
    .registers 2

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/p;->o()[B

    move-result-object v0

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/c0;->j([B)I

    move-result v0

    return v0
.end method

.method public final l()Lcom/android/internal/util/danda/classes/t;
    .registers 3

    new-instance v0, Lcom/android/internal/util/danda/classes/a2;

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/p;->m:[B

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    return-object v0
.end method

.method public final m()Lcom/android/internal/util/danda/classes/t;
    .registers 3

    new-instance v0, Lcom/android/internal/util/danda/classes/a2;

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/p;->m:[B

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    return-object v0
.end method

.method public o()[B
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/p;->m:[B

    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    sget-object v0, Lcom/android/internal/util/danda/classes/p3;->a:Lcom/android/internal/util/danda/classes/y5;

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/p;->m:[B

    array-length v1, v0

    invoke-static {v0, v1}, Lcom/android/internal/util/danda/classes/p3;->b([BI)[B

    move-result-object v0

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/p5;->a([B)Ljava/lang/String;

    move-result-object v0

    const-string v1, "#"

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

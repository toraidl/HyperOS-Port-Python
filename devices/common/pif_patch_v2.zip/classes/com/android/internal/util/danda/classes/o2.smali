.class public final Lcom/android/internal/util/danda/classes/o2;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/h6;


# instance fields
.field public final synthetic m:I

.field public final n:Ljava/lang/Object;

.field public final o:Ljava/lang/Object;

.field public final p:Lcom/android/internal/util/danda/classes/t;


# direct methods
.method public constructor <init>(Lcom/android/internal/util/danda/classes/x2;[B)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    iput v0, p0, Lcom/android/internal/util/danda/classes/o2;->m:I

    const/4 v1, 0x0

    iput-object v1, p0, Lcom/android/internal/util/danda/classes/o2;->p:Lcom/android/internal/util/danda/classes/t;

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/o2;->n:Ljava/lang/Object;

    iput-object p2, p0, Lcom/android/internal/util/danda/classes/o2;->o:Ljava/lang/Object;

    .line 2
    iget-object p1, p1, Lcom/android/internal/util/danda/classes/x2;->a:Lcom/android/internal/util/danda/classes/h3;

    .line 3
    invoke-interface {p1}, Lcom/android/internal/util/danda/classes/h3;->a()I

    move-result p1

    if-ne p1, v0, :cond_1a

    sget-object p1, Lcom/android/internal/util/danda/classes/h6;->a:Lcom/android/internal/util/danda/classes/o;

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/o2;->p:Lcom/android/internal/util/danda/classes/t;

    goto :goto_3a

    :cond_1a
    iget-object p1, p0, Lcom/android/internal/util/danda/classes/o2;->n:Ljava/lang/Object;

    check-cast p1, Lcom/android/internal/util/danda/classes/x2;

    .line 4
    iget-object p1, p1, Lcom/android/internal/util/danda/classes/x2;->a:Lcom/android/internal/util/danda/classes/h3;

    .line 5
    invoke-interface {p1}, Lcom/android/internal/util/danda/classes/h3;->a()I

    move-result p2

    if-le p2, v0, :cond_3b

    invoke-interface {p1}, Lcom/android/internal/util/danda/classes/h3;->b()Ljava/math/BigInteger;

    move-result-object p2

    sget-object v0, Lcom/android/internal/util/danda/classes/u2;->c:Ljava/math/BigInteger;

    invoke-virtual {p2, v0}, Ljava/math/BigInteger;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_3b

    instance-of p1, p1, Lcom/android/internal/util/danda/classes/o3;

    if-eqz p1, :cond_3b

    sget-object p1, Lcom/android/internal/util/danda/classes/h6;->b:Lcom/android/internal/util/danda/classes/o;

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/o2;->p:Lcom/android/internal/util/danda/classes/t;

    :goto_3a
    return-void

    .line 6
    :cond_3b
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "This type of ECCurve is not implemented"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public constructor <init>(Ljava/math/BigInteger;Ljava/math/BigInteger;Ljava/math/BigInteger;)V
    .registers 5

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lcom/android/internal/util/danda/classes/o2;->m:I

    .line 8
    new-instance v0, Lcom/android/internal/util/danda/classes/k;

    invoke-direct {v0, p1}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/o2;->n:Ljava/lang/Object;

    .line 9
    new-instance p1, Lcom/android/internal/util/danda/classes/k;

    invoke-direct {p1, p2}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/o2;->o:Ljava/lang/Object;

    .line 10
    new-instance p1, Lcom/android/internal/util/danda/classes/k;

    invoke-direct {p1, p3}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/o2;->p:Lcom/android/internal/util/danda/classes/t;

    return-void
.end method


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 7

    iget v0, p0, Lcom/android/internal/util/danda/classes/o2;->m:I

    const/4 v1, 0x0

    packed-switch v0, :pswitch_data_132

    new-instance v0, Lcom/android/internal/util/danda/classes/f;

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/o2;->p:Lcom/android/internal/util/danda/classes/t;

    check-cast v2, Lcom/android/internal/util/danda/classes/o;

    sget-object v3, Lcom/android/internal/util/danda/classes/h6;->a:Lcom/android/internal/util/danda/classes/o;

    invoke-virtual {v2, v3}, Lcom/android/internal/util/danda/classes/t;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_85

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/o2;->n:Ljava/lang/Object;

    check-cast v2, Lcom/android/internal/util/danda/classes/x2;

    iget-object v2, v2, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->e()I

    move-result v3

    add-int/lit8 v3, v3, 0x7

    div-int/lit8 v3, v3, 0x8

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->q()Ljava/math/BigInteger;

    move-result-object v2

    invoke-virtual {v2}, Ljava/math/BigInteger;->toByteArray()[B

    move-result-object v2

    array-length v4, v2

    if-ge v3, v4, :cond_39

    new-array v4, v3, [B

    array-length v5, v2

    sub-int/2addr v5, v3

    invoke-static {v2, v5, v4, v1, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :goto_37
    move-object v2, v4

    goto :goto_45

    :cond_39
    array-length v4, v2

    if-le v3, v4, :cond_45

    new-array v4, v3, [B

    array-length v5, v2

    sub-int/2addr v3, v5

    array-length v5, v2

    invoke-static {v2, v1, v4, v3, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    goto :goto_37

    :cond_45
    :goto_45
    new-instance v3, Lcom/android/internal/util/danda/classes/a2;

    invoke-direct {v3, v2}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    invoke-virtual {v0, v3}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/o2;->n:Ljava/lang/Object;

    check-cast v2, Lcom/android/internal/util/danda/classes/x2;

    iget-object v2, v2, Lcom/android/internal/util/danda/classes/x2;->c:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->e()I

    move-result v3

    add-int/lit8 v3, v3, 0x7

    div-int/lit8 v3, v3, 0x8

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->q()Ljava/math/BigInteger;

    move-result-object v2

    invoke-virtual {v2}, Ljava/math/BigInteger;->toByteArray()[B

    move-result-object v2

    array-length v4, v2

    if-ge v3, v4, :cond_6f

    new-array v4, v3, [B

    array-length v5, v2

    sub-int/2addr v5, v3

    invoke-static {v2, v5, v4, v1, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :goto_6d
    move-object v2, v4

    goto :goto_7b

    :cond_6f
    array-length v4, v2

    if-le v3, v4, :cond_7b

    new-array v4, v3, [B

    array-length v5, v2

    sub-int/2addr v3, v5

    array-length v5, v2

    invoke-static {v2, v1, v4, v3, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    goto :goto_6d

    :cond_7b
    :goto_7b
    new-instance v3, Lcom/android/internal/util/danda/classes/a2;

    invoke-direct {v3, v2}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    invoke-virtual {v0, v3}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    goto/16 :goto_fd

    :cond_85
    iget-object v2, p0, Lcom/android/internal/util/danda/classes/o2;->p:Lcom/android/internal/util/danda/classes/t;

    check-cast v2, Lcom/android/internal/util/danda/classes/o;

    sget-object v3, Lcom/android/internal/util/danda/classes/h6;->b:Lcom/android/internal/util/danda/classes/o;

    invoke-virtual {v2, v3}, Lcom/android/internal/util/danda/classes/t;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_fd

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/o2;->n:Ljava/lang/Object;

    check-cast v2, Lcom/android/internal/util/danda/classes/x2;

    iget-object v2, v2, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->e()I

    move-result v3

    add-int/lit8 v3, v3, 0x7

    div-int/lit8 v3, v3, 0x8

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->q()Ljava/math/BigInteger;

    move-result-object v2

    invoke-virtual {v2}, Ljava/math/BigInteger;->toByteArray()[B

    move-result-object v2

    array-length v4, v2

    if-ge v3, v4, :cond_b3

    new-array v4, v3, [B

    array-length v5, v2

    sub-int/2addr v5, v3

    invoke-static {v2, v5, v4, v1, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :goto_b1
    move-object v2, v4

    goto :goto_bf

    :cond_b3
    array-length v4, v2

    if-le v3, v4, :cond_bf

    new-array v4, v3, [B

    array-length v5, v2

    sub-int/2addr v3, v5

    array-length v5, v2

    invoke-static {v2, v1, v4, v3, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    goto :goto_b1

    :cond_bf
    :goto_bf
    new-instance v3, Lcom/android/internal/util/danda/classes/a2;

    invoke-direct {v3, v2}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    invoke-virtual {v0, v3}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/o2;->n:Ljava/lang/Object;

    check-cast v2, Lcom/android/internal/util/danda/classes/x2;

    iget-object v2, v2, Lcom/android/internal/util/danda/classes/x2;->c:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->e()I

    move-result v3

    add-int/lit8 v3, v3, 0x7

    div-int/lit8 v3, v3, 0x8

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->q()Ljava/math/BigInteger;

    move-result-object v2

    invoke-virtual {v2}, Ljava/math/BigInteger;->toByteArray()[B

    move-result-object v2

    array-length v4, v2

    if-ge v3, v4, :cond_e9

    new-array v4, v3, [B

    array-length v5, v2

    sub-int/2addr v5, v3

    invoke-static {v2, v5, v4, v1, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :goto_e7
    move-object v2, v4

    goto :goto_f5

    :cond_e9
    array-length v4, v2

    if-le v3, v4, :cond_f5

    new-array v4, v3, [B

    array-length v5, v2

    sub-int/2addr v3, v5

    array-length v5, v2

    invoke-static {v2, v1, v4, v3, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    goto :goto_e7

    :cond_f5
    :goto_f5
    new-instance v3, Lcom/android/internal/util/danda/classes/a2;

    invoke-direct {v3, v2}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    invoke-virtual {v0, v3}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_fd
    :goto_fd
    iget-object v2, p0, Lcom/android/internal/util/danda/classes/o2;->o:Ljava/lang/Object;

    check-cast v2, [B

    if-eqz v2, :cond_10b

    new-instance v3, Lcom/android/internal/util/danda/classes/q1;

    invoke-direct {v3, v1, v2}, Lcom/android/internal/util/danda/classes/b;-><init>(I[B)V

    invoke-virtual {v0, v3}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_10b
    new-instance v2, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v2, v1, v0}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    return-object v2

    :pswitch_111
    new-instance v0, Lcom/android/internal/util/danda/classes/f;

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/o2;->n:Ljava/lang/Object;

    check-cast v2, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/o2;->o:Ljava/lang/Object;

    check-cast v2, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/o2;->p:Lcom/android/internal/util/danda/classes/t;

    check-cast v2, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v2, v1, v0}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    return-object v2

    nop

    :pswitch_data_132
    .packed-switch 0x0
        :pswitch_111
    .end packed-switch
.end method

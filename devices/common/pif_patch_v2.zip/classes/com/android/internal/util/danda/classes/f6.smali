.class public final Lcom/android/internal/util/danda/classes/f6;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"


# instance fields
.field public final m:Lcom/android/internal/util/danda/classes/a2;


# direct methods
.method public constructor <init>(Lcom/android/internal/util/danda/classes/p;)V
    .registers 3

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/p;->o()[B

    move-result-object p1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lcom/android/internal/util/danda/classes/a2;

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/c0;->g([B)[B

    move-result-object p1

    invoke-direct {v0, p1}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/f6;->m:Lcom/android/internal/util/danda/classes/a2;

    return-void
.end method


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/f6;->m:Lcom/android/internal/util/danda/classes/a2;

    return-object v0
.end method

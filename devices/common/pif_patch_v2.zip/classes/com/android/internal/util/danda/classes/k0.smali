.class public final Lcom/android/internal/util/danda/classes/k0;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"


# instance fields
.field public m:Lcom/android/internal/util/danda/classes/o;

.field public n:Lcom/android/internal/util/danda/classes/e;


# direct methods
.method public static g(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/k0;
    .registers 3

    instance-of v0, p0, Lcom/android/internal/util/danda/classes/k0;

    if-eqz v0, :cond_7

    check-cast p0, Lcom/android/internal/util/danda/classes/k0;

    return-object p0

    :cond_7
    if-eqz p0, :cond_23

    new-instance v0, Lcom/android/internal/util/danda/classes/k0;

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object p0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/o;

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/k0;->m:Lcom/android/internal/util/danda/classes/o;

    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object p0

    iput-object p0, v0, Lcom/android/internal/util/danda/classes/k0;->n:Lcom/android/internal/util/danda/classes/e;

    return-object v0

    :cond_23
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "null value in getInstance()"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 4

    new-instance v0, Lcom/android/internal/util/danda/classes/f;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/k0;->m:Lcom/android/internal/util/danda/classes/o;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/k0;->n:Lcom/android/internal/util/danda/classes/e;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v2, v1, v0}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    return-object v2
.end method

.class public abstract Lcom/android/internal/util/danda/classes/m5;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic a:I


# direct methods
.method static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public static a(Ljava/lang/String;Z)J
    .registers 9

    const-string v0, "-"

    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    const-wide/16 v0, 0x64

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz p1, :cond_2d

    array-length p1, p0

    const/4 v4, 0x3

    if-lt p1, v4, :cond_2d

    aget-object p1, p0, v3

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1

    int-to-long v3, p1

    const-wide/16 v5, 0x2710

    mul-long/2addr v3, v5

    aget-object p1, p0, v2

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1

    int-to-long v5, p1

    mul-long/2addr v5, v0

    add-long/2addr v5, v3

    const/4 p1, 0x2

    aget-object p0, p0, p1

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0

    int-to-long p0, p0

    add-long/2addr v5, p0

    return-wide v5

    :cond_2d
    aget-object p1, p0, v3

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1

    int-to-long v3, p1

    mul-long/2addr v3, v0

    aget-object p0, p0, v2

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0

    int-to-long p0, p0

    add-long/2addr v3, p0

    return-wide v3
.end method

.method public static b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;
    .registers 9

    invoke-virtual {p0, p1}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result p1

    const/4 v0, 0x0

    const/4 v1, -0x1

    if-ne p1, v1, :cond_9

    return-object v0

    :cond_9
    invoke-virtual {p0, p2, p1}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result p1

    const/4 v2, 0x0

    :goto_e
    if-ge v2, p4, :cond_1f

    if-ne p1, v1, :cond_13

    return-object v0

    :cond_13
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v3

    add-int/2addr v3, p1

    invoke-virtual {p0, p2, v3}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result p1

    add-int/lit8 v2, v2, 0x1

    goto :goto_e

    :cond_1f
    if-ne p1, v1, :cond_22

    return-object v0

    :cond_22
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result p2

    add-int/2addr p2, p1

    invoke-virtual {p0, p3, p2}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result p1

    if-ne p1, v1, :cond_2e

    return-object v0

    :cond_2e
    invoke-virtual {p0, p2, p1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static c(Ljava/lang/String;)Ljava/lang/String;
    .registers 10

    const-string v0, "OemPorts10TUtils"

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "persist.sys."

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "_chunks"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/os/SystemProperties;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    if-eqz v1, :cond_f3

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_f3

    const-string v4, "0"

    invoke-virtual {v4, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2c

    goto/16 :goto_f3

    :cond_2c
    :try_start_2c
    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    move v6, v5

    :goto_37
    if-ge v6, v1, :cond_81

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, "_chunk"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Landroid/os/SystemProperties;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    if-eqz v7, :cond_64

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_64

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v6, v6, 0x1

    goto :goto_37

    :catch_62
    move-exception v1

    goto :goto_da

    :cond_64
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Missing chunk "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " for "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v3

    :cond_81
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "_length"

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v5}, Landroid/os/SystemProperties;->getInt(Ljava/lang/String;I)I

    move-result v2

    if-lez v2, :cond_ce

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v4

    if-eq v4, v2, :cond_ce

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Length mismatch for "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, ": expected "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ", got "

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v3

    :cond_ce
    invoke-static {v1, v5}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v1

    new-instance v2, Ljava/lang/String;

    sget-object v4, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v2, v1, v4}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    :try_end_d9
    .catch Ljava/lang/Exception; {:try_start_2c .. :try_end_d9} :catch_62

    return-object v2

    :goto_da
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v4, "Failed to get property "

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ": "

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_f3
    :goto_f3
    return-object v3
.end method

.method public static d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/m5;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x0

    if-eqz p0, :cond_1a

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_1a

    :try_start_11
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_1a
    .catch Lorg/json/JSONException; {:try_start_11 .. :try_end_1a} :catch_1a

    :catch_1a
    :cond_1a
    return-object v0
.end method

.method public static e()[B
    .registers 9

    const/4 v0, 0x0

    :try_start_1
    const-string v1, "ro.boot.vbmeta.digest"

    invoke-static {v1}, Landroid/os/SystemProperties;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_3f

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    const/16 v3, 0x40

    if-lt v2, v3, :cond_3f

    const/16 v2, 0x20

    new-array v3, v2, [B

    const/4 v4, 0x0

    const/4 v5, 0x1

    move v6, v4

    :goto_18
    if-ge v6, v2, :cond_33

    mul-int/lit8 v7, v6, 0x2

    add-int/lit8 v8, v7, 0x2

    invoke-virtual {v1, v7, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0x10

    invoke-static {v7, v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v7

    int-to-byte v7, v7

    aput-byte v7, v3, v6
    :try_end_2b
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_2b} :catch_31

    if-eqz v7, :cond_2e

    move v5, v4

    :cond_2e
    add-int/lit8 v6, v6, 0x1

    goto :goto_18

    :catch_31
    move-exception v1

    goto :goto_38

    :cond_33
    if-eqz v5, :cond_36

    goto :goto_37

    :cond_36
    move-object v0, v3

    :goto_37
    return-object v0

    :goto_38
    const-string v2, "OemPorts10TUtils"

    const-string v3, "Failed to parse ro.boot.vbmeta.digest"

    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_3f
    return-object v0
.end method

.method public static f()V
    .registers 15

    const-string v0, "</PrivateKey>"

    const-string v1, "<PrivateKey format=\"pem\">"

    const-string v2, "<Key algorithm=\"rsa\">"

    const-string v3, "<Key algorithm=\"ecdsa\">"

    const-string v4, "</Certificate>"

    const-string v5, "<Certificate format=\"pem\">"

    sget-object v6, Lcom/android/internal/util/danda/OemPorts10TUtils;->h:Ljava/lang/Boolean;

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v6

    if-eqz v6, :cond_15

    return-void

    :cond_15
    new-instance v6, Ljava/lang/String;

    const-string v7, "L2RhdGEvbG9jYWwvb2VtcG9ydHMxMHQva2V5Ym94LnhtbAo="

    const/4 v8, 0x0

    invoke-static {v7, v8}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v7

    invoke-direct {v6, v7}, Ljava/lang/String;-><init>([B)V

    invoke-virtual {v6}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/android/internal/util/danda/classes/m5;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "OemPorts10TUtils"

    if-nez v6, :cond_35

    sput-boolean v8, Lcom/android/internal/util/danda/OemPorts10TUtils;->b:Z

    const-string v0, "No keybox file found"

    invoke-static {v7, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_35
    :try_start_35
    const-string v9, "<NumberOfCertificates>(\\d+)</NumberOfCertificates>"

    invoke-static {v9}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v9

    invoke-virtual {v9, v6}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v9

    move v10, v8

    :goto_40
    invoke-virtual {v9}, Ljava/util/regex/Matcher;->find()Z

    move-result v11

    const/4 v12, 0x1

    if-eqz v11, :cond_51

    invoke-virtual {v9, v12}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v11

    add-int/2addr v10, v11

    goto :goto_40

    :cond_51
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    sput-object v9, Lcom/android/internal/util/danda/OemPorts10TUtils;->a:Ljava/lang/Integer;

    sget-object v9, Lcom/android/internal/util/danda/OemPorts10TUtils;->e:Ljava/lang/Boolean;

    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v9

    if-eqz v9, :cond_79

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "Setting keybox certs... Keybox size: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v10, Lcom/android/internal/util/danda/OemPorts10TUtils;->a:Ljava/lang/Integer;

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v7, v9}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_79

    :catch_76
    move-exception v0

    goto/16 :goto_113

    :cond_79
    :goto_79
    sget-object v9, Lcom/android/internal/util/danda/OemPorts10TUtils;->a:Ljava/lang/Integer;

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v9

    const/4 v10, 0x4

    const/16 v11, 0x8

    const/4 v13, 0x6

    if-eq v9, v10, :cond_b2

    sget-object v9, Lcom/android/internal/util/danda/OemPorts10TUtils;->a:Ljava/lang/Integer;

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v9

    if-eq v9, v13, :cond_b2

    sget-object v9, Lcom/android/internal/util/danda/OemPorts10TUtils;->a:Ljava/lang/Integer;

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v9

    if-ne v9, v11, :cond_96

    goto :goto_b2

    :cond_96
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Unexpected Keybox size: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lcom/android/internal/util/danda/OemPorts10TUtils;->a:Ljava/lang/Integer;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "Valid sizes: 4, 6, 8"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v7, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_110

    :cond_b2
    :goto_b2
    invoke-static {v6, v3, v1, v0, v8}, Lcom/android/internal/util/danda/classes/m5;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v9

    sput-object v9, Lcom/android/internal/util/danda/classes/c0;->a:Ljava/lang/String;

    invoke-static {v6, v3, v5, v4, v8}, Lcom/android/internal/util/danda/classes/m5;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v9

    sput-object v9, Lcom/android/internal/util/danda/classes/c0;->b:Ljava/lang/String;

    invoke-static {v6, v3, v5, v4, v12}, Lcom/android/internal/util/danda/classes/m5;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v9

    sput-object v9, Lcom/android/internal/util/danda/classes/c0;->c:Ljava/lang/String;

    sget-object v9, Lcom/android/internal/util/danda/OemPorts10TUtils;->a:Ljava/lang/Integer;

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v9

    const/4 v10, 0x2

    if-lt v9, v13, :cond_d3

    invoke-static {v6, v3, v5, v4, v10}, Lcom/android/internal/util/danda/classes/m5;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v9

    sput-object v9, Lcom/android/internal/util/danda/classes/c0;->d:Ljava/lang/String;

    :cond_d3
    sget-object v9, Lcom/android/internal/util/danda/OemPorts10TUtils;->a:Ljava/lang/Integer;

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v9

    const/4 v14, 0x3

    if-lt v9, v11, :cond_e2

    invoke-static {v6, v3, v5, v4, v14}, Lcom/android/internal/util/danda/classes/m5;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lcom/android/internal/util/danda/classes/c0;->e:Ljava/lang/String;

    :cond_e2
    invoke-static {v6, v2, v1, v0, v8}, Lcom/android/internal/util/danda/classes/m5;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/internal/util/danda/classes/c0;->f:Ljava/lang/String;

    invoke-static {v6, v2, v5, v4, v8}, Lcom/android/internal/util/danda/classes/m5;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/internal/util/danda/classes/c0;->g:Ljava/lang/String;

    invoke-static {v6, v2, v5, v4, v12}, Lcom/android/internal/util/danda/classes/m5;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/internal/util/danda/classes/c0;->h:Ljava/lang/String;

    sget-object v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->a:Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    if-lt v0, v13, :cond_102

    invoke-static {v6, v2, v5, v4, v10}, Lcom/android/internal/util/danda/classes/m5;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/internal/util/danda/classes/c0;->i:Ljava/lang/String;

    :cond_102
    sget-object v0, Lcom/android/internal/util/danda/OemPorts10TUtils;->a:Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    if-lt v0, v11, :cond_110

    invoke-static {v6, v2, v5, v4, v14}, Lcom/android/internal/util/danda/classes/m5;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/android/internal/util/danda/classes/c0;->j:Ljava/lang/String;

    :cond_110
    :goto_110
    sput-boolean v12, Lcom/android/internal/util/danda/OemPorts10TUtils;->b:Z
    :try_end_112
    .catch Ljava/lang/Exception; {:try_start_35 .. :try_end_112} :catch_76

    goto :goto_124

    :goto_113
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Unable to load keybox"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v7, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :goto_124
    return-void
.end method

.method public static g(Ljava/lang/String;)Ljava/security/cert/Certificate;
    .registers 4

    new-instance v0, Lcom/android/internal/util/danda/classes/z4;

    new-instance v1, Ljava/io/StringReader;

    invoke-direct {v1, p0}, Ljava/io/StringReader;-><init>(Ljava/lang/String;)V

    invoke-direct {v0, v1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    :try_start_a
    sget-object p0, Lcom/android/internal/util/danda/classes/b4;->e:Ljava/security/cert/CertificateFactory;

    new-instance v1, Ljava/io/ByteArrayInputStream;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/z4;->a()Lcom/android/internal/util/danda/classes/x4;

    move-result-object v2

    iget-object v2, v2, Lcom/android/internal/util/danda/classes/x4;->c:[B

    invoke-direct {v1, v2}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-virtual {p0, v1}, Ljava/security/cert/CertificateFactory;->generateCertificate(Ljava/io/InputStream;)Ljava/security/cert/Certificate;

    move-result-object p0
    :try_end_1b
    .catchall {:try_start_a .. :try_end_1b} :catchall_1f

    invoke-virtual {v0}, Ljava/io/Reader;->close()V

    return-object p0

    :catchall_1f
    move-exception p0

    :try_start_20
    invoke-virtual {v0}, Ljava/io/Reader;->close()V
    :try_end_23
    .catchall {:try_start_20 .. :try_end_23} :catchall_24

    goto :goto_28

    :catchall_24
    move-exception v0

    invoke-virtual {p0, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_28
    throw p0
.end method

.method public static h(II)V
    .registers 5

    const-string v0, "cert_ecpriv"

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m5;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m5;->j(Ljava/lang/String;)Lcom/android/internal/util/danda/classes/o4;

    move-result-object v0

    sput-object v0, Lcom/android/internal/util/danda/classes/b4;->a:Lcom/android/internal/util/danda/classes/o4;

    sget-object v0, Lcom/android/internal/util/danda/classes/b4;->c:Ljava/util/ArrayList;

    const-string v1, "cert_ec1"

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/m5;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const-string v1, "cert_ec2"

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/m5;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x3

    if-lt p0, v1, :cond_38

    const-string v2, "cert_ec3"

    invoke-static {v2}, Lcom/android/internal/util/danda/classes/m5;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_38
    const/4 v2, 0x4

    if-lt p0, v2, :cond_48

    const-string p0, "cert_ec4"

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/m5;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_48
    const-string p0, "cert_rsapriv"

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/m5;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/m5;->j(Ljava/lang/String;)Lcom/android/internal/util/danda/classes/o4;

    move-result-object p0

    sput-object p0, Lcom/android/internal/util/danda/classes/b4;->b:Lcom/android/internal/util/danda/classes/o4;

    sget-object p0, Lcom/android/internal/util/danda/classes/b4;->d:Ljava/util/ArrayList;

    const-string v0, "cert_rsa1"

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m5;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const-string v0, "cert_rsa2"

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m5;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-lt p1, v1, :cond_7f

    const-string v0, "cert_rsa3"

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m5;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_7f
    if-lt p1, v2, :cond_8e

    const-string p1, "cert_rsa4"

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/m5;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_8e
    return-void
.end method

.method public static i(II)V
    .registers 5

    sget-object v0, Lcom/android/internal/util/danda/classes/c0;->a:Ljava/lang/String;

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m5;->j(Ljava/lang/String;)Lcom/android/internal/util/danda/classes/o4;

    move-result-object v0

    sput-object v0, Lcom/android/internal/util/danda/classes/b4;->a:Lcom/android/internal/util/danda/classes/o4;

    sget-object v0, Lcom/android/internal/util/danda/classes/b4;->c:Ljava/util/ArrayList;

    sget-object v1, Lcom/android/internal/util/danda/classes/c0;->b:Ljava/lang/String;

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object v1, Lcom/android/internal/util/danda/classes/c0;->c:Ljava/lang/String;

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x3

    if-lt p0, v1, :cond_28

    sget-object v2, Lcom/android/internal/util/danda/classes/c0;->d:Ljava/lang/String;

    invoke-static {v2}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_28
    const/4 v2, 0x4

    if-lt p0, v2, :cond_34

    sget-object p0, Lcom/android/internal/util/danda/classes/c0;->e:Ljava/lang/String;

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_34
    sget-object p0, Lcom/android/internal/util/danda/classes/c0;->f:Ljava/lang/String;

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/m5;->j(Ljava/lang/String;)Lcom/android/internal/util/danda/classes/o4;

    move-result-object p0

    sput-object p0, Lcom/android/internal/util/danda/classes/b4;->b:Lcom/android/internal/util/danda/classes/o4;

    sget-object p0, Lcom/android/internal/util/danda/classes/b4;->d:Ljava/util/ArrayList;

    sget-object v0, Lcom/android/internal/util/danda/classes/c0;->g:Ljava/lang/String;

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object v0, Lcom/android/internal/util/danda/classes/c0;->h:Ljava/lang/String;

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-lt p1, v1, :cond_5b

    sget-object v0, Lcom/android/internal/util/danda/classes/c0;->i:Ljava/lang/String;

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5b
    if-lt p1, v2, :cond_66

    sget-object p1, Lcom/android/internal/util/danda/classes/c0;->j:Ljava/lang/String;

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/m5;->g(Ljava/lang/String;)Ljava/security/cert/Certificate;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_66
    return-void
.end method

.method public static j(Ljava/lang/String;)Lcom/android/internal/util/danda/classes/o4;
    .registers 3

    new-instance v0, Lcom/android/internal/util/danda/classes/t4;

    new-instance v1, Ljava/io/StringReader;

    invoke-direct {v1, p0}, Ljava/io/StringReader;-><init>(Ljava/lang/String;)V

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/t4;-><init>(Ljava/io/StringReader;)V

    :try_start_a
    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/t4;->b()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/android/internal/util/danda/classes/o4;
    :try_end_10
    .catchall {:try_start_a .. :try_end_10} :catchall_14

    invoke-virtual {v0}, Ljava/io/Reader;->close()V

    return-object p0

    :catchall_14
    move-exception p0

    :try_start_15
    invoke-virtual {v0}, Ljava/io/Reader;->close()V
    :try_end_18
    .catchall {:try_start_15 .. :try_end_18} :catchall_19

    goto :goto_1d

    :catchall_19
    move-exception v0

    invoke-virtual {p0, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_1d
    throw p0
.end method

.method public static k(Ljava/lang/String;)Ljava/lang/String;
    .registers 7

    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result p0

    const/4 v1, 0x0

    if-eqz p0, :cond_42

    invoke-virtual {v0}, Ljava/io/File;->length()J

    move-result-wide v2

    const-wide/16 v4, 0x0

    cmp-long p0, v2, v4

    if-nez p0, :cond_17

    goto :goto_42

    :cond_17
    invoke-virtual {v0}, Ljava/io/File;->length()J

    move-result-wide v2

    long-to-int p0, v2

    new-array p0, p0, [B

    :try_start_1e
    new-instance v2, Ljava/io/FileInputStream;

    invoke-direct {v2, v0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_23
    .catch Ljava/io/IOException; {:try_start_1e .. :try_end_23} :catch_42

    :try_start_23
    invoke-virtual {v2, p0}, Ljava/io/FileInputStream;->read([B)I

    move-result v0
    :try_end_27
    .catchall {:try_start_23 .. :try_end_27} :catchall_38

    if-gtz v0, :cond_2d

    :try_start_29
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_2c
    .catch Ljava/io/IOException; {:try_start_29 .. :try_end_2c} :catch_42

    return-object v1

    :cond_2d
    :try_start_2d
    new-instance v0, Ljava/lang/String;

    sget-object v3, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v0, p0, v3}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    :try_end_34
    .catchall {:try_start_2d .. :try_end_34} :catchall_38

    :try_start_34
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_37
    .catch Ljava/io/IOException; {:try_start_34 .. :try_end_37} :catch_42

    return-object v0

    :catchall_38
    move-exception p0

    :try_start_39
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_3c
    .catchall {:try_start_39 .. :try_end_3c} :catchall_3d

    goto :goto_41

    :catchall_3d
    move-exception v0

    :try_start_3e
    invoke-virtual {p0, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_41
    throw p0
    :try_end_42
    .catch Ljava/io/IOException; {:try_start_3e .. :try_end_42} :catch_42

    :catch_42
    :cond_42
    :goto_42
    return-object v1
.end method

.method public static l(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    :try_start_0
    const-class v0, Landroid/os/Build;

    invoke-virtual {v0, p0}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1, p1}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 p1, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_12
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_12} :catch_15
    .catch Ljava/lang/NoSuchFieldException; {:try_start_0 .. :try_end_12} :catch_13

    goto :goto_21

    :catch_13
    move-exception p1

    goto :goto_16

    :catch_15
    move-exception p1

    :goto_16
    const-string v0, "Failed to spoof Build."

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "OemPorts10TUtils"

    invoke-static {v0, p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_21
    return-void
.end method

.method public static m(Ljava/lang/String;I)V
    .registers 4

    :try_start_0
    const-class v0, Landroid/os/Build$VERSION;

    invoke-virtual {v0, p0}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x0

    invoke-virtual {v0, v1, p1}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 p1, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_16
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_16} :catch_19
    .catch Ljava/lang/NoSuchFieldException; {:try_start_0 .. :try_end_16} :catch_17

    goto :goto_25

    :catch_17
    move-exception p1

    goto :goto_1a

    :catch_19
    move-exception p1

    :goto_1a
    const-string v0, "Failed to spoof Build."

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "OemPorts10TUtils"

    invoke-static {v0, p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_25
    return-void
.end method

.method public static n(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    :try_start_0
    const-class v0, Landroid/os/Build$VERSION;

    invoke-virtual {v0, p0}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1, p1}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 p1, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_12
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_12} :catch_15
    .catch Ljava/lang/NoSuchFieldException; {:try_start_0 .. :try_end_12} :catch_13

    goto :goto_21

    :catch_13
    move-exception p1

    goto :goto_16

    :catch_15
    move-exception p1

    :goto_16
    const-string v0, "Failed to spoof Build."

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "OemPorts10TUtils"

    invoke-static {v0, p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_21
    return-void
.end method

.method public static o(Ljava/lang/String;Ljava/lang/String;)V
    .registers 10

    const-string v0, "_length"

    const-string v1, "_chunks"

    const-string v2, "persist.sys."

    if-eqz p1, :cond_80

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_f

    goto :goto_80

    :cond_f
    sget-object v3, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p1, v3}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p1

    const/4 v3, 0x2

    invoke-static {p1, v3}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    add-int/lit8 v3, v3, 0x59

    div-int/lit8 v3, v3, 0x5a

    const/4 v4, 0x0

    :goto_23
    if-ge v4, v3, :cond_4f

    mul-int/lit8 v5, v4, 0x5a

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v6

    add-int/lit8 v7, v5, 0x5a

    invoke-static {v6, v7}, Ljava/lang/Math;->min(II)I

    move-result v6

    invoke-virtual {p1, v5, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "_chunk"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v5}, Landroid/os/SystemProperties;->set(Ljava/lang/String;Ljava/lang/String;)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_23

    :cond_4f
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3}, Landroid/os/SystemProperties;->set(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p1

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Landroid/os/SystemProperties;->set(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_80
    :goto_80
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v1, "0"

    invoke-static {p1, v1}, Landroid/os/SystemProperties;->set(Ljava/lang/String;Ljava/lang/String;)V

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, v1}, Landroid/os/SystemProperties;->set(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static p([Ljava/lang/String;II)V
    .registers 8

    const/4 v0, 0x0

    aget-object v0, p0, v0

    const-string v1, "cert_ecpriv"

    invoke-static {v1, v0}, Lcom/android/internal/util/danda/classes/m5;->o(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x1

    aget-object v0, p0, v0

    const-string v1, "cert_ec1"

    invoke-static {v1, v0}, Lcom/android/internal/util/danda/classes/m5;->o(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v0, 0x2

    aget-object v0, p0, v0

    const-string v1, "cert_ec2"

    invoke-static {v1, v0}, Lcom/android/internal/util/danda/classes/m5;->o(Ljava/lang/String;Ljava/lang/String;)V

    const-string v0, "cert_ec3"

    const-string v1, ""

    const/4 v2, 0x4

    if-lt p1, v2, :cond_26

    const/4 v3, 0x3

    aget-object v3, p0, v3

    invoke-static {v0, v3}, Lcom/android/internal/util/danda/classes/m5;->o(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_29

    :cond_26
    invoke-static {v0, v1}, Lcom/android/internal/util/danda/classes/m5;->o(Ljava/lang/String;Ljava/lang/String;)V

    :goto_29
    const-string v0, "cert_ec4"

    const/4 v3, 0x5

    if-lt p1, v3, :cond_34

    aget-object v4, p0, v2

    invoke-static {v0, v4}, Lcom/android/internal/util/danda/classes/m5;->o(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_37

    :cond_34
    invoke-static {v0, v1}, Lcom/android/internal/util/danda/classes/m5;->o(Ljava/lang/String;Ljava/lang/String;)V

    :goto_37
    const-string v0, "cert_rsapriv"

    aget-object v4, p0, p1

    invoke-static {v0, v4}, Lcom/android/internal/util/danda/classes/m5;->o(Ljava/lang/String;Ljava/lang/String;)V

    add-int/lit8 v0, p1, 0x1

    aget-object v0, p0, v0

    const-string v4, "cert_rsa1"

    invoke-static {v4, v0}, Lcom/android/internal/util/danda/classes/m5;->o(Ljava/lang/String;Ljava/lang/String;)V

    add-int/lit8 v0, p1, 0x2

    aget-object v0, p0, v0

    const-string v4, "cert_rsa2"

    invoke-static {v4, v0}, Lcom/android/internal/util/danda/classes/m5;->o(Ljava/lang/String;Ljava/lang/String;)V

    const-string v0, "cert_rsa3"

    if-lt p2, v2, :cond_5c

    add-int/lit8 v4, p1, 0x3

    aget-object v4, p0, v4

    invoke-static {v0, v4}, Lcom/android/internal/util/danda/classes/m5;->o(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_5f

    :cond_5c
    invoke-static {v0, v1}, Lcom/android/internal/util/danda/classes/m5;->o(Ljava/lang/String;Ljava/lang/String;)V

    :goto_5f
    const-string v0, "cert_rsa4"

    if-lt p2, v3, :cond_6a

    add-int/2addr p1, v2

    aget-object p1, p0, p1

    invoke-static {v0, p1}, Lcom/android/internal/util/danda/classes/m5;->o(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_6d

    :cond_6a
    invoke-static {v0, v1}, Lcom/android/internal/util/danda/classes/m5;->o(Ljava/lang/String;Ljava/lang/String;)V

    :goto_6d
    array-length p0, p0

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    const-string p1, "persist.sys.cert_size"

    invoke-static {p1, p0}, Landroid/os/SystemProperties;->set(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

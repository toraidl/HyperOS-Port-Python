.class public final Lcom/android/internal/util/danda/classes/k4;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"


# instance fields
.field public m:Lcom/android/internal/util/danda/classes/g;

.field public n:Lcom/android/internal/util/danda/classes/o;

.field public o:Lcom/android/internal/util/danda/classes/d0;

.field public p:Lcom/android/internal/util/danda/classes/q1;


# direct methods
.method public static g(Lcom/android/internal/util/danda/classes/a0;)Lcom/android/internal/util/danda/classes/k4;
    .registers 6

    const/4 v0, 0x0

    invoke-static {p0, v0}, Lcom/android/internal/util/danda/classes/u;->n(Lcom/android/internal/util/danda/classes/a0;Z)Lcom/android/internal/util/danda/classes/u;

    move-result-object p0

    instance-of v1, p0, Lcom/android/internal/util/danda/classes/k4;

    if-eqz v1, :cond_d

    check-cast p0, Lcom/android/internal/util/danda/classes/k4;

    goto/16 :goto_b3

    :cond_d
    if-eqz p0, :cond_b2

    new-instance v1, Lcom/android/internal/util/danda/classes/k4;

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object p0

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result v2

    const/4 v3, 0x4

    if-gt v2, v3, :cond_9a

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result v2

    const/4 v4, 0x3

    if-lt v2, v4, :cond_9a

    invoke-virtual {p0, v0}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v2

    if-eqz v2, :cond_6b

    instance-of v4, v2, Lcom/android/internal/util/danda/classes/g;

    if-eqz v4, :cond_31

    goto :goto_6b

    :cond_31
    instance-of v4, v2, [B

    if-eqz v4, :cond_57

    :try_start_35
    check-cast v2, [B

    invoke-static {v2}, Lcom/android/internal/util/danda/classes/t;->j([B)Lcom/android/internal/util/danda/classes/t;

    move-result-object v2

    check-cast v2, Lcom/android/internal/util/danda/classes/g;
    :try_end_3d
    .catch Ljava/lang/Exception; {:try_start_35 .. :try_end_3d} :catch_3e

    goto :goto_6d

    :catch_3e
    move-exception p0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "encoding error in getInstance: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_57
    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "illegal object in getInstance: "

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_6b
    :goto_6b
    check-cast v2, Lcom/android/internal/util/danda/classes/g;

    :goto_6d
    iput-object v2, v1, Lcom/android/internal/util/danda/classes/k4;->m:Lcom/android/internal/util/danda/classes/g;

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result v2

    if-ne v2, v3, :cond_80

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v2

    invoke-static {v2}, Lcom/android/internal/util/danda/classes/o;->p(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/o;

    move-result-object v2

    iput-object v2, v1, Lcom/android/internal/util/danda/classes/k4;->n:Lcom/android/internal/util/danda/classes/o;

    :cond_80
    add-int/lit8 v2, v0, 0x1

    invoke-virtual {p0, v2}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v2

    invoke-static {v2}, Lcom/android/internal/util/danda/classes/d0;->g(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/d0;

    move-result-object v2

    iput-object v2, v1, Lcom/android/internal/util/danda/classes/k4;->o:Lcom/android/internal/util/danda/classes/d0;

    add-int/lit8 v0, v0, 0x2

    invoke-virtual {p0, v0}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object p0

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/q1;->p(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/q1;

    move-result-object p0

    iput-object p0, v1, Lcom/android/internal/util/danda/classes/k4;->p:Lcom/android/internal/util/danda/classes/q1;

    move-object p0, v1

    goto :goto_b3

    :cond_9a
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Bad sequence size: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_b2
    const/4 p0, 0x0

    :goto_b3
    return-object p0
.end method


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 4

    new-instance v0, Lcom/android/internal/util/danda/classes/f;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/k4;->m:Lcom/android/internal/util/danda/classes/g;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/k4;->n:Lcom/android/internal/util/danda/classes/o;

    if-eqz v2, :cond_12

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_12
    iget-object v2, p0, Lcom/android/internal/util/danda/classes/k4;->o:Lcom/android/internal/util/danda/classes/d0;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/k4;->p:Lcom/android/internal/util/danda/classes/q1;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v2, v1, v0}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    return-object v2
.end method

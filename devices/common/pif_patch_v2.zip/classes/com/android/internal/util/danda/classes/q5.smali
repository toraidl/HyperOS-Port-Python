.class public final Lcom/android/internal/util/danda/classes/q5;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"


# instance fields
.field public m:Lcom/android/internal/util/danda/classes/d0;

.field public n:Lcom/android/internal/util/danda/classes/q1;


# direct methods
.method public constructor <init>(Lcom/android/internal/util/danda/classes/d0;Lcom/android/internal/util/danda/classes/m;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lcom/android/internal/util/danda/classes/q1;

    invoke-interface {p2}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object p2

    const-string v1, "DER"

    invoke-virtual {p2, v1}, Lcom/android/internal/util/danda/classes/m;->f(Ljava/lang/String;)[B

    move-result-object p2

    const/4 v1, 0x0

    invoke-direct {v0, v1, p2}, Lcom/android/internal/util/danda/classes/b;-><init>(I[B)V

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/q5;->n:Lcom/android/internal/util/danda/classes/q1;

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/q5;->m:Lcom/android/internal/util/danda/classes/d0;

    return-void
.end method

.method public static g(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/q5;
    .registers 4

    instance-of v0, p0, Lcom/android/internal/util/danda/classes/q5;

    if-eqz v0, :cond_7

    check-cast p0, Lcom/android/internal/util/danda/classes/q5;

    return-object p0

    :cond_7
    if-eqz p0, :cond_4a

    new-instance v0, Lcom/android/internal/util/danda/classes/q5;

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object p0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result v1

    const/4 v2, 0x2

    if-ne v1, v2, :cond_32

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/u;->q()Ljava/util/Enumeration;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/d0;->g(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/d0;

    move-result-object v1

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/q5;->m:Lcom/android/internal/util/danda/classes/d0;

    invoke-interface {p0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/q1;->p(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/q1;

    move-result-object p0

    iput-object p0, v0, Lcom/android/internal/util/danda/classes/q5;->n:Lcom/android/internal/util/danda/classes/q1;

    return-object v0

    :cond_32
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Bad sequence size: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_4a
    const/4 p0, 0x0

    return-object p0
.end method


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 4

    new-instance v0, Lcom/android/internal/util/danda/classes/f;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/q5;->m:Lcom/android/internal/util/danda/classes/d0;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/q5;->n:Lcom/android/internal/util/danda/classes/q1;

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v2, v1, v0}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    return-object v2
.end method

.class public final Lcom/android/internal/util/danda/classes/p1;
.super Lcom/android/internal/util/danda/classes/t;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/z;


# instance fields
.field public final m:[C


# direct methods
.method public constructor <init>([C)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/p1;->m:[C

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/String;

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/p1;->m:[C

    invoke-direct {v0, v1}, Ljava/lang/String;-><init>([C)V

    return-object v0
.end method

.method public final g(Lcom/android/internal/util/danda/classes/t;)Z
    .registers 8

    instance-of v0, p1, Lcom/android/internal/util/danda/classes/p1;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return v1

    :cond_6
    check-cast p1, Lcom/android/internal/util/danda/classes/p1;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/p1;->m:[C

    const/4 v0, 0x1

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/p1;->m:[C

    if-ne v2, p1, :cond_11

    :cond_f
    move v1, v0

    goto :goto_29

    :cond_11
    if-eqz v2, :cond_29

    if-nez p1, :cond_16

    goto :goto_29

    :cond_16
    array-length v3, v2

    array-length v4, p1

    if-eq v3, v4, :cond_1b

    goto :goto_29

    :cond_1b
    move v3, v1

    :goto_1c
    array-length v4, v2

    if-eq v3, v4, :cond_f

    aget-char v4, v2, v3

    aget-char v5, p1, v3

    if-eq v4, v5, :cond_26

    goto :goto_29

    :cond_26
    add-int/lit8 v3, v3, 0x1

    goto :goto_1c

    :cond_29
    :goto_29
    return v1
.end method

.method public final h(Lcom/android/internal/util/danda/classes/f;)V
    .registers 6

    const/16 v0, 0x1e

    invoke-virtual {p1, v0}, Lcom/android/internal/util/danda/classes/f;->g(I)V

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/p1;->m:[C

    array-length v1, v0

    mul-int/lit8 v1, v1, 0x2

    invoke-virtual {p1, v1}, Lcom/android/internal/util/danda/classes/f;->j(I)V

    const/4 v1, 0x0

    :goto_e
    array-length v2, v0

    if-eq v1, v2, :cond_20

    aget-char v2, v0, v1

    shr-int/lit8 v3, v2, 0x8

    int-to-byte v3, v3

    invoke-virtual {p1, v3}, Lcom/android/internal/util/danda/classes/f;->g(I)V

    int-to-byte v2, v2

    invoke-virtual {p1, v2}, Lcom/android/internal/util/danda/classes/f;->g(I)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_e

    :cond_20
    return-void
.end method

.method public final hashCode()I
    .registers 5

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/p1;->m:[C

    if-nez v0, :cond_6

    const/4 v0, 0x0

    goto :goto_14

    :cond_6
    array-length v1, v0

    add-int/lit8 v2, v1, 0x1

    :goto_9
    add-int/lit8 v1, v1, -0x1

    if-ltz v1, :cond_13

    mul-int/lit16 v2, v2, 0x101

    aget-char v3, v0, v1

    xor-int/2addr v2, v3

    goto :goto_9

    :cond_13
    move v0, v2

    :goto_14
    return v0
.end method

.method public final i()I
    .registers 3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/p1;->m:[C

    array-length v1, v0

    mul-int/lit8 v1, v1, 0x2

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/n5;->a(I)I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    array-length v0, v0

    mul-int/lit8 v0, v0, 0x2

    add-int/2addr v0, v1

    return v0
.end method

.method public final k()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 2

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/p1;->a()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

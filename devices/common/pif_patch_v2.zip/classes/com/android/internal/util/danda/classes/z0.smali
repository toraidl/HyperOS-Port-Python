.class public final Lcom/android/internal/util/danda/classes/z0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/e;
.implements Lcom/android/internal/util/danda/classes/s3;


# instance fields
.field public final m:Z

.field public final n:I

.field public final o:Lcom/android/internal/util/danda/classes/y;


# direct methods
.method public constructor <init>(ZILcom/android/internal/util/danda/classes/y;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lcom/android/internal/util/danda/classes/z0;->m:Z

    iput p2, p0, Lcom/android/internal/util/danda/classes/z0;->n:I

    iput-object p3, p0, Lcom/android/internal/util/danda/classes/z0;->o:Lcom/android/internal/util/danda/classes/y;

    return-void
.end method


# virtual methods
.method public final b()Lcom/android/internal/util/danda/classes/t;
    .registers 4

    iget-boolean v0, p0, Lcom/android/internal/util/danda/classes/z0;->m:Z

    iget v1, p0, Lcom/android/internal/util/danda/classes/z0;->n:I

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/z0;->o:Lcom/android/internal/util/danda/classes/y;

    invoke-virtual {v2, v0, v1}, Lcom/android/internal/util/danda/classes/y;->b(ZI)Lcom/android/internal/util/danda/classes/a0;

    move-result-object v0

    return-object v0
.end method

.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 3

    :try_start_0
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/z0;->b()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_4} :catch_5

    return-object v0

    :catch_5
    move-exception v0

    new-instance v1, Lcom/android/internal/util/danda/classes/s;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Lcom/android/internal/util/danda/classes/s;-><init>(Ljava/lang/String;)V

    throw v1
.end method

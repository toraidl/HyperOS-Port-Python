.class public interface abstract Lcom/android/internal/util/danda/classes/d6;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lcom/android/internal/util/danda/classes/o;

.field public static final b:Lcom/android/internal/util/danda/classes/o;

.field public static final c:Lcom/android/internal/util/danda/classes/o;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "2.5.4.3"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/o;->q()Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "2.5.4.6"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/o;->q()Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "2.5.4.7"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/o;->q()Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "2.5.4.8"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/o;->q()Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "2.5.4.10"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/o;->q()Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "2.5.4.11"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/o;->q()Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "2.5.4.20"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/o;->q()Lcom/android/internal/util/danda/classes/o;

    move-result-object v0

    sput-object v0, Lcom/android/internal/util/danda/classes/d6;->a:Lcom/android/internal/util/danda/classes/o;

    const-string v0, "2.5.4.41"

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m0;->a(Ljava/lang/String;)Lcom/android/internal/util/danda/classes/o;

    move-result-object v0

    sput-object v0, Lcom/android/internal/util/danda/classes/d6;->b:Lcom/android/internal/util/danda/classes/o;

    const-string v0, "2.5.4.97"

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/m0;->a(Ljava/lang/String;)Lcom/android/internal/util/danda/classes/o;

    move-result-object v0

    sput-object v0, Lcom/android/internal/util/danda/classes/d6;->c:Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.14.3.2.26"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/o;->q()Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.36.3.2.1"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/o;->q()Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.36.3.3.1.2"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/o;->q()Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "2.5.8.1.1"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/o;->q()Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.6.1.5.5.7"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "1"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v3, "2.5.29"

    invoke-direct {v1, v3}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v3, "48"

    invoke-direct {v1, v0, v3}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v3, "2"

    invoke-direct {v0, v1, v3}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/o;->q()Lcom/android/internal/util/danda/classes/o;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v0, v1, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/o;->q()Lcom/android/internal/util/danda/classes/o;

    return-void
.end method

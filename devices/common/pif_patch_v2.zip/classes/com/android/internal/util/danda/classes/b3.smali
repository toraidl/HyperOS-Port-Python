.class public final Lcom/android/internal/util/danda/classes/b3;
.super Lcom/android/internal/util/danda/classes/c3;
.source "SourceFile"


# instance fields
.field public final synthetic g:I


# direct methods
.method public constructor <init>(Lcom/android/internal/util/danda/classes/x2;I)V
    .registers 9

    const/4 v2, 0x0

    const/4 v3, 0x0

    iput p2, p0, Lcom/android/internal/util/danda/classes/b3;->g:I

    const/4 v0, 0x1

    if-eq p2, v0, :cond_f

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, p1

    .line 10
    invoke-direct/range {v0 .. v5}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;ZI)V

    return-void

    :cond_f
    const/4 v4, 0x0

    const/4 v5, 0x1

    move-object v0, p0

    move-object v1, p1

    .line 11
    invoke-direct/range {v0 .. v5}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;ZI)V

    return-void
.end method

.method public constructor <init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;ZI)V
    .registers 9

    iput p5, p0, Lcom/android/internal/util/danda/classes/b3;->g:I

    const-string v0, "Exactly one of the field elements is null"

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eq p5, v2, :cond_2a

    .line 1
    invoke-direct {p0, p1, p2, p3}, Lcom/android/internal/util/danda/classes/c3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)V

    if-nez p2, :cond_f

    move p5, v2

    goto :goto_10

    :cond_f
    move p5, v1

    :goto_10
    if-nez p3, :cond_13

    move v1, v2

    :cond_13
    if-ne p5, v1, :cond_24

    if-eqz p2, :cond_21

    .line 2
    invoke-static {p2, p3}, Lcom/android/internal/util/danda/classes/y2;->r(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)V

    if-eqz p1, :cond_21

    .line 3
    iget-object p1, p1, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    .line 4
    invoke-static {p2, p1}, Lcom/android/internal/util/danda/classes/y2;->r(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)V

    :cond_21
    iput-boolean p4, p0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    return-void

    .line 5
    :cond_24
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 6
    :cond_2a
    invoke-direct {p0, p1, p2, p3}, Lcom/android/internal/util/danda/classes/c3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)V

    if-nez p2, :cond_31

    move p1, v2

    goto :goto_32

    :cond_31
    move p1, v1

    :goto_32
    if-nez p3, :cond_35

    move v1, v2

    :cond_35
    if-ne p1, v1, :cond_3a

    iput-boolean p4, p0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    return-void

    .line 7
    :cond_3a
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public constructor <init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;[Lcom/android/internal/util/danda/classes/a3;ZI)V
    .registers 8

    iput p6, p0, Lcom/android/internal/util/danda/classes/b3;->g:I

    const/4 v0, 0x1

    if-eq p6, v0, :cond_b

    .line 8
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/android/internal/util/danda/classes/c3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;[Lcom/android/internal/util/danda/classes/a3;)V

    iput-boolean p5, p0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    return-void

    .line 9
    :cond_b
    invoke-direct {p0, p1, p2, p3, p4}, Lcom/android/internal/util/danda/classes/c3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;[Lcom/android/internal/util/danda/classes/a3;)V

    iput-boolean p5, p0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    return-void
.end method


# virtual methods
.method public final a(Lcom/android/internal/util/danda/classes/c3;)Lcom/android/internal/util/danda/classes/c3;
    .registers 18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Lcom/android/internal/util/danda/classes/c3;->d:[Lcom/android/internal/util/danda/classes/a3;

    iget-object v3, v0, Lcom/android/internal/util/danda/classes/c3;->c:Lcom/android/internal/util/danda/classes/a3;

    iget-object v4, v0, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    iget-object v6, v0, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    iget v5, v0, Lcom/android/internal/util/danda/classes/b3;->g:I

    const-string v7, "unsupported coordinate system"

    const/4 v8, 0x0

    const/4 v9, 0x1

    packed-switch v5, :pswitch_data_44a

    invoke-virtual/range {p0 .. p0}, Lcom/android/internal/util/danda/classes/c3;->e()Z

    move-result v5

    if-eqz v5, :cond_1d

    goto/16 :goto_22c

    :cond_1d
    invoke-virtual/range {p1 .. p1}, Lcom/android/internal/util/danda/classes/c3;->e()Z

    move-result v5

    if-eqz v5, :cond_26

    move-object v1, v0

    goto/16 :goto_22c

    :cond_26
    if-ne v0, v1, :cond_2e

    invoke-virtual/range {p0 .. p0}, Lcom/android/internal/util/danda/classes/b3;->h()Lcom/android/internal/util/danda/classes/c3;

    move-result-object v1

    goto/16 :goto_22c

    :cond_2e
    iget v5, v6, Lcom/android/internal/util/danda/classes/x2;->e:I

    iget-object v10, v1, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    iget-object v11, v1, Lcom/android/internal/util/danda/classes/c3;->c:Lcom/android/internal/util/danda/classes/a3;

    if-eqz v5, :cond_1e9

    iget-object v1, v1, Lcom/android/internal/util/danda/classes/c3;->d:[Lcom/android/internal/util/danda/classes/a3;

    if-eq v5, v9, :cond_154

    const/4 v12, 0x4

    const/4 v13, 0x2

    if-eq v5, v13, :cond_47

    if-ne v5, v12, :cond_41

    goto :goto_47

    :cond_41
    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-direct {v1, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_47
    :goto_47
    aget-object v2, v2, v8

    aget-object v1, v1, v8

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v7

    if-nez v7, :cond_ac

    invoke-virtual {v2, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_ac

    invoke-virtual {v4, v10}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v3, v11}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v7

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v11

    if-eqz v11, :cond_77

    invoke-virtual {v7}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v1

    if-eqz v1, :cond_71

    invoke-virtual/range {p0 .. p0}, Lcom/android/internal/util/danda/classes/b3;->h()Lcom/android/internal/util/danda/classes/c3;

    move-result-object v1

    goto/16 :goto_22c

    :cond_71
    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/x2;->f()Lcom/android/internal/util/danda/classes/b3;

    move-result-object v1

    goto/16 :goto_22c

    :cond_77
    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v11

    invoke-virtual {v4, v11}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v10, v11}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    invoke-virtual {v4, v10}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v11

    invoke-virtual {v11, v3}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v7}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v11

    invoke-virtual {v11, v4}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v11

    invoke-virtual {v11, v10}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    invoke-virtual {v4, v10}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v4, v7}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v4, v3}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v1, v2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    move-object v8, v3

    move-object v7, v10

    const/4 v14, 0x0

    goto/16 :goto_131

    :cond_ac
    if-eqz v7, :cond_af

    goto :goto_bf

    :cond_af
    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v15

    invoke-virtual {v15, v10}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    invoke-virtual {v15, v2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v15

    invoke-virtual {v15, v11}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v11

    :goto_bf
    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v15

    if-eqz v15, :cond_c6

    goto :goto_d6

    :cond_c6
    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v14

    invoke-virtual {v14, v4}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v14, v1}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v14

    invoke-virtual {v14, v3}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    :goto_d6
    invoke-virtual {v4, v10}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    invoke-virtual {v3, v11}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v11

    invoke-virtual {v10}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v14

    if-eqz v14, :cond_f6

    invoke-virtual {v11}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v1

    if-eqz v1, :cond_f0

    invoke-virtual/range {p0 .. p0}, Lcom/android/internal/util/danda/classes/b3;->h()Lcom/android/internal/util/danda/classes/c3;

    move-result-object v1

    goto/16 :goto_22c

    :cond_f0
    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/x2;->f()Lcom/android/internal/util/danda/classes/b3;

    move-result-object v1

    goto/16 :goto_22c

    :cond_f6
    invoke-virtual {v10}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v14

    invoke-virtual {v14, v10}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v9

    invoke-virtual {v14, v4}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v11}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v8

    invoke-virtual {v8, v9}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v8

    invoke-virtual {v4, v4}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v13

    invoke-virtual {v8, v13}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v8

    invoke-virtual {v4, v8}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v4, v11, v9, v3}, Lcom/android/internal/util/danda/classes/a3;->j(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    if-nez v7, :cond_121

    invoke-virtual {v10, v2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    goto :goto_122

    :cond_121
    move-object v2, v10

    :goto_122
    if-nez v15, :cond_129

    invoke-virtual {v2, v1}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    goto :goto_12a

    :cond_129
    move-object v1, v2

    :goto_12a
    move-object v7, v8

    if-ne v1, v10, :cond_12f

    :goto_12d
    move-object v8, v3

    goto :goto_131

    :cond_12f
    const/4 v14, 0x0

    goto :goto_12d

    :goto_131
    if-ne v5, v12, :cond_142

    invoke-virtual {v0, v1, v14}, Lcom/android/internal/util/danda/classes/b3;->i(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    const/4 v3, 0x2

    new-array v3, v3, [Lcom/android/internal/util/danda/classes/a3;

    const/4 v4, 0x0

    aput-object v1, v3, v4

    const/4 v5, 0x1

    aput-object v2, v3, v5

    move-object v9, v3

    goto :goto_149

    :cond_142
    const/4 v4, 0x0

    const/4 v5, 0x1

    new-array v2, v5, [Lcom/android/internal/util/danda/classes/a3;

    aput-object v1, v2, v4

    move-object v9, v2

    :goto_149
    new-instance v1, Lcom/android/internal/util/danda/classes/b3;

    iget-boolean v10, v0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/4 v11, 0x1

    move-object v5, v1

    invoke-direct/range {v5 .. v11}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;[Lcom/android/internal/util/danda/classes/a3;ZI)V

    goto/16 :goto_22c

    :cond_154
    move v5, v8

    aget-object v2, v2, v5

    aget-object v1, v1, v5

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v5

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v7

    if-eqz v5, :cond_164

    goto :goto_168

    :cond_164
    invoke-virtual {v11, v2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v11

    :goto_168
    if-eqz v7, :cond_16b

    goto :goto_16f

    :cond_16b
    invoke-virtual {v3, v1}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    :goto_16f
    invoke-virtual {v11, v3}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v8

    if-eqz v5, :cond_176

    goto :goto_17a

    :cond_176
    invoke-virtual {v10, v2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    :goto_17a
    if-eqz v7, :cond_17d

    goto :goto_181

    :cond_17d
    invoke-virtual {v4, v1}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    :goto_181
    invoke-virtual {v10, v4}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v9

    invoke-virtual {v9}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v10

    if-eqz v10, :cond_19d

    invoke-virtual {v8}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v1

    if-eqz v1, :cond_197

    invoke-virtual/range {p0 .. p0}, Lcom/android/internal/util/danda/classes/b3;->h()Lcom/android/internal/util/danda/classes/c3;

    move-result-object v1

    goto/16 :goto_22c

    :cond_197
    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/x2;->f()Lcom/android/internal/util/danda/classes/b3;

    move-result-object v1

    goto/16 :goto_22c

    :cond_19d
    if-eqz v5, :cond_1a1

    move-object v2, v1

    goto :goto_1a8

    :cond_1a1
    if-eqz v7, :cond_1a4

    goto :goto_1a8

    :cond_1a4
    invoke-virtual {v2, v1}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    :goto_1a8
    invoke-virtual {v9}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1, v9}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    invoke-virtual {v1, v4}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v8}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v4, v2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v4, v5}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v1, v1}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v7

    invoke-virtual {v4, v7}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v9, v4}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v7

    invoke-virtual {v1, v4}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1, v8, v3, v5}, Lcom/android/internal/util/danda/classes/a3;->j(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v8

    invoke-virtual {v5, v2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    new-instance v2, Lcom/android/internal/util/danda/classes/b3;

    const/4 v3, 0x1

    new-array v9, v3, [Lcom/android/internal/util/danda/classes/a3;

    const/4 v3, 0x0

    aput-object v1, v9, v3

    iget-boolean v10, v0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/4 v11, 0x1

    move-object v5, v2

    invoke-direct/range {v5 .. v11}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;[Lcom/android/internal/util/danda/classes/a3;ZI)V

    move-object v1, v2

    goto :goto_22c

    :cond_1e9
    invoke-virtual {v10, v4}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v11, v3}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v5

    if-eqz v5, :cond_207

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v1

    if-eqz v1, :cond_202

    invoke-virtual/range {p0 .. p0}, Lcom/android/internal/util/danda/classes/b3;->h()Lcom/android/internal/util/danda/classes/c3;

    move-result-object v1

    goto :goto_22c

    :cond_202
    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/x2;->f()Lcom/android/internal/util/danda/classes/b3;

    move-result-object v1

    goto :goto_22c

    :cond_207
    invoke-virtual {v2, v1}, Lcom/android/internal/util/danda/classes/a3;->d(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v2, v4}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v2, v10}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v7

    invoke-virtual {v4, v7}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1, v3}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v8

    new-instance v1, Lcom/android/internal/util/danda/classes/b3;

    iget-boolean v9, v0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/4 v10, 0x1

    move-object v5, v1

    invoke-direct/range {v5 .. v10}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;ZI)V

    :goto_22c
    return-object v1

    :pswitch_22d
    invoke-virtual/range {p0 .. p0}, Lcom/android/internal/util/danda/classes/c3;->e()Z

    move-result v5

    if-eqz v5, :cond_235

    goto/16 :goto_448

    :cond_235
    invoke-virtual/range {p1 .. p1}, Lcom/android/internal/util/danda/classes/c3;->e()Z

    move-result v5

    if-eqz v5, :cond_23e

    move-object v1, v0

    goto/16 :goto_448

    :cond_23e
    iget v5, v6, Lcom/android/internal/util/danda/classes/x2;->e:I

    iget-object v8, v1, Lcom/android/internal/util/danda/classes/c3;->c:Lcom/android/internal/util/danda/classes/a3;

    iget-object v9, v1, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    if-eqz v5, :cond_3fb

    iget-object v10, v1, Lcom/android/internal/util/danda/classes/c3;->d:[Lcom/android/internal/util/danda/classes/a3;

    const/4 v11, 0x1

    if-eq v5, v11, :cond_370

    const/4 v11, 0x6

    if-ne v5, v11, :cond_36a

    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v5

    if-eqz v5, :cond_266

    invoke-virtual {v9}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v2

    if-eqz v2, :cond_260

    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/x2;->f()Lcom/android/internal/util/danda/classes/b3;

    move-result-object v1

    goto/16 :goto_448

    :cond_260
    invoke-virtual {v1, v0}, Lcom/android/internal/util/danda/classes/c3;->a(Lcom/android/internal/util/danda/classes/c3;)Lcom/android/internal/util/danda/classes/c3;

    move-result-object v1

    goto/16 :goto_448

    :cond_266
    const/4 v1, 0x0

    aget-object v2, v2, v1

    aget-object v5, v10, v1

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v1

    if-nez v1, :cond_27a

    invoke-virtual {v9, v2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v7

    invoke-virtual {v8, v2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    goto :goto_27c

    :cond_27a
    move-object v10, v8

    move-object v7, v9

    :goto_27c
    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v11

    if-nez v11, :cond_28b

    invoke-virtual {v4, v5}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v3, v5}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v12

    goto :goto_28c

    :cond_28b
    move-object v12, v3

    :goto_28c
    invoke-virtual {v12, v10}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    invoke-virtual {v4, v7}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v12

    invoke-virtual {v12}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v13

    if-eqz v13, :cond_2ac

    invoke-virtual {v10}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v1

    if-eqz v1, :cond_2a6

    invoke-virtual/range {p0 .. p0}, Lcom/android/internal/util/danda/classes/b3;->h()Lcom/android/internal/util/danda/classes/c3;

    move-result-object v1

    goto/16 :goto_448

    :cond_2a6
    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/x2;->f()Lcom/android/internal/util/danda/classes/b3;

    move-result-object v1

    goto/16 :goto_448

    :cond_2ac
    invoke-virtual {v9}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v9

    if-eqz v9, :cond_30d

    invoke-virtual/range {p0 .. p0}, Lcom/android/internal/util/danda/classes/c3;->f()Lcom/android/internal/util/danda/classes/c3;

    move-result-object v1

    iget-object v2, v1, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/c3;->c()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1, v8}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v3, v2}, Lcom/android/internal/util/danda/classes/a3;->d(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v4, v3}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v4, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    iget-object v5, v6, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v4, v5}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v7

    invoke-virtual {v7}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v4

    if-eqz v4, :cond_2ed

    new-instance v1, Lcom/android/internal/util/danda/classes/b3;

    iget-object v2, v6, Lcom/android/internal/util/danda/classes/x2;->c:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->m()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v8

    iget-boolean v9, v0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/4 v10, 0x0

    move-object v5, v1

    invoke-direct/range {v5 .. v10}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;ZI)V

    goto/16 :goto_448

    :cond_2ed
    invoke-virtual {v2, v7}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v3, v2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v2, v7}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v2, v1}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1, v7}, Lcom/android/internal/util/danda/classes/a3;->d(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1, v7}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    sget-object v2, Lcom/android/internal/util/danda/classes/u2;->b:Ljava/math/BigInteger;

    invoke-virtual {v6, v2}, Lcom/android/internal/util/danda/classes/x2;->d(Ljava/math/BigInteger;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    move-object v8, v1

    goto :goto_359

    :cond_30d
    invoke-virtual {v12}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v8

    invoke-virtual {v10, v4}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v10, v7}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v7

    invoke-virtual {v4, v7}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v9

    if-eqz v9, :cond_335

    new-instance v1, Lcom/android/internal/util/danda/classes/b3;

    iget-object v2, v6, Lcom/android/internal/util/danda/classes/x2;->c:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->m()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v8

    iget-boolean v9, v0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/4 v10, 0x0

    move-object v5, v1

    move-object v7, v4

    invoke-direct/range {v5 .. v10}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;ZI)V

    goto/16 :goto_448

    :cond_335
    invoke-virtual {v10, v8}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v9

    if-nez v11, :cond_340

    invoke-virtual {v9, v5}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    goto :goto_341

    :cond_340
    move-object v5, v9

    :goto_341
    invoke-virtual {v7, v8}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v7

    invoke-virtual {v3, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v7, v5, v3}, Lcom/android/internal/util/danda/classes/a3;->o(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    if-nez v1, :cond_356

    invoke-virtual {v5, v2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    move-object v8, v3

    move-object v7, v4

    goto :goto_359

    :cond_356
    move-object v8, v3

    move-object v7, v4

    move-object v2, v5

    :goto_359
    new-instance v1, Lcom/android/internal/util/danda/classes/b3;

    const/4 v3, 0x1

    new-array v9, v3, [Lcom/android/internal/util/danda/classes/a3;

    const/4 v3, 0x0

    aput-object v2, v9, v3

    iget-boolean v10, v0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/4 v11, 0x0

    move-object v5, v1

    invoke-direct/range {v5 .. v11}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;[Lcom/android/internal/util/danda/classes/a3;ZI)V

    goto/16 :goto_448

    :cond_36a
    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-direct {v1, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_370
    const/4 v1, 0x0

    aget-object v2, v2, v1

    aget-object v5, v10, v1

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v1

    invoke-virtual {v2, v8}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v7

    if-eqz v1, :cond_381

    move-object v8, v3

    goto :goto_385

    :cond_381
    invoke-virtual {v3, v5}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v8

    :goto_385
    invoke-virtual {v7, v8}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v7

    invoke-virtual {v2, v9}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v8

    if-eqz v1, :cond_391

    move-object v9, v4

    goto :goto_395

    :cond_391
    invoke-virtual {v4, v5}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v9

    :goto_395
    invoke-virtual {v8, v9}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v8

    invoke-virtual {v8}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v9

    if-eqz v9, :cond_3b1

    invoke-virtual {v7}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v1

    if-eqz v1, :cond_3ab

    invoke-virtual/range {p0 .. p0}, Lcom/android/internal/util/danda/classes/b3;->h()Lcom/android/internal/util/danda/classes/c3;

    move-result-object v1

    goto/16 :goto_448

    :cond_3ab
    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/x2;->f()Lcom/android/internal/util/danda/classes/b3;

    move-result-object v1

    goto/16 :goto_448

    :cond_3b1
    invoke-virtual {v8}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v9

    invoke-virtual {v9, v8}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    if-eqz v1, :cond_3bc

    goto :goto_3c0

    :cond_3bc
    invoke-virtual {v2, v5}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    :goto_3c0
    invoke-virtual {v7, v8}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v11

    iget-object v12, v6, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v11, v7, v9, v12}, Lcom/android/internal/util/danda/classes/a3;->k(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v12

    invoke-virtual {v12, v2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v12

    invoke-virtual {v12, v10}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v12

    invoke-virtual {v8, v12}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v13

    if-eqz v1, :cond_3d9

    goto :goto_3dd

    :cond_3d9
    invoke-virtual {v9, v5}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v9

    :goto_3dd
    invoke-virtual {v7, v4, v8, v3}, Lcom/android/internal/util/danda/classes/a3;->k(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1, v9, v11, v12}, Lcom/android/internal/util/danda/classes/a3;->k(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v8

    invoke-virtual {v10, v2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    new-instance v2, Lcom/android/internal/util/danda/classes/b3;

    const/4 v3, 0x1

    new-array v9, v3, [Lcom/android/internal/util/danda/classes/a3;

    const/4 v3, 0x0

    aput-object v1, v9, v3

    iget-boolean v10, v0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/4 v11, 0x0

    move-object v5, v2

    move-object v7, v13

    invoke-direct/range {v5 .. v11}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;[Lcom/android/internal/util/danda/classes/a3;ZI)V

    move-object v1, v2

    goto :goto_448

    :cond_3fb
    invoke-virtual {v4, v9}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v3, v8}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v5

    if-eqz v5, :cond_419

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v1

    if-eqz v1, :cond_414

    invoke-virtual/range {p0 .. p0}, Lcom/android/internal/util/danda/classes/b3;->h()Lcom/android/internal/util/danda/classes/c3;

    move-result-object v1

    goto :goto_448

    :cond_414
    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/x2;->f()Lcom/android/internal/util/danda/classes/b3;

    move-result-object v1

    goto :goto_448

    :cond_419
    invoke-virtual {v2, v1}, Lcom/android/internal/util/danda/classes/a3;->d(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    invoke-virtual {v5, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    invoke-virtual {v5, v1}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    iget-object v5, v6, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v1, v5}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v7

    invoke-virtual {v4, v7}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v2, v1}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1, v7}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1, v3}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v8

    new-instance v1, Lcom/android/internal/util/danda/classes/b3;

    iget-boolean v9, v0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/4 v10, 0x0

    move-object v5, v1

    invoke-direct/range {v5 .. v10}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;ZI)V

    :goto_448
    return-object v1

    nop

    :pswitch_data_44a
    .packed-switch 0x0
        :pswitch_22d
    .end packed-switch
.end method

.method public final c()Lcom/android/internal/util/danda/classes/a3;
    .registers 6

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/c3;->c:Lcom/android/internal/util/danda/classes/a3;

    iget v1, p0, Lcom/android/internal/util/danda/classes/b3;->g:I

    packed-switch v1, :pswitch_data_3c

    return-object v0

    :pswitch_8
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/c3;->b()I

    move-result v1

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eq v1, v2, :cond_13

    if-eq v1, v3, :cond_13

    goto :goto_3b

    :cond_13
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/c3;->e()Z

    move-result v2

    if-nez v2, :cond_3b

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v4

    if-eqz v4, :cond_22

    goto :goto_3b

    :cond_22
    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v0

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v0

    if-ne v3, v1, :cond_3b

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/c3;->d:[Lcom/android/internal/util/danda/classes/a3;

    const/4 v2, 0x0

    aget-object v1, v1, v2

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v2

    if-nez v2, :cond_3b

    invoke-virtual {v0, v1}, Lcom/android/internal/util/danda/classes/a3;->d(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v0

    :cond_3b
    :goto_3b
    return-object v0

    :pswitch_data_3c
    .packed-switch 0x0
        :pswitch_8
    .end packed-switch
.end method

.method public final d()Lcom/android/internal/util/danda/classes/a3;
    .registers 5

    iget v0, p0, Lcom/android/internal/util/danda/classes/b3;->g:I

    const/4 v1, 0x0

    const/4 v2, 0x0

    packed-switch v0, :pswitch_data_1a

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/c3;->d:[Lcom/android/internal/util/danda/classes/a3;

    array-length v3, v0

    if-gtz v3, :cond_d

    goto :goto_f

    :cond_d
    aget-object v2, v0, v1

    :goto_f
    return-object v2

    :pswitch_10
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/c3;->d:[Lcom/android/internal/util/danda/classes/a3;

    array-length v3, v0

    if-gtz v3, :cond_16

    goto :goto_18

    :cond_16
    aget-object v2, v0, v1

    :goto_18
    return-object v2

    nop

    :pswitch_data_1a
    .packed-switch 0x1
        :pswitch_10
    .end packed-switch
.end method

.method public final h()Lcom/android/internal/util/danda/classes/c3;
    .registers 20

    move-object/from16 v0, p0

    iget-object v1, v0, Lcom/android/internal/util/danda/classes/c3;->d:[Lcom/android/internal/util/danda/classes/a3;

    iget-object v2, v0, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    iget-object v4, v0, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    iget-object v3, v0, Lcom/android/internal/util/danda/classes/c3;->c:Lcom/android/internal/util/danda/classes/a3;

    iget v5, v0, Lcom/android/internal/util/danda/classes/b3;->g:I

    const-string v6, "unsupported coordinate system"

    const/4 v7, 0x0

    const/4 v8, 0x1

    packed-switch v5, :pswitch_data_3e2

    invoke-virtual/range {p0 .. p0}, Lcom/android/internal/util/danda/classes/c3;->e()Z

    move-result v5

    if-eqz v5, :cond_1c

    move-object v1, v0

    goto/16 :goto_262

    :cond_1c
    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v5

    if-eqz v5, :cond_28

    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/x2;->f()Lcom/android/internal/util/danda/classes/b3;

    move-result-object v1

    goto/16 :goto_262

    :cond_28
    iget v5, v4, Lcom/android/internal/util/danda/classes/x2;->e:I

    if-eqz v5, :cond_227

    if-eq v5, v8, :cond_18f

    const/4 v9, 0x2

    if-eq v5, v9, :cond_b6

    const/4 v4, 0x4

    if-ne v5, v4, :cond_b0

    aget-object v1, v1, v7

    iget-object v4, v0, Lcom/android/internal/util/danda/classes/c3;->d:[Lcom/android/internal/util/danda/classes/a3;

    aget-object v5, v4, v8

    if-nez v5, :cond_45

    aget-object v5, v4, v7

    const/4 v6, 0x0

    invoke-virtual {v0, v5, v6}, Lcom/android/internal/util/danda/classes/b3;->i(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    aput-object v5, v4, v8

    :cond_45
    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v4, v4}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    invoke-virtual {v6, v4}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v4, v5}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    invoke-virtual {v3, v3}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    invoke-virtual {v6, v3}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v2, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    invoke-virtual {v2, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v11

    invoke-virtual {v10, v11}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v14

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v3, v3}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v2, v14}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v4, v2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v2, v3}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v15

    invoke-virtual {v3, v5}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v2, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v3

    if-eqz v3, :cond_94

    goto :goto_98

    :cond_94
    invoke-virtual {v6, v1}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    :goto_98
    new-instance v1, Lcom/android/internal/util/danda/classes/b3;

    iget-object v13, v0, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    new-array v3, v9, [Lcom/android/internal/util/danda/classes/a3;

    aput-object v6, v3, v7

    aput-object v2, v3, v8

    iget-boolean v2, v0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/16 v18, 0x1

    move-object v12, v1

    move-object/from16 v16, v3

    move/from16 v17, v2

    invoke-direct/range {v12 .. v18}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;[Lcom/android/internal/util/danda/classes/a3;ZI)V

    goto/16 :goto_262

    :cond_b0
    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-direct {v1, v6}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_b6
    aget-object v1, v1, v7

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v5

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v9

    iget-object v10, v4, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v10}, Lcom/android/internal/util/danda/classes/a3;->l()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v11

    invoke-virtual {v11}, Lcom/android/internal/util/danda/classes/a3;->q()Ljava/math/BigInteger;

    move-result-object v12

    const-wide/16 v13, 0x3

    invoke-static {v13, v14}, Ljava/math/BigInteger;->valueOf(J)Ljava/math/BigInteger;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/math/BigInteger;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_103

    if-eqz v5, :cond_de

    move-object v10, v1

    goto :goto_e2

    :cond_de
    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    :goto_e2
    invoke-virtual {v2, v10}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v11

    invoke-virtual {v2, v10}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    invoke-virtual {v11, v10}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    invoke-virtual {v10, v10}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v11

    invoke-virtual {v11, v10}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    invoke-virtual {v6, v2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v2, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v2, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    goto :goto_14d

    :cond_103
    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v12

    invoke-virtual {v12, v12}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v13

    invoke-virtual {v13, v12}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v12

    if-eqz v5, :cond_116

    invoke-virtual {v12, v10}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    goto :goto_141

    :cond_116
    invoke-virtual {v10}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v13

    if-nez v13, :cond_140

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v13

    invoke-virtual {v13}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v13

    invoke-virtual {v11}, Lcom/android/internal/util/danda/classes/a3;->c()I

    move-result v14

    invoke-virtual {v10}, Lcom/android/internal/util/danda/classes/a3;->c()I

    move-result v15

    if-ge v14, v15, :cond_137

    invoke-virtual {v13, v11}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    invoke-virtual {v12, v10}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    goto :goto_141

    :cond_137
    invoke-virtual {v13, v10}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    invoke-virtual {v12, v10}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    goto :goto_141

    :cond_140
    move-object v10, v12

    :goto_141
    invoke-virtual {v2, v6}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v2, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v2, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    :goto_14d
    invoke-virtual {v10}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    invoke-virtual {v2, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v11

    invoke-virtual {v6, v11}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    invoke-virtual {v2, v6}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v2, v10}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v9, v9}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v9

    invoke-virtual {v9, v9}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v9

    invoke-virtual {v9, v9}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v9

    invoke-virtual {v2, v9}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v3, v3}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    if-nez v5, :cond_17b

    invoke-virtual {v3, v1}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    :cond_17b
    new-instance v1, Lcom/android/internal/util/danda/classes/b3;

    new-array v8, v8, [Lcom/android/internal/util/danda/classes/a3;

    aput-object v3, v8, v7

    iget-boolean v9, v0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/4 v10, 0x1

    move-object v3, v1

    move-object v5, v6

    move-object v6, v2

    move-object v7, v8

    move v8, v9

    move v9, v10

    invoke-direct/range {v3 .. v9}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;[Lcom/android/internal/util/danda/classes/a3;ZI)V

    goto/16 :goto_262

    :cond_18f
    aget-object v1, v1, v7

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v5

    iget-object v6, v4, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v9

    if-nez v9, :cond_1a7

    if-nez v5, :cond_1a7

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v9

    invoke-virtual {v6, v9}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    :cond_1a7
    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v9

    invoke-virtual {v9, v9}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    invoke-virtual {v10, v9}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v9

    invoke-virtual {v6, v9}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    if-eqz v5, :cond_1bb

    move-object v1, v3

    goto :goto_1bf

    :cond_1bb
    invoke-virtual {v3, v1}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    :goto_1bf
    if-eqz v5, :cond_1c6

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    goto :goto_1ca

    :cond_1c6
    invoke-virtual {v1, v3}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    :goto_1ca
    invoke-virtual {v2, v3}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v2, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v2, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v9

    invoke-virtual {v2, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    invoke-virtual {v9, v10}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v9

    invoke-virtual {v1, v1}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    invoke-virtual {v9, v10}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v11

    invoke-virtual {v3, v3}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v2, v9}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v2, v6}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    invoke-virtual {v6, v6}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    invoke-virtual {v2, v6}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    if-eqz v5, :cond_209

    invoke-virtual {v3, v3}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    goto :goto_20d

    :cond_209
    invoke-virtual {v10}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    :goto_20d
    invoke-virtual {v2, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v2, v1}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    new-instance v2, Lcom/android/internal/util/danda/classes/b3;

    new-array v8, v8, [Lcom/android/internal/util/danda/classes/a3;

    aput-object v1, v8, v7

    iget-boolean v1, v0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/4 v9, 0x1

    move-object v3, v2

    move-object v5, v11

    move-object v7, v8

    move v8, v1

    invoke-direct/range {v3 .. v9}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;[Lcom/android/internal/util/danda/classes/a3;ZI)V

    move-object v1, v2

    goto :goto_262

    :cond_227
    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1, v1}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    invoke-virtual {v5, v1}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    iget-object v5, v4, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v1, v5}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v3, v3}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    invoke-virtual {v1, v5}, Lcom/android/internal/util/danda/classes/a3;->d(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    invoke-virtual {v2, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    invoke-virtual {v2, v5}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1, v3}, Lcom/android/internal/util/danda/classes/a3;->p(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    new-instance v1, Lcom/android/internal/util/danda/classes/b3;

    iget-boolean v7, v0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/4 v8, 0x1

    move-object v3, v1

    invoke-direct/range {v3 .. v8}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;ZI)V

    :goto_262
    return-object v1

    :pswitch_263
    invoke-virtual/range {p0 .. p0}, Lcom/android/internal/util/danda/classes/c3;->e()Z

    move-result v5

    if-eqz v5, :cond_26c

    move-object v1, v0

    goto/16 :goto_3e0

    :cond_26c
    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v5

    if-eqz v5, :cond_278

    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/x2;->f()Lcom/android/internal/util/danda/classes/b3;

    move-result-object v1

    goto/16 :goto_3e0

    :cond_278
    iget v5, v4, Lcom/android/internal/util/danda/classes/x2;->e:I

    if-eqz v5, :cond_3b5

    if-eq v5, v8, :cond_360

    const/4 v9, 0x6

    if-ne v5, v9, :cond_35a

    aget-object v1, v1, v7

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v5

    if-eqz v5, :cond_28b

    move-object v6, v3

    goto :goto_28f

    :cond_28b
    invoke-virtual {v3, v1}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    :goto_28f
    if-eqz v5, :cond_293

    move-object v9, v1

    goto :goto_297

    :cond_293
    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v9

    :goto_297
    iget-object v10, v4, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    if-eqz v5, :cond_29d

    move-object v11, v10

    goto :goto_2a1

    :cond_29d
    invoke-virtual {v10, v9}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v11

    :goto_2a1
    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v12

    invoke-virtual {v12, v6}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v12

    invoke-virtual {v12, v11}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v12

    invoke-virtual {v12}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v13

    if-eqz v13, :cond_2c5

    new-instance v1, Lcom/android/internal/util/danda/classes/b3;

    iget-object v2, v4, Lcom/android/internal/util/danda/classes/x2;->c:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->m()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    iget-boolean v7, v0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/4 v8, 0x0

    move-object v3, v1

    move-object v5, v12

    invoke-direct/range {v3 .. v8}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;ZI)V

    goto/16 :goto_3e0

    :cond_2c5
    invoke-virtual {v12}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v13

    if-eqz v5, :cond_2cd

    move-object v14, v12

    goto :goto_2d1

    :cond_2cd
    invoke-virtual {v12, v9}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v14

    :goto_2d1
    iget-object v15, v4, Lcom/android/internal/util/danda/classes/x2;->c:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v15}, Lcom/android/internal/util/danda/classes/a3;->c()I

    move-result v7

    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/x2;->e()I

    move-result v17

    move-object/from16 v18, v4

    shr-int/lit8 v4, v17, 0x1

    if-ge v7, v4, :cond_333

    invoke-virtual {v3, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v15}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v2

    if-eqz v2, :cond_2f8

    invoke-virtual {v11, v9}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    goto :goto_300

    :cond_2f8
    invoke-virtual {v9}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v11, v15, v2}, Lcom/android/internal/util/danda/classes/a3;->o(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    :goto_300
    invoke-virtual {v1, v12}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v3, v9}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v3, v1}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1, v13}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v10}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v2

    if-eqz v2, :cond_31f

    invoke-virtual {v1, v14}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    goto :goto_331

    :cond_31f
    invoke-virtual {v10}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v2

    if-nez v2, :cond_331

    invoke-virtual {v10}, Lcom/android/internal/util/danda/classes/a3;->b()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v2, v14}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    :cond_331
    :goto_331
    move-object v6, v1

    goto :goto_347

    :cond_333
    if-eqz v5, :cond_336

    goto :goto_33a

    :cond_336
    invoke-virtual {v2, v1}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    :goto_33a
    invoke-virtual {v2, v12, v6}, Lcom/android/internal/util/danda/classes/a3;->o(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1, v13}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1, v14}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    goto :goto_331

    :goto_347
    new-instance v1, Lcom/android/internal/util/danda/classes/b3;

    new-array v7, v8, [Lcom/android/internal/util/danda/classes/a3;

    const/4 v2, 0x0

    aput-object v14, v7, v2

    iget-boolean v8, v0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/4 v9, 0x0

    move-object v3, v1

    move-object/from16 v4, v18

    move-object v5, v13

    invoke-direct/range {v3 .. v9}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;[Lcom/android/internal/util/danda/classes/a3;ZI)V

    goto/16 :goto_3e0

    :cond_35a
    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-direct {v1, v6}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_360
    move-object/from16 v18, v4

    move v4, v7

    aget-object v1, v1, v4

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v4

    if-eqz v4, :cond_36d

    move-object v5, v2

    goto :goto_371

    :cond_36d
    invoke-virtual {v2, v1}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    :goto_371
    if-eqz v4, :cond_374

    goto :goto_378

    :cond_374
    invoke-virtual {v3, v1}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    :goto_378
    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1, v3}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v2, v5}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v4

    move-object/from16 v6, v18

    iget-object v7, v6, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v4, v2, v3, v7}, Lcom/android/internal/util/danda/classes/a3;->k(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    invoke-virtual {v5, v2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v7

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1, v5, v2, v4}, Lcom/android/internal/util/danda/classes/a3;->k(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v5, v3}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    new-instance v10, Lcom/android/internal/util/danda/classes/b3;

    new-array v8, v8, [Lcom/android/internal/util/danda/classes/a3;

    const/4 v3, 0x0

    aput-object v2, v8, v3

    iget-boolean v2, v0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/4 v9, 0x0

    move-object v3, v10

    move-object v4, v6

    move-object v5, v7

    move-object v6, v1

    move-object v7, v8

    move v8, v2

    invoke-direct/range {v3 .. v9}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;[Lcom/android/internal/util/danda/classes/a3;ZI)V

    move-object v1, v10

    goto :goto_3e0

    :cond_3b5
    move-object v6, v4

    invoke-virtual {v3, v2}, Lcom/android/internal/util/danda/classes/a3;->d(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1, v2}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    invoke-virtual {v3, v1}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    iget-object v4, v6, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v3, v4}, Lcom/android/internal/util/danda/classes/a3;->a(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v5

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a3;->b()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v2, v5, v1}, Lcom/android/internal/util/danda/classes/a3;->o(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    new-instance v2, Lcom/android/internal/util/danda/classes/b3;

    iget-boolean v7, v0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    const/4 v8, 0x0

    move-object v3, v2

    move-object v4, v6

    move-object v6, v1

    invoke-direct/range {v3 .. v8}, Lcom/android/internal/util/danda/classes/b3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;ZI)V

    move-object v1, v2

    :goto_3e0
    return-object v1

    nop

    :pswitch_data_3e2
    .packed-switch 0x0
        :pswitch_263
    .end packed-switch
.end method

.method public final i(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;
    .registers 6

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    iget-object v0, v0, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v1

    if-nez v1, :cond_37

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v1

    if-eqz v1, :cond_11

    goto :goto_37

    :cond_11
    if-nez p2, :cond_17

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object p2

    :cond_17
    invoke-virtual {p2}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object p1

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/a3;->l()Lcom/android/internal/util/danda/classes/a3;

    move-result-object p2

    invoke-virtual {p2}, Lcom/android/internal/util/danda/classes/a3;->c()I

    move-result v1

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/a3;->c()I

    move-result v2

    if-ge v1, v2, :cond_32

    invoke-virtual {p1, p2}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object p1

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/a3;->l()Lcom/android/internal/util/danda/classes/a3;

    move-result-object p1

    goto :goto_36

    :cond_32
    invoke-virtual {p1, v0}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object p1

    :goto_36
    return-object p1

    :cond_37
    :goto_37
    return-object v0
.end method

.class public final Lcom/android/internal/util/danda/classes/y5;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .registers 5

    const/4 v0, 0x4

    if-eq p1, v0, :cond_15

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance p1, Ljava/util/Hashtable;

    invoke-direct {p1}, Ljava/util/Hashtable;-><init>()V

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/y5;->b:Ljava/lang/Object;

    .line 3
    new-instance p1, Ljava/util/Vector;

    invoke-direct {p1}, Ljava/util/Vector;-><init>()V

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    return-void

    .line 4
    :cond_15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 p1, 0x10

    new-array p1, p1, [B

    fill-array-data p1, :array_7e

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/y5;->b:Ljava/lang/Object;

    const/16 p1, 0x80

    new-array p1, p1, [B

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    const/4 p1, 0x0

    move v0, p1

    :goto_29
    iget-object v1, p0, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    check-cast v1, [B

    .line 5
    array-length v2, v1

    if-ge v0, v2, :cond_36

    const/4 v2, -0x1

    .line 6
    aput-byte v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_29

    :cond_36
    :goto_36
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y5;->b:Ljava/lang/Object;

    check-cast v0, [B

    .line 7
    array-length v1, v0

    if-ge p1, v1, :cond_49

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    check-cast v1, [B

    .line 8
    aget-byte v0, v0, p1

    int-to-byte v2, p1

    aput-byte v2, v1, v0

    add-int/lit8 p1, p1, 0x1

    goto :goto_36

    :cond_49
    iget-object p1, p0, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    check-cast p1, [B

    const/16 v0, 0x61

    .line 9
    aget-byte v0, p1, v0

    const/16 v1, 0x41

    aput-byte v0, p1, v1

    const/16 v0, 0x62

    .line 10
    aget-byte v0, p1, v0

    const/16 v1, 0x42

    aput-byte v0, p1, v1

    const/16 v0, 0x63

    .line 11
    aget-byte v0, p1, v0

    const/16 v1, 0x43

    aput-byte v0, p1, v1

    const/16 v0, 0x64

    .line 12
    aget-byte v0, p1, v0

    const/16 v1, 0x44

    aput-byte v0, p1, v1

    const/16 v0, 0x65

    .line 13
    aget-byte v0, p1, v0

    const/16 v1, 0x45

    aput-byte v0, p1, v1

    const/16 v0, 0x66

    .line 14
    aget-byte v0, p1, v0

    const/16 v1, 0x46

    aput-byte v0, p1, v1

    return-void

    :array_7e
    .array-data 1
        0x30t
        0x31t
        0x32t
        0x33t
        0x34t
        0x35t
        0x36t
        0x37t
        0x38t
        0x39t
        0x61t
        0x62t
        0x63t
        0x64t
        0x65t
        0x66t
    .end array-data
.end method

.method public constructor <init>(Lcom/android/internal/util/danda/classes/x5;Ljava/math/BigInteger;Ljava/util/Date;Ljava/util/Date;Lcom/android/internal/util/danda/classes/x5;Lcom/android/internal/util/danda/classes/q5;)V
    .registers 12

    .line 36
    new-instance v0, Lcom/android/internal/util/danda/classes/u5;

    invoke-direct {v0, p3}, Lcom/android/internal/util/danda/classes/u5;-><init>(Ljava/util/Date;)V

    new-instance p3, Lcom/android/internal/util/danda/classes/u5;

    invoke-direct {p3, p4}, Lcom/android/internal/util/danda/classes/u5;-><init>(Ljava/util/Date;)V

    .line 37
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 38
    new-instance p4, Lcom/android/internal/util/danda/classes/w5;

    .line 39
    invoke-direct {p4}, Ljava/lang/Object;-><init>()V

    .line 40
    new-instance v1, Lcom/android/internal/util/danda/classes/g2;

    new-instance v2, Lcom/android/internal/util/danda/classes/k;

    const-wide/16 v3, 0x2

    invoke-direct {v2, v3, v4}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    const/4 v3, 0x1

    const/4 v4, 0x0

    .line 41
    invoke-direct {v1, v3, v4, v2}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    iput-object v1, p4, Lcom/android/internal/util/danda/classes/w5;->a:Lcom/android/internal/util/danda/classes/g2;

    iput-object p4, p0, Lcom/android/internal/util/danda/classes/y5;->b:Ljava/lang/Object;

    .line 42
    new-instance v1, Lcom/android/internal/util/danda/classes/k;

    invoke-direct {v1, p2}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    iput-object v1, p4, Lcom/android/internal/util/danda/classes/w5;->b:Lcom/android/internal/util/danda/classes/k;

    iget-object p2, p0, Lcom/android/internal/util/danda/classes/y5;->b:Ljava/lang/Object;

    check-cast p2, Lcom/android/internal/util/danda/classes/w5;

    .line 43
    iput-object p1, p2, Lcom/android/internal/util/danda/classes/w5;->d:Lcom/android/internal/util/danda/classes/x5;

    .line 44
    iput-object v0, p2, Lcom/android/internal/util/danda/classes/w5;->e:Lcom/android/internal/util/danda/classes/u5;

    .line 45
    iput-object p3, p2, Lcom/android/internal/util/danda/classes/w5;->f:Lcom/android/internal/util/danda/classes/u5;

    .line 46
    iput-object p5, p2, Lcom/android/internal/util/danda/classes/w5;->g:Lcom/android/internal/util/danda/classes/x5;

    .line 47
    iput-object p6, p2, Lcom/android/internal/util/danda/classes/w5;->h:Lcom/android/internal/util/danda/classes/q5;

    .line 48
    new-instance p1, Lcom/android/internal/util/danda/classes/y5;

    invoke-direct {p1, v3}, Lcom/android/internal/util/danda/classes/y5;-><init>(I)V

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>([B)V
    .registers 5

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    new-instance v0, Lcom/android/internal/util/danda/classes/j;

    invoke-direct {v0, p1}, Lcom/android/internal/util/danda/classes/j;-><init>([B)V

    .line 17
    new-instance p1, Lcom/android/internal/util/danda/classes/c6;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/j;->f()Lcom/android/internal/util/danda/classes/t;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/m;->e()[B

    move-result-object v1

    invoke-direct {p1, v1}, Lcom/android/internal/util/danda/classes/c6;-><init>([B)V

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/y5;->b:Ljava/lang/Object;

    .line 18
    new-instance p1, Lcom/android/internal/util/danda/classes/j1;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/j;->f()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/m;->e()[B

    move-result-object v0

    .line 19
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 20
    invoke-static {v0}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object v0

    .line 21
    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/u;->q()Ljava/util/Enumeration;

    move-result-object v0

    :cond_2c
    :goto_2c
    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v1

    if-eqz v1, :cond_96

    .line 22
    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/e;

    .line 23
    instance-of v2, v1, Lcom/android/internal/util/danda/classes/u;

    if-eqz v2, :cond_40

    .line 24
    invoke-static {v1}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    goto :goto_2c

    .line 25
    :cond_40
    instance-of v2, v1, Lcom/android/internal/util/danda/classes/a0;

    if-eqz v2, :cond_4b

    .line 26
    check-cast v1, Lcom/android/internal/util/danda/classes/a0;

    const/4 v2, 0x0

    invoke-static {v1, v2}, Lcom/android/internal/util/danda/classes/u;->n(Lcom/android/internal/util/danda/classes/a0;Z)Lcom/android/internal/util/danda/classes/u;

    goto :goto_2c

    .line 27
    :cond_4b
    instance-of v2, v1, Lcom/android/internal/util/danda/classes/i2;

    if-eqz v2, :cond_2c

    if-eqz v1, :cond_90

    .line 28
    instance-of v2, v1, Lcom/android/internal/util/danda/classes/i2;

    if-eqz v2, :cond_56

    goto :goto_90

    .line 29
    :cond_56
    instance-of v2, v1, [B

    if-eqz v2, :cond_7c

    .line 30
    :try_start_5a
    check-cast v1, [B

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/t;->j([B)Lcom/android/internal/util/danda/classes/t;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/i2;
    :try_end_62
    .catch Ljava/lang/Exception; {:try_start_5a .. :try_end_62} :catch_63

    goto :goto_92

    :catch_63
    move-exception p1

    .line 31
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "encoding error in getInstance: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 32
    :cond_7c
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 33
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "illegal object in getInstance: "

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 34
    :cond_90
    :goto_90
    check-cast v1, Lcom/android/internal/util/danda/classes/i2;

    .line 35
    :goto_92
    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/i2;->a()Ljava/lang/String;

    goto :goto_2c

    :cond_96
    iput-object p1, p0, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    return-void
.end method

.method public static d(C)Z
    .registers 2

    const/16 v0, 0xa

    if-eq p0, v0, :cond_13

    const/16 v0, 0xd

    if-eq p0, v0, :cond_13

    const/16 v0, 0x9

    if-eq p0, v0, :cond_13

    const/16 v0, 0x20

    if-ne p0, v0, :cond_11

    goto :goto_13

    :cond_11
    const/4 p0, 0x0

    goto :goto_14

    :cond_13
    :goto_13
    const/4 p0, 0x1

    :goto_14
    return p0
.end method


# virtual methods
.method public final a(Lcom/android/internal/util/danda/classes/f3;)V
    .registers 5

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    check-cast v0, Lcom/android/internal/util/danda/classes/y5;

    iget-object v1, v0, Lcom/android/internal/util/danda/classes/y5;->b:Ljava/lang/Object;

    check-cast v1, Ljava/util/Hashtable;

    iget-object v2, p1, Lcom/android/internal/util/danda/classes/f3;->m:Lcom/android/internal/util/danda/classes/o;

    invoke-virtual {v1, v2}, Ljava/util/Hashtable;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    iget-object v2, p1, Lcom/android/internal/util/danda/classes/f3;->m:Lcom/android/internal/util/danda/classes/o;

    if-nez v1, :cond_21

    iget-object v1, v0, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    check-cast v1, Ljava/util/Vector;

    invoke-virtual {v1, v2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    iget-object v0, v0, Lcom/android/internal/util/danda/classes/y5;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/Hashtable;

    invoke-virtual {v0, v2, p1}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_21
    new-instance p1, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "extension "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " already added"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final b(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V
    .registers 7

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y5;->b:Ljava/lang/Object;

    check-cast v0, Lcom/android/internal/util/danda/classes/c0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1, p2}, Lcom/android/internal/util/danda/classes/c0;->p(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)Lcom/android/internal/util/danda/classes/t;

    move-result-object p2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    check-cast v0, Ljava/util/Vector;

    new-instance v1, Lcom/android/internal/util/danda/classes/e5;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    new-instance v2, Lcom/android/internal/util/danda/classes/f;

    const/4 v3, 0x0

    invoke-direct {v2, v3}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    invoke-virtual {v2, p1}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v2, p2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance p1, Lcom/android/internal/util/danda/classes/e2;

    new-instance p2, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {p2, v3, v2}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    invoke-direct {p1, v3, p2}, Lcom/android/internal/util/danda/classes/e2;-><init>(ILcom/android/internal/util/danda/classes/t;)V

    iput-object p1, v1, Lcom/android/internal/util/danda/classes/e5;->m:Lcom/android/internal/util/danda/classes/w;

    invoke-virtual {v0, v1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    return-void
.end method

.method public final c(Lcom/android/internal/util/danda/classes/n4;)Lcom/android/internal/util/danda/classes/c6;
    .registers 12

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y5;->b:Ljava/lang/Object;

    check-cast v0, Lcom/android/internal/util/danda/classes/w5;

    iget-object v1, p1, Lcom/android/internal/util/danda/classes/n4;->c:Ljava/lang/Object;

    check-cast v1, Lcom/android/internal/util/danda/classes/d0;

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/w5;->c:Lcom/android/internal/util/danda/classes/d0;

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    check-cast v0, Lcom/android/internal/util/danda/classes/y5;

    iget-object v0, v0, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    check-cast v0, Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->isEmpty()Z

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_8b

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y5;->b:Ljava/lang/Object;

    check-cast v0, Lcom/android/internal/util/danda/classes/w5;

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    check-cast v3, Lcom/android/internal/util/danda/classes/y5;

    iget-object v4, v3, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    check-cast v4, Ljava/util/Vector;

    invoke-virtual {v4}, Ljava/util/Vector;->size()I

    move-result v4

    new-array v5, v4, [Lcom/android/internal/util/danda/classes/f3;

    move v6, v2

    :goto_2d
    iget-object v7, v3, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    check-cast v7, Ljava/util/Vector;

    invoke-virtual {v7}, Ljava/util/Vector;->size()I

    move-result v7

    if-eq v6, v7, :cond_4e

    iget-object v7, v3, Lcom/android/internal/util/danda/classes/y5;->b:Ljava/lang/Object;

    check-cast v7, Ljava/util/Hashtable;

    iget-object v8, v3, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    check-cast v8, Ljava/util/Vector;

    invoke-virtual {v8, v6}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/android/internal/util/danda/classes/f3;

    aput-object v7, v5, v6

    add-int/lit8 v6, v6, 0x1

    goto :goto_2d

    :cond_4e
    new-instance v3, Lcom/android/internal/util/danda/classes/g3;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    new-instance v6, Ljava/util/Hashtable;

    invoke-direct {v6}, Ljava/util/Hashtable;-><init>()V

    iput-object v6, v3, Lcom/android/internal/util/danda/classes/g3;->m:Ljava/util/Hashtable;

    new-instance v6, Ljava/util/Vector;

    invoke-direct {v6}, Ljava/util/Vector;-><init>()V

    iput-object v6, v3, Lcom/android/internal/util/danda/classes/g3;->n:Ljava/util/Vector;

    move v6, v2

    :goto_62
    if-eq v6, v4, :cond_77

    aget-object v7, v5, v6

    iget-object v8, v3, Lcom/android/internal/util/danda/classes/g3;->n:Ljava/util/Vector;

    iget-object v9, v7, Lcom/android/internal/util/danda/classes/f3;->m:Lcom/android/internal/util/danda/classes/o;

    invoke-virtual {v8, v9}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    iget-object v8, v3, Lcom/android/internal/util/danda/classes/g3;->m:Ljava/util/Hashtable;

    iget-object v9, v7, Lcom/android/internal/util/danda/classes/f3;->m:Lcom/android/internal/util/danda/classes/o;

    invoke-virtual {v8, v9, v7}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v6, v6, 0x1

    goto :goto_62

    :cond_77
    iput-object v3, v0, Lcom/android/internal/util/danda/classes/w5;->i:Lcom/android/internal/util/danda/classes/g3;

    sget-object v4, Lcom/android/internal/util/danda/classes/f3;->q:Lcom/android/internal/util/danda/classes/o;

    iget-object v3, v3, Lcom/android/internal/util/danda/classes/g3;->m:Ljava/util/Hashtable;

    invoke-virtual {v3, v4}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/internal/util/danda/classes/f3;

    if-eqz v3, :cond_8b

    iget-boolean v3, v3, Lcom/android/internal/util/danda/classes/f3;->n:Z

    if-eqz v3, :cond_8b

    iput-boolean v1, v0, Lcom/android/internal/util/danda/classes/w5;->j:Z

    :cond_8b
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/y5;->b:Ljava/lang/Object;

    check-cast v0, Lcom/android/internal/util/danda/classes/w5;

    iget-object v3, v0, Lcom/android/internal/util/danda/classes/w5;->b:Lcom/android/internal/util/danda/classes/k;

    if-eqz v3, :cond_13e

    iget-object v3, v0, Lcom/android/internal/util/danda/classes/w5;->c:Lcom/android/internal/util/danda/classes/d0;

    if-eqz v3, :cond_13e

    iget-object v3, v0, Lcom/android/internal/util/danda/classes/w5;->d:Lcom/android/internal/util/danda/classes/x5;

    if-eqz v3, :cond_13e

    iget-object v3, v0, Lcom/android/internal/util/danda/classes/w5;->e:Lcom/android/internal/util/danda/classes/u5;

    if-eqz v3, :cond_13e

    iget-object v3, v0, Lcom/android/internal/util/danda/classes/w5;->f:Lcom/android/internal/util/danda/classes/u5;

    if-eqz v3, :cond_13e

    iget-object v3, v0, Lcom/android/internal/util/danda/classes/w5;->g:Lcom/android/internal/util/danda/classes/x5;

    if-nez v3, :cond_ab

    iget-boolean v3, v0, Lcom/android/internal/util/danda/classes/w5;->j:Z

    if-eqz v3, :cond_13e

    :cond_ab
    iget-object v3, v0, Lcom/android/internal/util/danda/classes/w5;->h:Lcom/android/internal/util/danda/classes/q5;

    if-eqz v3, :cond_13e

    new-instance v3, Lcom/android/internal/util/danda/classes/f;

    invoke-direct {v3, v2}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    iget-object v4, v0, Lcom/android/internal/util/danda/classes/w5;->a:Lcom/android/internal/util/danda/classes/g2;

    invoke-virtual {v3, v4}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v4, v0, Lcom/android/internal/util/danda/classes/w5;->b:Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v3, v4}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v4, v0, Lcom/android/internal/util/danda/classes/w5;->c:Lcom/android/internal/util/danda/classes/d0;

    invoke-virtual {v3, v4}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v4, v0, Lcom/android/internal/util/danda/classes/w5;->d:Lcom/android/internal/util/danda/classes/x5;

    invoke-virtual {v3, v4}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v4, Lcom/android/internal/util/danda/classes/f;

    invoke-direct {v4, v2}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    iget-object v5, v0, Lcom/android/internal/util/danda/classes/w5;->e:Lcom/android/internal/util/danda/classes/u5;

    invoke-virtual {v4, v5}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v5, v0, Lcom/android/internal/util/danda/classes/w5;->f:Lcom/android/internal/util/danda/classes/u5;

    invoke-virtual {v4, v5}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v5, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v5, v2, v4}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    invoke-virtual {v3, v5}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v4, v0, Lcom/android/internal/util/danda/classes/w5;->g:Lcom/android/internal/util/danda/classes/x5;

    if-eqz v4, :cond_e7

    invoke-virtual {v3, v4}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    goto :goto_ef

    :cond_e7
    new-instance v4, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v4, v2}, Lcom/android/internal/util/danda/classes/d2;-><init>(I)V

    invoke-virtual {v3, v4}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :goto_ef
    iget-object v4, v0, Lcom/android/internal/util/danda/classes/w5;->h:Lcom/android/internal/util/danda/classes/q5;

    invoke-virtual {v3, v4}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v0, v0, Lcom/android/internal/util/danda/classes/w5;->i:Lcom/android/internal/util/danda/classes/g3;

    if-eqz v0, :cond_101

    new-instance v4, Lcom/android/internal/util/danda/classes/g2;

    const/4 v5, 0x3

    invoke-direct {v4, v1, v5, v0}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v3, v4}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_101
    new-instance v0, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v0, v2, v3}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/s5;->g(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/s5;

    move-result-object v0

    sget v1, Lcom/android/internal/util/danda/classes/d1;->a:I

    :try_start_10c
    new-instance v1, Lcom/android/internal/util/danda/classes/c6;

    iget-object v3, p1, Lcom/android/internal/util/danda/classes/n4;->c:Ljava/lang/Object;

    check-cast v3, Lcom/android/internal/util/danda/classes/d0;

    invoke-static {p1, v0}, Lcom/android/internal/util/danda/classes/d1;->a(Lcom/android/internal/util/danda/classes/n4;Lcom/android/internal/util/danda/classes/s5;)[B

    move-result-object p1

    new-instance v4, Lcom/android/internal/util/danda/classes/f;

    invoke-direct {v4, v2}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    invoke-virtual {v4, v0}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v4, v3}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/q1;

    invoke-direct {v0, v2, p1}, Lcom/android/internal/util/danda/classes/b;-><init>(I[B)V

    invoke-virtual {v4, v0}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance p1, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {p1, v2, v4}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/e1;->g(Lcom/android/internal/util/danda/classes/t;)Lcom/android/internal/util/danda/classes/e1;

    move-result-object p1

    invoke-direct {v1, p1}, Lcom/android/internal/util/danda/classes/c6;-><init>(Lcom/android/internal/util/danda/classes/e1;)V
    :try_end_135
    .catch Ljava/io/IOException; {:try_start_10c .. :try_end_135} :catch_136

    return-object v1

    :catch_136
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "cannot produce certificate signature"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_13e
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "not all mandatory fields set in V3 TBScertificate generator"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.class public final Lcom/android/internal/util/danda/classes/c4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Enumeration;


# instance fields
.field public final a:Lcom/android/internal/util/danda/classes/j;

.field public b:Lcom/android/internal/util/danda/classes/t;


# direct methods
.method public constructor <init>([B)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lcom/android/internal/util/danda/classes/j;

    new-instance v1, Ljava/io/ByteArrayInputStream;

    invoke-direct {v1, p1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    array-length p1, p1

    const/4 v2, 0x1

    invoke-direct {v0, v1, p1, v2}, Lcom/android/internal/util/danda/classes/j;-><init>(Ljava/io/InputStream;IZ)V

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/c4;->a:Lcom/android/internal/util/danda/classes/j;

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/c4;->a()Lcom/android/internal/util/danda/classes/t;

    move-result-object p1

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/c4;->b:Lcom/android/internal/util/danda/classes/t;

    return-void
.end method


# virtual methods
.method public final a()Lcom/android/internal/util/danda/classes/t;
    .registers 5

    :try_start_0
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/c4;->a:Lcom/android/internal/util/danda/classes/j;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/j;->f()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_6} :catch_7

    return-object v0

    :catch_7
    move-exception v0

    new-instance v1, Lcom/android/internal/util/danda/classes/s;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "malformed DER construction: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    invoke-direct {v1, v2, v0, v3}, Lcom/android/internal/util/danda/classes/s;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v1
.end method

.method public final hasMoreElements()Z
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/c4;->b:Lcom/android/internal/util/danda/classes/t;

    if-eqz v0, :cond_6

    const/4 v0, 0x1

    goto :goto_7

    :cond_6
    const/4 v0, 0x0

    :goto_7
    return v0
.end method

.method public final nextElement()Ljava/lang/Object;
    .registers 3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/c4;->b:Lcom/android/internal/util/danda/classes/t;

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/c4;->a()Lcom/android/internal/util/danda/classes/t;

    move-result-object v1

    iput-object v1, p0, Lcom/android/internal/util/danda/classes/c4;->b:Lcom/android/internal/util/danda/classes/t;

    return-object v0
.end method

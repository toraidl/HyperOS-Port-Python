.class public final Lcom/android/internal/util/danda/classes/f1;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;I)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p2, p0, Lcom/android/internal/util/danda/classes/f1;->a:I

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/f1;->b:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/android/internal/util/danda/classes/f1;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lcom/android/internal/util/danda/classes/f1;

    iget v1, p1, Lcom/android/internal/util/danda/classes/f1;->a:I

    iget v3, p0, Lcom/android/internal/util/danda/classes/f1;->a:I

    if-ne v3, v1, :cond_1d

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/f1;->b:Ljava/lang/String;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/f1;->b:Ljava/lang/String;

    invoke-static {v1, p1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1d

    goto :goto_1e

    :cond_1d
    move v0, v2

    :goto_1e
    return v0
.end method

.method public final hashCode()I
    .registers 3

    iget v0, p0, Lcom/android/internal/util/danda/classes/f1;->a:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/f1;->b:Ljava/lang/String;

    filled-new-array {v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Objects;->hash([Ljava/lang/Object;)I

    move-result v0

    return v0
.end method

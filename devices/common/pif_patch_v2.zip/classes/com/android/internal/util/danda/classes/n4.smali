.class public final Lcom/android/internal/util/danda/classes/n4;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lcom/android/internal/util/danda/classes/m4;

    new-instance v1, Lcom/android/internal/util/danda/classes/j1;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/m4;->a:Lcom/android/internal/util/danda/classes/j1;

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/n4;->b:Ljava/lang/Object;

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/n4;->a:Ljava/lang/Object;

    new-instance v0, Lcom/android/internal/util/danda/classes/p2;

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/p5;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    sget-object v0, Lcom/android/internal/util/danda/classes/p2;->a:Ljava/util/HashMap;

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/internal/util/danda/classes/o;

    if-eqz v0, :cond_76

    sget-object v1, Lcom/android/internal/util/danda/classes/p2;->b:Ljava/util/HashSet;

    invoke-virtual {v1, v0}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_33

    new-instance p1, Lcom/android/internal/util/danda/classes/d0;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object v0, p1, Lcom/android/internal/util/danda/classes/d0;->m:Lcom/android/internal/util/danda/classes/o;

    goto :goto_4f

    :cond_33
    sget-object v1, Lcom/android/internal/util/danda/classes/p2;->c:Ljava/util/HashMap;

    invoke-virtual {v1, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_48

    new-instance v2, Lcom/android/internal/util/danda/classes/d0;

    invoke-virtual {v1, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/android/internal/util/danda/classes/e;

    invoke-direct {v2, v0, p1}, Lcom/android/internal/util/danda/classes/d0;-><init>(Lcom/android/internal/util/danda/classes/o;Lcom/android/internal/util/danda/classes/e;)V

    move-object p1, v2

    goto :goto_4f

    :cond_48
    new-instance p1, Lcom/android/internal/util/danda/classes/d0;

    sget-object v1, Lcom/android/internal/util/danda/classes/y1;->m:Lcom/android/internal/util/danda/classes/y1;

    invoke-direct {p1, v0, v1}, Lcom/android/internal/util/danda/classes/d0;-><init>(Lcom/android/internal/util/danda/classes/o;Lcom/android/internal/util/danda/classes/e;)V

    :goto_4f
    sget-object v1, Lcom/android/internal/util/danda/classes/p2;->d:Ljava/util/HashSet;

    invoke-virtual {v1, v0}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_59

    sget-object v1, Lcom/android/internal/util/danda/classes/v4;->a:Lcom/android/internal/util/danda/classes/o;

    :cond_59
    sget-object v1, Lcom/android/internal/util/danda/classes/v4;->g:Lcom/android/internal/util/danda/classes/o;

    iget-object v2, p1, Lcom/android/internal/util/danda/classes/d0;->m:Lcom/android/internal/util/danda/classes/o;

    invoke-virtual {v2, v1}, Lcom/android/internal/util/danda/classes/t;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6b

    iget-object v0, p1, Lcom/android/internal/util/danda/classes/d0;->n:Lcom/android/internal/util/danda/classes/e;

    check-cast v0, Lcom/android/internal/util/danda/classes/h5;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto :goto_73

    :cond_6b
    sget-object v1, Lcom/android/internal/util/danda/classes/p2;->e:Ljava/util/HashMap;

    invoke-virtual {v1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/internal/util/danda/classes/o;

    :goto_73
    iput-object p1, p0, Lcom/android/internal/util/danda/classes/n4;->d:Ljava/lang/Object;

    return-void

    :cond_76
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Unknown signature type requested: "

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method public final a(Ljava/security/PrivateKey;)Lcom/android/internal/util/danda/classes/n4;
    .registers 6

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/n4;->d:Ljava/lang/Object;

    :try_start_2
    iget-object v1, p0, Lcom/android/internal/util/danda/classes/n4;->b:Ljava/lang/Object;

    check-cast v1, Lcom/android/internal/util/danda/classes/m4;

    move-object v2, v0

    check-cast v2, Lcom/android/internal/util/danda/classes/d0;

    invoke-virtual {v1, v2}, Lcom/android/internal/util/danda/classes/m4;->a(Lcom/android/internal/util/danda/classes/d0;)Ljava/security/Signature;

    move-result-object v1

    check-cast v0, Lcom/android/internal/util/danda/classes/d0;

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/n4;->c:Ljava/lang/Object;

    move-object v3, v2

    check-cast v3, Ljava/security/SecureRandom;

    if-eqz v3, :cond_1e

    check-cast v2, Ljava/security/SecureRandom;

    invoke-virtual {v1, p1, v2}, Ljava/security/Signature;->initSign(Ljava/security/PrivateKey;Ljava/security/SecureRandom;)V

    goto :goto_21

    :catch_1c
    move-exception p1

    goto :goto_36

    :cond_1e
    invoke-virtual {v1, p1}, Ljava/security/Signature;->initSign(Ljava/security/PrivateKey;)V

    :goto_21
    new-instance p1, Lcom/android/internal/util/danda/classes/n4;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p0, p1, Lcom/android/internal/util/danda/classes/n4;->d:Ljava/lang/Object;

    iput-object v1, p1, Lcom/android/internal/util/danda/classes/n4;->b:Ljava/lang/Object;

    iput-object v0, p1, Lcom/android/internal/util/danda/classes/n4;->c:Ljava/lang/Object;

    new-instance v0, Lcom/android/internal/util/danda/classes/w3;

    invoke-direct {v0}, Ljava/io/OutputStream;-><init>()V

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/w3;->a:Ljava/security/Signature;

    iput-object v0, p1, Lcom/android/internal/util/danda/classes/n4;->a:Ljava/lang/Object;
    :try_end_35
    .catch Ljava/security/GeneralSecurityException; {:try_start_2 .. :try_end_35} :catch_1c

    return-object p1

    :goto_36
    new-instance v0, Lcom/android/internal/util/danda/classes/l4;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "cannot create signer: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    iput-object p1, v0, Lcom/android/internal/util/danda/classes/l4;->a:Ljava/lang/Throwable;

    throw v0
.end method

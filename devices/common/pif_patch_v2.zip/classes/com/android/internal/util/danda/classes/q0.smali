.class public abstract Lcom/android/internal/util/danda/classes/q0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lcom/android/internal/util/danda/classes/u0;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/android/internal/util/danda/classes/u0;

    invoke-direct {v0}, Lcom/android/internal/util/danda/classes/u;-><init>()V

    sput-object v0, Lcom/android/internal/util/danda/classes/q0;->a:Lcom/android/internal/util/danda/classes/u0;

    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    return-void
.end method

.class public interface abstract Lcom/android/internal/util/danda/classes/a1;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lcom/android/internal/util/danda/classes/o;

.field public static final b:Lcom/android/internal/util/danda/classes/o;

.field public static final c:Lcom/android/internal/util/danda/classes/o;

.field public static final d:Lcom/android/internal/util/danda/classes/o;

.field public static final e:Lcom/android/internal/util/danda/classes/o;

.field public static final f:Lcom/android/internal/util/danda/classes/o;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "0.4.0.127.0.7"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "1.1"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "4.1"

    invoke-direct {v0, v1, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "1"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/a1;->a:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "2"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/a1;->b:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "3"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/a1;->c:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "4"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/a1;->d:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "5"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/a1;->e:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "6"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/a1;->f:Lcom/android/internal/util/danda/classes/o;

    return-void
.end method

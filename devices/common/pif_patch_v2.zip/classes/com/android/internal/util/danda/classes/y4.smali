.class public interface abstract Lcom/android/internal/util/danda/classes/y4;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Lcom/android/internal/util/danda/classes/x4;)Ljava/lang/Object;
.end method

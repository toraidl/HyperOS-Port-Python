.class public final Lcom/android/internal/util/danda/classes/p0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/e;
.implements Lcom/android/internal/util/danda/classes/s3;


# instance fields
.field public final m:I

.field public final n:Lcom/android/internal/util/danda/classes/y;


# direct methods
.method public constructor <init>(ILcom/android/internal/util/danda/classes/y;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/android/internal/util/danda/classes/p0;->m:I

    iput-object p2, p0, Lcom/android/internal/util/danda/classes/p0;->n:Lcom/android/internal/util/danda/classes/y;

    return-void
.end method


# virtual methods
.method public final b()Lcom/android/internal/util/danda/classes/t;
    .registers 4

    new-instance v0, Lcom/android/internal/util/danda/classes/o0;

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/p0;->n:Lcom/android/internal/util/danda/classes/y;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/y;->c()Lcom/android/internal/util/danda/classes/f;

    move-result-object v1

    iget v2, p0, Lcom/android/internal/util/danda/classes/p0;->m:I

    invoke-direct {v0, v2, v1}, Lcom/android/internal/util/danda/classes/o0;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    return-object v0
.end method

.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 5

    :try_start_0
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/p0;->b()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_4} :catch_5

    return-object v0

    :catch_5
    move-exception v0

    new-instance v1, Lcom/android/internal/util/danda/classes/s;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    invoke-direct {v1, v2, v0, v3}, Lcom/android/internal/util/danda/classes/s;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v1
.end method

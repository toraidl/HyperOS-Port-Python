.class public final Lcom/android/internal/util/danda/classes/f0;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/d;


# instance fields
.field public final m:Lcom/android/internal/util/danda/classes/t;


# direct methods
.method public constructor <init>(Lcom/android/internal/util/danda/classes/n3;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/n3;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object p1

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/f0;->m:Lcom/android/internal/util/danda/classes/t;

    return-void
.end method

.method public constructor <init>(Lcom/android/internal/util/danda/classes/v5;)V
    .registers 4

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Lcom/android/internal/util/danda/classes/g2;

    const/4 v1, 0x0

    .line 5
    invoke-direct {v0, v1, v1, p1}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/f0;->m:Lcom/android/internal/util/danda/classes/t;

    return-void
.end method


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/f0;->m:Lcom/android/internal/util/danda/classes/t;

    return-object v0
.end method

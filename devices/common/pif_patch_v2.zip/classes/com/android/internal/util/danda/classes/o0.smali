.class public final Lcom/android/internal/util/danda/classes/o0;
.super Lcom/android/internal/util/danda/classes/a;
.source "SourceFile"


# instance fields
.field public final synthetic p:I


# direct methods
.method public constructor <init>(ILcom/android/internal/util/danda/classes/f;)V
    .registers 8

    const/4 v0, 0x0

    iput v0, p0, Lcom/android/internal/util/danda/classes/o0;->p:I

    .line 2
    new-instance v1, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v1}, Ljava/io/ByteArrayOutputStream;-><init>()V

    move v2, v0

    .line 3
    :goto_9
    invoke-virtual {p2}, Lcom/android/internal/util/danda/classes/f;->f()I

    move-result v3

    if-eq v2, v3, :cond_36

    .line 4
    :try_start_f
    invoke-virtual {p2, v2}, Lcom/android/internal/util/danda/classes/f;->b(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v3

    check-cast v3, Lcom/android/internal/util/danda/classes/m;

    const-string v4, "BER"

    invoke-virtual {v3, v4}, Lcom/android/internal/util/danda/classes/m;->f(Ljava/lang/String;)[B

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/io/OutputStream;->write([B)V
    :try_end_1e
    .catch Ljava/io/IOException; {:try_start_f .. :try_end_1e} :catch_21

    add-int/lit8 v2, v2, 0x1

    goto :goto_9

    :catch_21
    move-exception p1

    .line 5
    new-instance p2, Lcom/android/internal/util/danda/classes/s;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "malformed object: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p2, v1, p1, v0}, Lcom/android/internal/util/danda/classes/s;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw p2

    .line 6
    :cond_36
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p2

    const/4 v0, 0x1

    .line 7
    invoke-direct {p0, v0, p1, p2}, Lcom/android/internal/util/danda/classes/a;-><init>(ZI[B)V

    return-void
.end method

.method public constructor <init>(ZI[B)V
    .registers 5

    const/4 v0, 0x1

    iput v0, p0, Lcom/android/internal/util/danda/classes/o0;->p:I

    .line 1
    invoke-direct {p0, p1, p2, p3}, Lcom/android/internal/util/danda/classes/a;-><init>(ZI[B)V

    return-void
.end method


# virtual methods
.method public final h(Lcom/android/internal/util/danda/classes/f;)V
    .registers 8

    iget v0, p0, Lcom/android/internal/util/danda/classes/o0;->p:I

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/a;->o:[B

    iget v2, p0, Lcom/android/internal/util/danda/classes/a;->n:I

    const/16 v3, 0x40

    const/16 v4, 0x60

    iget-boolean v5, p0, Lcom/android/internal/util/danda/classes/a;->m:Z

    packed-switch v0, :pswitch_data_3c

    if-eqz v5, :cond_12

    move v3, v4

    :cond_12
    invoke-virtual {p1, v3, v2}, Lcom/android/internal/util/danda/classes/f;->l(II)V

    array-length v0, v1

    invoke-virtual {p1, v0}, Lcom/android/internal/util/danda/classes/f;->j(I)V

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/f;->a:Ljava/lang/Object;

    check-cast p1, Ljava/io/OutputStream;

    invoke-virtual {p1, v1}, Ljava/io/OutputStream;->write([B)V

    return-void

    :pswitch_21
    if-eqz v5, :cond_24

    move v3, v4

    :cond_24
    invoke-virtual {p1, v3, v2}, Lcom/android/internal/util/danda/classes/f;->l(II)V

    const/16 v0, 0x80

    invoke-virtual {p1, v0}, Lcom/android/internal/util/danda/classes/f;->g(I)V

    iget-object v0, p1, Lcom/android/internal/util/danda/classes/f;->a:Ljava/lang/Object;

    check-cast v0, Ljava/io/OutputStream;

    invoke-virtual {v0, v1}, Ljava/io/OutputStream;->write([B)V

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lcom/android/internal/util/danda/classes/f;->g(I)V

    invoke-virtual {p1, v0}, Lcom/android/internal/util/danda/classes/f;->g(I)V

    return-void

    nop

    :pswitch_data_3c
    .packed-switch 0x0
        :pswitch_21
    .end packed-switch
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    iget v0, p0, Lcom/android/internal/util/danda/classes/o0;->p:I

    packed-switch v0, :pswitch_data_52

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_a
    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "["

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    iget-boolean v1, p0, Lcom/android/internal/util/danda/classes/a;->m:Z

    if-eqz v1, :cond_1a

    const-string v1, "CONSTRUCTED "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_1a
    const-string v1, "APPLICATION "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    iget v1, p0, Lcom/android/internal/util/danda/classes/a;->n:I

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const-string v1, "]"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/a;->o:[B

    if-eqz v1, :cond_43

    const-string v2, " #"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    array-length v2, v1

    invoke-static {v1, v2}, Lcom/android/internal/util/danda/classes/p3;->b([BI)[B

    move-result-object v1

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/p5;->a([B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    goto :goto_48

    :cond_43
    const-string v1, " #null"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :goto_48
    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_data_52
    .packed-switch 0x1
        :pswitch_a
    .end packed-switch
.end method

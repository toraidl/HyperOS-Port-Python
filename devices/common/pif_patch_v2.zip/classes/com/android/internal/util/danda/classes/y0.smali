.class public final Lcom/android/internal/util/danda/classes/y0;
.super Lcom/android/internal/util/danda/classes/a0;
.source "SourceFile"


# virtual methods
.method public final h(Lcom/android/internal/util/danda/classes/f;)V
    .registers 5

    const/16 v0, 0xa0

    iget v1, p0, Lcom/android/internal/util/danda/classes/a0;->m:I

    invoke-virtual {p1, v0, v1}, Lcom/android/internal/util/danda/classes/f;->l(II)V

    const/16 v0, 0x80

    invoke-virtual {p1, v0}, Lcom/android/internal/util/danda/classes/f;->g(I)V

    iget-boolean v0, p0, Lcom/android/internal/util/danda/classes/a0;->n:Z

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/a0;->o:Lcom/android/internal/util/danda/classes/e;

    const/4 v2, 0x0

    if-nez v0, :cond_6d

    instance-of v0, v1, Lcom/android/internal/util/danda/classes/p;

    if-eqz v0, :cond_32

    instance-of v0, v1, Lcom/android/internal/util/danda/classes/s0;

    if-eqz v0, :cond_22

    check-cast v1, Lcom/android/internal/util/danda/classes/s0;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/s0;->p()Ljava/util/Enumeration;

    move-result-object v0

    goto :goto_49

    :cond_22
    check-cast v1, Lcom/android/internal/util/danda/classes/p;

    new-instance v0, Lcom/android/internal/util/danda/classes/s0;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/p;->o()[B

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/s0;->p()Ljava/util/Enumeration;

    move-result-object v0

    goto :goto_49

    :cond_32
    instance-of v0, v1, Lcom/android/internal/util/danda/classes/u;

    if-eqz v0, :cond_3d

    check-cast v1, Lcom/android/internal/util/danda/classes/u;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/u;->q()Ljava/util/Enumeration;

    move-result-object v0

    goto :goto_49

    :cond_3d
    instance-of v0, v1, Lcom/android/internal/util/danda/classes/w;

    if-eqz v0, :cond_59

    check-cast v1, Lcom/android/internal/util/danda/classes/w;

    iget-object v0, v1, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->elements()Ljava/util/Enumeration;

    move-result-object v0

    :goto_49
    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v1

    if-eqz v1, :cond_70

    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/e;

    invoke-virtual {p1, v1}, Lcom/android/internal/util/danda/classes/f;->k(Lcom/android/internal/util/danda/classes/e;)V

    goto :goto_49

    :cond_59
    new-instance p1, Lcom/android/internal/util/danda/classes/h;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "not implemented: "

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0, v2}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;I)V

    throw p1

    :cond_6d
    invoke-virtual {p1, v1}, Lcom/android/internal/util/danda/classes/f;->k(Lcom/android/internal/util/danda/classes/e;)V

    :cond_70
    invoke-virtual {p1, v2}, Lcom/android/internal/util/danda/classes/f;->g(I)V

    invoke-virtual {p1, v2}, Lcom/android/internal/util/danda/classes/f;->g(I)V

    return-void
.end method

.method public final i()I
    .registers 4

    iget v0, p0, Lcom/android/internal/util/danda/classes/a0;->m:I

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/a0;->o:Lcom/android/internal/util/danda/classes/e;

    invoke-interface {v1}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v1

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/t;->i()I

    move-result v1

    iget-boolean v2, p0, Lcom/android/internal/util/danda/classes/a0;->n:Z

    if-eqz v2, :cond_1b

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/n5;->b(I)I

    move-result v0

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/n5;->a(I)I

    move-result v2

    add-int/2addr v2, v0

    add-int/2addr v2, v1

    return v2

    :cond_1b
    add-int/lit8 v1, v1, -0x1

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/n5;->b(I)I

    move-result v0

    add-int/2addr v0, v1

    return v0
.end method

.method public final k()Z
    .registers 2

    iget-boolean v0, p0, Lcom/android/internal/util/danda/classes/a0;->n:Z

    if-eqz v0, :cond_6

    const/4 v0, 0x1

    return v0

    :cond_6
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/a0;->o:Lcom/android/internal/util/danda/classes/e;

    invoke-interface {v0}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/t;->l()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/t;->k()Z

    move-result v0

    return v0
.end method

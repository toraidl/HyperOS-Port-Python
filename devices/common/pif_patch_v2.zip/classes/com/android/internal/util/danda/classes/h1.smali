.class public abstract Lcom/android/internal/util/danda/classes/h1;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljava/util/concurrent/ConcurrentHashMap;

.field public static final b:Ljava/util/concurrent/ConcurrentHashMap;

.field public static final c:Lcom/android/internal/util/danda/classes/o;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    sput-object v0, Lcom/android/internal/util/danda/classes/h1;->a:Ljava/util/concurrent/ConcurrentHashMap;

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    sput-object v0, Lcom/android/internal/util/danda/classes/h1;->b:Ljava/util/concurrent/ConcurrentHashMap;

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.3.6.1.4.1.11129.2.1.17"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    sput-object v0, Lcom/android/internal/util/danda/classes/h1;->c:Lcom/android/internal/util/danda/classes/o;

    return-void
.end method

.method public static a(Ljava/util/ArrayList;ILandroid/hardware/security/keymint/KeyParameterValue;I)V
    .registers 6

    new-instance v0, Landroid/system/keystore2/Authorization;

    invoke-direct {v0}, Landroid/system/keystore2/Authorization;-><init>()V

    new-instance v1, Landroid/hardware/security/keymint/KeyParameter;

    invoke-direct {v1}, Landroid/hardware/security/keymint/KeyParameter;-><init>()V

    iput-object v1, v0, Landroid/system/keystore2/Authorization;->keyParameter:Landroid/hardware/security/keymint/KeyParameter;

    iput p1, v1, Landroid/hardware/security/keymint/KeyParameter;->tag:I

    iput-object p2, v1, Landroid/hardware/security/keymint/KeyParameter;->value:Landroid/hardware/security/keymint/KeyParameterValue;

    iput p3, v0, Landroid/system/keystore2/Authorization;->securityLevel:I

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public static b(I)[B
    .registers 14

    const/4 v0, 0x0

    :try_start_1
    invoke-static {}, Landroid/app/ActivityThread;->currentActivityThread()Landroid/app/ActivityThread;

    move-result-object v1

    if-nez v1, :cond_8

    return-object v0

    :cond_8
    invoke-virtual {v1}, Landroid/app/ActivityThread;->getSystemContext()Landroid/app/ContextImpl;

    move-result-object v1

    if-nez v1, :cond_f

    return-object v0

    :cond_f
    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {v1, p0}, Landroid/content/pm/PackageManager;->getPackagesForUid(I)[Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_a5

    array-length v2, p0

    if-nez v2, :cond_1e

    goto/16 :goto_a5

    :cond_1e
    new-instance v2, Lcom/android/internal/util/danda/classes/f;

    const/4 v3, 0x0

    invoke-direct {v2, v3}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    new-instance v4, Lcom/android/internal/util/danda/classes/f;

    invoke-direct {v4, v3}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    const-string v5, "SHA-256"

    invoke-static {v5}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v5

    array-length v6, p0

    move v7, v3

    :goto_31
    if-ge v7, v6, :cond_86

    aget-object v8, p0, v7

    const/16 v9, 0x40

    invoke-virtual {v1, v8, v9}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v9

    new-instance v10, Lcom/android/internal/util/danda/classes/f;

    invoke-direct {v10, v3}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    new-instance v11, Lcom/android/internal/util/danda/classes/a2;

    invoke-virtual {v8}, Ljava/lang/String;->getBytes()[B

    move-result-object v8

    invoke-direct {v11, v8}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    invoke-virtual {v10, v11}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V
    :try_end_4c
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_4c} :catch_51

    :try_start_4c
    invoke-virtual {v9}, Landroid/content/pm/PackageInfo;->getLongVersionCode()J

    move-result-wide v11
    :try_end_50
    .catch Ljava/lang/NoSuchMethodError; {:try_start_4c .. :try_end_50} :catch_53
    .catch Ljava/lang/Exception; {:try_start_4c .. :try_end_50} :catch_51

    goto :goto_56

    :catch_51
    move-exception p0

    goto :goto_a6

    :catch_53
    :try_start_53
    iget v8, v9, Landroid/content/pm/PackageInfo;->versionCode:I

    int-to-long v11, v8

    :goto_56
    new-instance v8, Lcom/android/internal/util/danda/classes/k;

    invoke-direct {v8, v11, v12}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    invoke-virtual {v10, v8}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v8, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v8, v3, v10}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    invoke-virtual {v2, v8}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    iget-object v8, v9, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    if-eqz v8, :cond_83

    array-length v9, v8

    move v10, v3

    :goto_6c
    if-ge v10, v9, :cond_83

    aget-object v11, v8, v10

    invoke-virtual {v11}, Landroid/content/pm/Signature;->toByteArray()[B

    move-result-object v11

    invoke-virtual {v5, v11}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object v11

    new-instance v12, Lcom/android/internal/util/danda/classes/a2;

    invoke-direct {v12, v11}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    invoke-virtual {v4, v12}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    add-int/lit8 v10, v10, 0x1

    goto :goto_6c

    :cond_83
    add-int/lit8 v7, v7, 0x1

    goto :goto_31

    :cond_86
    new-instance p0, Lcom/android/internal/util/danda/classes/f;

    invoke-direct {p0, v3}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    new-instance v1, Lcom/android/internal/util/danda/classes/e2;

    invoke-direct {v1, v3, v2}, Lcom/android/internal/util/danda/classes/e2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    invoke-virtual {p0, v1}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/e2;

    invoke-direct {v1, v3, v4}, Lcom/android/internal/util/danda/classes/e2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    invoke-virtual {p0, v1}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v1, v3, p0}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/m;->e()[B

    move-result-object p0
    :try_end_a4
    .catch Ljava/lang/Exception; {:try_start_53 .. :try_end_a4} :catch_51

    return-object p0

    :cond_a5
    :goto_a5
    return-object v0

    :goto_a6
    const-string v1, "OemPorts10TUtils"

    const-string v2, "Failed to build AttestationApplicationId"

    invoke-static {v1, v2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return-object v0
.end method

.method public static c(Landroid/system/keystore2/IKeystoreSecurityLevel;Ljava/util/ArrayList;Lcom/android/internal/util/danda/classes/g1;Landroid/system/keystore2/KeyDescriptor;)Landroid/system/keystore2/KeyEntryResponse;
    .registers 12

    :try_start_0
    new-instance v0, Landroid/system/keystore2/KeyEntryResponse;

    invoke-direct {v0}, Landroid/system/keystore2/KeyEntryResponse;-><init>()V

    new-instance v1, Landroid/system/keystore2/KeyMetadata;

    invoke-direct {v1}, Landroid/system/keystore2/KeyMetadata;-><init>()V

    iget v2, p2, Lcom/android/internal/util/danda/classes/g1;->f:I
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_c} :catch_74

    iget v3, p2, Lcom/android/internal/util/danda/classes/g1;->a:I

    :try_start_e
    iput v2, v1, Landroid/system/keystore2/KeyMetadata;->keySecurityLevel:I

    const/4 v2, 0x0

    new-array v4, v2, [Ljava/security/cert/Certificate;

    invoke-virtual {p1, v4}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Ljava/security/cert/Certificate;

    aget-object v4, p1, v2

    invoke-virtual {v4}, Ljava/security/cert/Certificate;->getEncoded()[B

    move-result-object v4

    iput-object v4, v1, Landroid/system/keystore2/KeyMetadata;->certificate:[B

    new-instance v4, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v4}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v5, 0x1

    move v6, v5

    :goto_28
    array-length v7, p1

    if-ge v6, v7, :cond_37

    aget-object v7, p1, v6

    invoke-virtual {v7}, Ljava/security/cert/Certificate;->getEncoded()[B

    move-result-object v7

    invoke-virtual {v4, v7}, Ljava/io/OutputStream;->write([B)V

    add-int/lit8 v6, v6, 0x1

    goto :goto_28

    :cond_37
    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p1

    iput-object p1, v1, Landroid/system/keystore2/KeyMetadata;->certificateChain:[B

    new-instance p1, Landroid/system/keystore2/KeyDescriptor;

    invoke-direct {p1}, Landroid/system/keystore2/KeyDescriptor;-><init>()V

    iget v4, p3, Landroid/system/keystore2/KeyDescriptor;->domain:I

    iput v4, p1, Landroid/system/keystore2/KeyDescriptor;->domain:I

    iget-wide v6, p3, Landroid/system/keystore2/KeyDescriptor;->nspace:J

    iput-wide v6, p1, Landroid/system/keystore2/KeyDescriptor;->nspace:J

    iput-object p1, v1, Landroid/system/keystore2/KeyMetadata;->key:Landroid/system/keystore2/KeyDescriptor;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iget-object p3, p2, Lcom/android/internal/util/danda/classes/g1;->g:Ljava/util/ArrayList;

    invoke-virtual {p3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p3

    :goto_57
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4
    :try_end_5b
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_5b} :catch_74

    iget v6, p2, Lcom/android/internal/util/danda/classes/g1;->f:I

    if-eqz v4, :cond_77

    :try_start_5f
    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    invoke-static {v4}, Landroid/hardware/security/keymint/KeyParameterValue;->keyPurpose(I)Landroid/hardware/security/keymint/KeyParameterValue;

    move-result-object v4

    const v7, 0x20000001

    invoke-static {p1, v7, v4, v6}, Lcom/android/internal/util/danda/classes/h1;->a(Ljava/util/ArrayList;ILandroid/hardware/security/keymint/KeyParameterValue;I)V

    goto :goto_57

    :catch_74
    move-exception p0

    goto/16 :goto_118

    :cond_77
    iget-object p3, p2, Lcom/android/internal/util/danda/classes/g1;->h:Ljava/util/ArrayList;

    invoke-virtual {p3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p3

    :goto_7d
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_98

    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    invoke-static {v4}, Landroid/hardware/security/keymint/KeyParameterValue;->digest(I)Landroid/hardware/security/keymint/KeyParameterValue;

    move-result-object v4

    const v7, 0x20000005

    invoke-static {p1, v7, v4, v6}, Lcom/android/internal/util/danda/classes/h1;->a(Ljava/util/ArrayList;ILandroid/hardware/security/keymint/KeyParameterValue;I)V

    goto :goto_7d

    :cond_98
    invoke-static {v3}, Landroid/hardware/security/keymint/KeyParameterValue;->algorithm(I)Landroid/hardware/security/keymint/KeyParameterValue;

    move-result-object p3

    const v4, 0x10000002

    invoke-static {p1, v4, p3, v6}, Lcom/android/internal/util/danda/classes/h1;->a(Ljava/util/ArrayList;ILandroid/hardware/security/keymint/KeyParameterValue;I)V

    iget p3, p2, Lcom/android/internal/util/danda/classes/g1;->d:I

    invoke-static {p3}, Landroid/hardware/security/keymint/KeyParameterValue;->integer(I)Landroid/hardware/security/keymint/KeyParameterValue;

    move-result-object p3

    const v4, 0x30000003

    invoke-static {p1, v4, p3, v6}, Lcom/android/internal/util/danda/classes/h1;->a(Ljava/util/ArrayList;ILandroid/hardware/security/keymint/KeyParameterValue;I)V

    const/4 p3, 0x3

    if-ne v3, p3, :cond_bd

    iget p3, p2, Lcom/android/internal/util/danda/classes/g1;->e:I

    invoke-static {p3}, Landroid/hardware/security/keymint/KeyParameterValue;->ecCurve(I)Landroid/hardware/security/keymint/KeyParameterValue;

    move-result-object p3

    const v3, 0x1000000a

    invoke-static {p1, v3, p3, v6}, Lcom/android/internal/util/danda/classes/h1;->a(Ljava/util/ArrayList;ILandroid/hardware/security/keymint/KeyParameterValue;I)V

    :cond_bd
    invoke-static {v2}, Landroid/hardware/security/keymint/KeyParameterValue;->origin(I)Landroid/hardware/security/keymint/KeyParameterValue;

    move-result-object p3

    const v3, 0x100002be

    invoke-static {p1, v3, p3, v6}, Lcom/android/internal/util/danda/classes/h1;->a(Ljava/util/ArrayList;ILandroid/hardware/security/keymint/KeyParameterValue;I)V

    iget-wide v3, p2, Lcom/android/internal/util/danda/classes/g1;->j:J

    long-to-int p3, v3

    invoke-static {p3}, Landroid/hardware/security/keymint/KeyParameterValue;->integer(I)Landroid/hardware/security/keymint/KeyParameterValue;

    move-result-object p3

    const v3, 0x300002ce

    invoke-static {p1, v3, p3, v6}, Lcom/android/internal/util/danda/classes/h1;->a(Ljava/util/ArrayList;ILandroid/hardware/security/keymint/KeyParameterValue;I)V

    iget-wide v3, p2, Lcom/android/internal/util/danda/classes/g1;->k:J

    long-to-int p3, v3

    invoke-static {p3}, Landroid/hardware/security/keymint/KeyParameterValue;->integer(I)Landroid/hardware/security/keymint/KeyParameterValue;

    move-result-object p3

    const v3, 0x300002cf

    invoke-static {p1, v3, p3, v6}, Lcom/android/internal/util/danda/classes/h1;->a(Ljava/util/ArrayList;ILandroid/hardware/security/keymint/KeyParameterValue;I)V

    iget p3, p2, Lcom/android/internal/util/danda/classes/g1;->m:I

    invoke-static {p3}, Landroid/hardware/security/keymint/KeyParameterValue;->integer(I)Landroid/hardware/security/keymint/KeyParameterValue;

    move-result-object p3

    const v3, 0x300001f5

    invoke-static {p1, v3, p3, v6}, Lcom/android/internal/util/danda/classes/h1;->a(Ljava/util/ArrayList;ILandroid/hardware/security/keymint/KeyParameterValue;I)V

    invoke-static {v5}, Landroid/hardware/security/keymint/KeyParameterValue;->boolValue(Z)Landroid/hardware/security/keymint/KeyParameterValue;

    move-result-object p3

    const v3, 0x700001f7

    invoke-static {p1, v3, p3, v6}, Lcom/android/internal/util/danda/classes/h1;->a(Ljava/util/ArrayList;ILandroid/hardware/security/keymint/KeyParameterValue;I)V

    iget-wide p2, p2, Lcom/android/internal/util/danda/classes/g1;->l:J

    invoke-static {p2, p3}, Landroid/hardware/security/keymint/KeyParameterValue;->longInteger(J)Landroid/hardware/security/keymint/KeyParameterValue;

    move-result-object p2

    const p3, 0x600002bd

    invoke-static {p1, p3, p2, v6}, Lcom/android/internal/util/danda/classes/h1;->a(Ljava/util/ArrayList;ILandroid/hardware/security/keymint/KeyParameterValue;I)V

    new-array p2, v2, [Landroid/system/keystore2/Authorization;

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Landroid/system/keystore2/Authorization;

    iput-object p1, v1, Landroid/system/keystore2/KeyMetadata;->authorizations:[Landroid/system/keystore2/Authorization;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p1

    iput-wide p1, v1, Landroid/system/keystore2/KeyMetadata;->modificationTimeMs:J

    iput-object v1, v0, Landroid/system/keystore2/KeyEntryResponse;->metadata:Landroid/system/keystore2/KeyMetadata;

    iput-object p0, v0, Landroid/system/keystore2/KeyEntryResponse;->iSecurityLevel:Landroid/system/keystore2/IKeystoreSecurityLevel;
    :try_end_117
    .catch Ljava/lang/Exception; {:try_start_5f .. :try_end_117} :catch_74

    return-object v0

    :goto_118
    const-string p1, "OemPorts10TUtils"

    const-string p2, "Failed to build key entry response"

    invoke-static {p1, p2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 p0, 0x0

    return-object p0
.end method

.method public static d(Lcom/android/internal/util/danda/classes/g1;)Lcom/android/internal/util/danda/classes/f3;
    .registers 15

    const/16 v0, 0x20

    :try_start_2
    new-array v1, v0, [B

    invoke-static {}, Ljava/util/concurrent/ThreadLocalRandom;->current()Ljava/util/concurrent/ThreadLocalRandom;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/util/Random;->nextBytes([B)V

    invoke-static {}, Lcom/android/internal/util/danda/classes/m5;->e()[B

    move-result-object v2

    if-nez v2, :cond_1e

    new-array v2, v0, [B

    invoke-static {}, Ljava/util/concurrent/ThreadLocalRandom;->current()Ljava/util/concurrent/ThreadLocalRandom;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/util/Random;->nextBytes([B)V

    goto :goto_1e

    :catch_1b
    move-exception p0

    goto/16 :goto_1b9

    :cond_1e
    :goto_1e
    const/4 v0, 0x4

    new-array v3, v0, [Lcom/android/internal/util/danda/classes/e;

    new-instance v4, Lcom/android/internal/util/danda/classes/a2;

    invoke-direct {v4, v1}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    const/4 v1, 0x0

    aput-object v4, v3, v1

    sget-object v4, Lcom/android/internal/util/danda/classes/c;->q:Lcom/android/internal/util/danda/classes/c;

    const/4 v5, 0x1

    aput-object v4, v3, v5

    new-instance v4, Lcom/android/internal/util/danda/classes/g;

    invoke-direct {v4, v1}, Lcom/android/internal/util/danda/classes/g;-><init>(I)V

    const/4 v6, 0x2

    aput-object v4, v3, v6

    new-instance v4, Lcom/android/internal/util/danda/classes/a2;

    invoke-direct {v4, v2}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    const/4 v2, 0x3

    aput-object v4, v3, v2

    new-instance v4, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v4, v3}, Lcom/android/internal/util/danda/classes/d2;-><init>([Lcom/android/internal/util/danda/classes/e;)V

    new-instance v3, Lcom/android/internal/util/danda/classes/f;

    invoke-direct {v3, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    new-instance v7, Lcom/android/internal/util/danda/classes/f;

    invoke-direct {v7, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    iget-object v8, p0, Lcom/android/internal/util/danda/classes/g1;->g:Ljava/util/ArrayList;
    :try_end_4f
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_4f} :catch_1b

    iget v9, p0, Lcom/android/internal/util/danda/classes/g1;->a:I

    :try_start_51
    invoke-virtual {v8}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_55
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_6f

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Integer;

    new-instance v11, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    move-result v10

    int-to-long v12, v10

    invoke-direct {v11, v12, v13}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    invoke-virtual {v7, v11}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    goto :goto_55

    :cond_6f
    new-instance v8, Lcom/android/internal/util/danda/classes/g2;

    new-instance v10, Lcom/android/internal/util/danda/classes/e2;

    invoke-direct {v10, v1, v7}, Lcom/android/internal/util/danda/classes/e2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    invoke-direct {v8, v5, v5, v10}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v3, v8}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v7, Lcom/android/internal/util/danda/classes/g2;

    new-instance v8, Lcom/android/internal/util/danda/classes/k;

    int-to-long v10, v9

    invoke-direct {v8, v10, v11}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    invoke-direct {v7, v5, v6, v8}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v3, v7}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v7, Lcom/android/internal/util/danda/classes/g2;

    new-instance v8, Lcom/android/internal/util/danda/classes/k;

    iget v10, p0, Lcom/android/internal/util/danda/classes/g1;->d:I

    int-to-long v10, v10

    invoke-direct {v8, v10, v11}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    invoke-direct {v7, v5, v2, v8}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v3, v7}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v7, Lcom/android/internal/util/danda/classes/f;

    invoke-direct {v7, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    iget-object v8, p0, Lcom/android/internal/util/danda/classes/g1;->h:Ljava/util/ArrayList;

    invoke-virtual {v8}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_a5
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_bf

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Integer;

    new-instance v11, Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    move-result v10

    int-to-long v12, v10

    invoke-direct {v11, v12, v13}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    invoke-virtual {v7, v11}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    goto :goto_a5

    :cond_bf
    new-instance v8, Lcom/android/internal/util/danda/classes/g2;

    new-instance v10, Lcom/android/internal/util/danda/classes/e2;

    invoke-direct {v10, v1, v7}, Lcom/android/internal/util/danda/classes/e2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    const/4 v7, 0x5

    invoke-direct {v8, v5, v7, v10}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v3, v8}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    if-ne v9, v2, :cond_e1

    new-instance v8, Lcom/android/internal/util/danda/classes/g2;

    new-instance v9, Lcom/android/internal/util/danda/classes/k;

    iget v10, p0, Lcom/android/internal/util/danda/classes/g1;->e:I

    int-to-long v10, v10

    invoke-direct {v9, v10, v11}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    const/16 v10, 0xa

    invoke-direct {v8, v5, v10, v9}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v3, v8}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_e1
    new-instance v8, Lcom/android/internal/util/danda/classes/g2;

    sget-object v9, Lcom/android/internal/util/danda/classes/y1;->m:Lcom/android/internal/util/danda/classes/y1;

    const/16 v10, 0x1f7

    invoke-direct {v8, v5, v10, v9}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v3, v8}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v8, Lcom/android/internal/util/danda/classes/g2;

    new-instance v9, Lcom/android/internal/util/danda/classes/k;

    iget-wide v10, p0, Lcom/android/internal/util/danda/classes/g1;->l:J

    invoke-direct {v9, v10, v11}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    const/16 v10, 0x2bd

    invoke-direct {v8, v5, v10, v9}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v3, v8}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v8, Lcom/android/internal/util/danda/classes/g2;

    new-instance v9, Lcom/android/internal/util/danda/classes/k;

    int-to-long v10, v1

    invoke-direct {v9, v10, v11}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    const/16 v10, 0x2be

    invoke-direct {v8, v5, v10, v9}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v3, v8}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v8, Lcom/android/internal/util/danda/classes/g2;

    const/16 v9, 0x2c0

    invoke-direct {v8, v5, v9, v4}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v3, v8}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v4, Lcom/android/internal/util/danda/classes/g2;

    new-instance v8, Lcom/android/internal/util/danda/classes/k;

    iget-wide v9, p0, Lcom/android/internal/util/danda/classes/g1;->i:J

    invoke-direct {v8, v9, v10}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    const/16 v9, 0x2c2

    invoke-direct {v4, v5, v9, v8}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v3, v4}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v4, Lcom/android/internal/util/danda/classes/g2;

    new-instance v8, Lcom/android/internal/util/danda/classes/k;

    iget-wide v9, p0, Lcom/android/internal/util/danda/classes/g1;->j:J

    invoke-direct {v8, v9, v10}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    const/16 v9, 0x2ce

    invoke-direct {v4, v5, v9, v8}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v3, v4}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v4, Lcom/android/internal/util/danda/classes/g2;

    new-instance v8, Lcom/android/internal/util/danda/classes/k;

    iget-wide v9, p0, Lcom/android/internal/util/danda/classes/g1;->k:J

    invoke-direct {v8, v9, v10}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    const/16 v9, 0x2cf

    invoke-direct {v4, v5, v9, v8}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v3, v4}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v4, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v4, v1, v3}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    new-instance v3, Lcom/android/internal/util/danda/classes/f;

    invoke-direct {v3, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    iget-object v8, p0, Lcom/android/internal/util/danda/classes/g1;->c:[B

    if-eqz v8, :cond_168

    new-instance v9, Lcom/android/internal/util/danda/classes/g2;

    new-instance v10, Lcom/android/internal/util/danda/classes/a2;

    invoke-direct {v10, v8}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    const/16 v8, 0x2c5

    invoke-direct {v9, v5, v8, v10}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v3, v9}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_168
    new-instance v8, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v8, v1, v3}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    const/16 v3, 0x8

    new-array v3, v3, [Lcom/android/internal/util/danda/classes/e;

    new-instance v9, Lcom/android/internal/util/danda/classes/k;

    const-wide/16 v10, 0x64

    invoke-direct {v9, v10, v11}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    aput-object v9, v3, v1

    new-instance v9, Lcom/android/internal/util/danda/classes/g;

    invoke-direct {v9, v5}, Lcom/android/internal/util/danda/classes/g;-><init>(I)V

    aput-object v9, v3, v5

    new-instance v9, Lcom/android/internal/util/danda/classes/k;

    invoke-direct {v9, v10, v11}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    aput-object v9, v3, v6

    new-instance v6, Lcom/android/internal/util/danda/classes/g;

    invoke-direct {v6, v5}, Lcom/android/internal/util/danda/classes/g;-><init>(I)V

    aput-object v6, v3, v2

    new-instance v2, Lcom/android/internal/util/danda/classes/a2;

    iget-object p0, p0, Lcom/android/internal/util/danda/classes/g1;->b:[B

    invoke-direct {v2, p0}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    aput-object v2, v3, v0

    new-instance p0, Lcom/android/internal/util/danda/classes/a2;

    new-array v0, v1, [B

    invoke-direct {p0, v0}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    aput-object p0, v3, v7

    const/4 p0, 0x6

    aput-object v8, v3, p0

    const/4 p0, 0x7

    aput-object v4, v3, p0

    new-instance p0, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {p0, v3}, Lcom/android/internal/util/danda/classes/d2;-><init>([Lcom/android/internal/util/danda/classes/e;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/f3;

    sget-object v2, Lcom/android/internal/util/danda/classes/h1;->c:Lcom/android/internal/util/danda/classes/o;

    new-instance v3, Lcom/android/internal/util/danda/classes/a2;

    invoke-direct {v3, p0}, Lcom/android/internal/util/danda/classes/a2;-><init>(Lcom/android/internal/util/danda/classes/d2;)V

    invoke-direct {v0, v2, v1, v3}, Lcom/android/internal/util/danda/classes/f3;-><init>(Lcom/android/internal/util/danda/classes/o;ZLcom/android/internal/util/danda/classes/a2;)V
    :try_end_1b8
    .catch Ljava/lang/Exception; {:try_start_51 .. :try_end_1b8} :catch_1b

    return-object v0

    :goto_1b9
    const-string v0, "OemPorts10TUtils"

    const-string v1, "Error creating attestation ASN.1 extension"

    invoke-static {v0, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 p0, 0x0

    return-object p0
.end method

.method public static e(ILcom/android/internal/util/danda/classes/g1;)Ljava/util/ArrayList;
    .registers 23

    move-object/from16 v0, p1

    const-string v1, "OemPorts10TUtils"

    const-string v2, "No valid keybox found in KeyboxParser for algorithm "

    :try_start_6
    iget v4, v0, Lcom/android/internal/util/danda/classes/g1;->a:I
    :try_end_8
    .catchall {:try_start_6 .. :try_end_8} :catchall_12

    iget-wide v5, v0, Lcom/android/internal/util/danda/classes/g1;->l:J

    const/4 v7, 0x3

    if-ne v4, v7, :cond_15

    :try_start_d
    sget-object v8, Lcom/android/internal/util/danda/classes/b4;->a:Lcom/android/internal/util/danda/classes/o4;

    sget-object v9, Lcom/android/internal/util/danda/classes/b4;->c:Ljava/util/ArrayList;

    goto :goto_19

    :catchall_12
    move-exception v0

    goto/16 :goto_19b

    :cond_15
    sget-object v8, Lcom/android/internal/util/danda/classes/b4;->b:Lcom/android/internal/util/danda/classes/o4;

    sget-object v9, Lcom/android/internal/util/danda/classes/b4;->d:Ljava/util/ArrayList;

    :goto_19
    if-eqz v8, :cond_18a

    if-eqz v9, :cond_18a

    invoke-interface {v9}, Ljava/util/List;->isEmpty()Z

    move-result v10

    if-eqz v10, :cond_25

    goto/16 :goto_18a

    :cond_25
    new-instance v2, Lcom/android/internal/util/danda/classes/x3;

    invoke-direct {v2}, Lcom/android/internal/util/danda/classes/x3;-><init>()V

    iget-object v8, v8, Lcom/android/internal/util/danda/classes/o4;->a:Lcom/android/internal/util/danda/classes/b5;

    invoke-virtual {v2, v8}, Lcom/android/internal/util/danda/classes/x3;->b(Lcom/android/internal/util/danda/classes/b5;)Ljava/security/PrivateKey;

    move-result-object v2

    if-ne v4, v7, :cond_35

    const-string v8, "EC"

    goto :goto_37

    :cond_35
    const-string v8, "RSA"

    :goto_37
    invoke-static {v8}, Ljava/security/KeyPairGenerator;->getInstance(Ljava/lang/String;)Ljava/security/KeyPairGenerator;

    move-result-object v8

    if-ne v4, v7, :cond_48

    new-instance v10, Ljava/security/spec/ECGenParameterSpec;

    const-string v11, "secp256r1"

    invoke-direct {v10, v11}, Ljava/security/spec/ECGenParameterSpec;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v10}, Ljava/security/KeyPairGenerator;->initialize(Ljava/security/spec/AlgorithmParameterSpec;)V

    goto :goto_4d

    :cond_48
    iget v10, v0, Lcom/android/internal/util/danda/classes/g1;->d:I

    invoke-virtual {v8, v10}, Ljava/security/KeyPairGenerator;->initialize(I)V

    :goto_4d
    invoke-virtual {v8}, Ljava/security/KeyPairGenerator;->generateKeyPair()Ljava/security/KeyPair;

    move-result-object v8

    new-instance v10, Lcom/android/internal/util/danda/classes/c6;

    const/4 v11, 0x0

    invoke-interface {v9, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/security/cert/Certificate;

    invoke-virtual {v12}, Ljava/security/cert/Certificate;->getEncoded()[B

    move-result-object v12

    invoke-direct {v10, v12}, Lcom/android/internal/util/danda/classes/c6;-><init>([B)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    invoke-static {v12, v13}, Ljava/math/BigInteger;->valueOf(J)Ljava/math/BigInteger;

    move-result-object v16

    new-instance v12, Ljava/util/Date;

    const-wide/16 v13, 0x2710

    sub-long v13, v5, v13

    invoke-direct {v12, v13, v14}, Ljava/util/Date;-><init>(J)V

    new-instance v13, Ljava/util/Date;

    const-wide v14, 0x496cebb800L

    add-long/2addr v5, v14

    invoke-direct {v13, v5, v6}, Ljava/util/Date;-><init>(J)V

    new-instance v5, Lcom/android/internal/util/danda/classes/y5;

    iget-object v6, v10, Lcom/android/internal/util/danda/classes/c6;->a:Lcom/android/internal/util/danda/classes/e1;

    iget-object v6, v6, Lcom/android/internal/util/danda/classes/e1;->n:Lcom/android/internal/util/danda/classes/s5;

    iget-object v6, v6, Lcom/android/internal/util/danda/classes/s5;->r:Lcom/android/internal/util/danda/classes/x5;

    invoke-static {v6}, Lcom/android/internal/util/danda/classes/x5;->g(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/x5;

    move-result-object v15

    new-instance v19, Lcom/android/internal/util/danda/classes/x5;

    invoke-direct/range {v19 .. v19}, Lcom/android/internal/util/danda/classes/x5;-><init>()V

    invoke-virtual {v8}, Ljava/security/KeyPair;->getPublic()Ljava/security/PublicKey;

    move-result-object v6

    invoke-interface {v6}, Ljava/security/Key;->getEncoded()[B

    move-result-object v6

    invoke-static {v6}, Lcom/android/internal/util/danda/classes/q5;->g(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/q5;

    move-result-object v20

    move-object v14, v5

    move-object/from16 v17, v12

    move-object/from16 v18, v13

    invoke-direct/range {v14 .. v20}, Lcom/android/internal/util/danda/classes/y5;-><init>(Lcom/android/internal/util/danda/classes/x5;Ljava/math/BigInteger;Ljava/util/Date;Ljava/util/Date;Lcom/android/internal/util/danda/classes/x5;Lcom/android/internal/util/danda/classes/q5;)V

    sget-object v6, Lcom/android/internal/util/danda/classes/f3;->p:Lcom/android/internal/util/danda/classes/o;

    new-instance v8, Lcom/android/internal/util/danda/classes/q1;

    const/4 v10, 0x4

    move v12, v7

    :goto_a8
    const/4 v13, 0x1

    const/16 v14, 0x80

    const/16 v15, 0xff

    if-lt v12, v13, :cond_bd

    mul-int/lit8 v16, v12, 0x8

    shl-int v16, v15, v16

    and-int v16, v14, v16

    if-eqz v16, :cond_b8

    goto :goto_bd

    :cond_b8
    add-int/lit8 v10, v10, -0x1

    add-int/lit8 v12, v12, -0x1

    goto :goto_a8

    :cond_bd
    :goto_bd
    new-array v12, v10, [B

    :goto_bf
    if-ge v11, v10, :cond_cc

    mul-int/lit8 v17, v11, 0x8

    shr-int v3, v14, v17

    and-int/2addr v3, v15

    int-to-byte v3, v3

    aput-byte v3, v12, v11

    add-int/lit8 v11, v11, 0x1

    goto :goto_bf

    :cond_cc
    move v3, v7

    :goto_cd
    if-ltz v3, :cond_dd

    if-eqz v3, :cond_de

    mul-int/lit8 v10, v3, 0x8

    shr-int v10, v14, v10

    if-eqz v10, :cond_da

    and-int/lit16 v14, v10, 0xff

    goto :goto_de

    :cond_da
    add-int/lit8 v3, v3, -0x1

    goto :goto_cd

    :cond_dd
    const/4 v14, 0x0

    :cond_de
    :goto_de
    if-nez v14, :cond_e2

    const/4 v11, 0x0

    goto :goto_ed

    :cond_e2
    move v3, v13

    :goto_e3
    shl-int/2addr v14, v13

    and-int/lit16 v10, v14, 0xff

    if-eqz v10, :cond_eb

    add-int/lit8 v3, v3, 0x1

    goto :goto_e3

    :cond_eb
    rsub-int/lit8 v11, v3, 0x8

    :goto_ed
    invoke-direct {v8, v11, v12}, Lcom/android/internal/util/danda/classes/b;-><init>(I[B)V

    iget-object v3, v5, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    check-cast v3, Lcom/android/internal/util/danda/classes/y5;

    sget v10, Lcom/android/internal/util/danda/classes/d1;->a:I
    :try_end_f6
    .catchall {:try_start_d .. :try_end_f6} :catchall_12

    :try_start_f6
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v10, "DER"

    invoke-virtual {v8, v10}, Lcom/android/internal/util/danda/classes/m;->f(Ljava/lang/String;)[B

    move-result-object v8

    iget-object v10, v3, Lcom/android/internal/util/danda/classes/y5;->b:Ljava/lang/Object;

    check-cast v10, Ljava/util/Hashtable;

    invoke-virtual {v10, v6}, Ljava/util/Hashtable;->containsKey(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_158

    iget-object v10, v3, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    check-cast v10, Ljava/util/Vector;

    invoke-virtual {v10, v6}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    iget-object v3, v3, Lcom/android/internal/util/danda/classes/y5;->b:Ljava/lang/Object;

    check-cast v3, Ljava/util/Hashtable;

    new-instance v10, Lcom/android/internal/util/danda/classes/f3;

    new-instance v11, Lcom/android/internal/util/danda/classes/a2;

    invoke-direct {v11, v8}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    invoke-direct {v10, v6, v13, v11}, Lcom/android/internal/util/danda/classes/f3;-><init>(Lcom/android/internal/util/danda/classes/o;ZLcom/android/internal/util/danda/classes/a2;)V

    invoke-virtual {v3, v6, v10}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_121
    .catch Ljava/io/IOException; {:try_start_f6 .. :try_end_121} :catch_171
    .catchall {:try_start_f6 .. :try_end_121} :catchall_12

    :try_start_121
    invoke-static/range {p0 .. p0}, Lcom/android/internal/util/danda/classes/h1;->b(I)[B

    move-result-object v3

    iput-object v3, v0, Lcom/android/internal/util/danda/classes/g1;->c:[B

    invoke-static/range {p1 .. p1}, Lcom/android/internal/util/danda/classes/h1;->d(Lcom/android/internal/util/danda/classes/g1;)Lcom/android/internal/util/danda/classes/f3;

    move-result-object v0

    invoke-virtual {v5, v0}, Lcom/android/internal/util/danda/classes/y5;->a(Lcom/android/internal/util/danda/classes/f3;)V

    new-instance v0, Lcom/android/internal/util/danda/classes/n4;

    if-ne v4, v7, :cond_135

    const-string v3, "SHA256withECDSA"

    goto :goto_137

    :cond_135
    const-string v3, "SHA256withRSA"

    :goto_137
    invoke-direct {v0, v3}, Lcom/android/internal/util/danda/classes/n4;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Lcom/android/internal/util/danda/classes/n4;->a(Ljava/security/PrivateKey;)Lcom/android/internal/util/danda/classes/n4;

    move-result-object v0

    new-instance v2, Lcom/android/internal/util/danda/classes/f;

    const/4 v3, 0x2

    invoke-direct {v2, v3}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    invoke-virtual {v5, v0}, Lcom/android/internal/util/danda/classes/y5;->c(Lcom/android/internal/util/danda/classes/n4;)Lcom/android/internal/util/danda/classes/c6;

    move-result-object v0

    invoke-virtual {v2, v0}, Lcom/android/internal/util/danda/classes/f;->c(Lcom/android/internal/util/danda/classes/c6;)Ljava/security/cert/X509Certificate;

    move-result-object v0

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z
    :try_end_157
    .catchall {:try_start_121 .. :try_end_157} :catchall_12

    return-object v2

    :cond_158
    :try_start_158
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "extension "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v3, " already added"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_171
    .catch Ljava/io/IOException; {:try_start_158 .. :try_end_171} :catch_171
    .catchall {:try_start_158 .. :try_end_171} :catchall_12

    :catch_171
    move-exception v0

    :try_start_172
    new-instance v2, Lcom/android/internal/util/danda/classes/h;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "cannot encode extension: "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3, v0, v13}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v2

    :cond_18a
    :goto_18a
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_199
    .catchall {:try_start_172 .. :try_end_199} :catchall_12

    const/4 v1, 0x0

    return-object v1

    :goto_19b
    const-string v2, "Failed to generate hardware-backed cert chain"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v1, 0x0

    return-object v1
.end method

.method public static f([B)[Ljava/security/cert/Certificate;
    .registers 21

    move-object/from16 v0, p0

    const-string v1, "persist.sys.oemports10t.utils.patchlevel"

    sget-object v2, Lcom/android/internal/util/danda/classes/h1;->c:Lcom/android/internal/util/danda/classes/o;

    if-eqz v0, :cond_b

    array-length v4, v0

    if-nez v4, :cond_e

    :cond_b
    const/4 v1, 0x0

    goto/16 :goto_24a

    :cond_e
    :try_start_e
    const-string v4, "X.509"

    invoke-static {v4}, Ljava/security/cert/CertificateFactory;->getInstance(Ljava/lang/String;)Ljava/security/cert/CertificateFactory;

    move-result-object v4

    new-instance v5, Ljava/io/ByteArrayInputStream;

    invoke-direct {v5, v0}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-virtual {v4, v5}, Ljava/security/cert/CertificateFactory;->generateCertificate(Ljava/io/InputStream;)Ljava/security/cert/Certificate;

    move-result-object v4

    check-cast v4, Ljava/security/cert/X509Certificate;

    new-instance v5, Lcom/android/internal/util/danda/classes/c6;

    invoke-direct {v5, v0}, Lcom/android/internal/util/danda/classes/c6;-><init>([B)V

    const-string v0, "EC"

    invoke-virtual {v4}, Ljava/security/cert/Certificate;->getPublicKey()Ljava/security/PublicKey;

    move-result-object v6

    invoke-interface {v6}, Ljava/security/Key;->getAlgorithm()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3a

    sget-object v6, Lcom/android/internal/util/danda/classes/b4;->a:Lcom/android/internal/util/danda/classes/o4;

    goto :goto_3c

    :catchall_37
    move-exception v0

    goto/16 :goto_242

    :cond_3a
    sget-object v6, Lcom/android/internal/util/danda/classes/b4;->b:Lcom/android/internal/util/danda/classes/o4;

    :goto_3c
    if-eqz v0, :cond_41

    sget-object v7, Lcom/android/internal/util/danda/classes/b4;->c:Ljava/util/ArrayList;

    goto :goto_43

    :cond_41
    sget-object v7, Lcom/android/internal/util/danda/classes/b4;->d:Ljava/util/ArrayList;

    :goto_43
    if-eqz v6, :cond_4d

    if-eqz v7, :cond_4d

    invoke-interface {v7}, Ljava/util/List;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_50

    :cond_4d
    const/4 v1, 0x0

    goto/16 :goto_241

    :cond_50
    new-instance v8, Lcom/android/internal/util/danda/classes/y5;

    new-instance v9, Lcom/android/internal/util/danda/classes/c6;

    const/4 v15, 0x0

    invoke-interface {v7, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/security/cert/Certificate;

    invoke-virtual {v10}, Ljava/security/cert/Certificate;->getEncoded()[B

    move-result-object v10

    invoke-direct {v9, v10}, Lcom/android/internal/util/danda/classes/c6;-><init>([B)V

    iget-object v9, v9, Lcom/android/internal/util/danda/classes/c6;->a:Lcom/android/internal/util/danda/classes/e1;

    iget-object v9, v9, Lcom/android/internal/util/danda/classes/e1;->n:Lcom/android/internal/util/danda/classes/s5;

    iget-object v9, v9, Lcom/android/internal/util/danda/classes/s5;->r:Lcom/android/internal/util/danda/classes/x5;

    invoke-static {v9}, Lcom/android/internal/util/danda/classes/x5;->g(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/x5;

    move-result-object v10

    iget-object v9, v5, Lcom/android/internal/util/danda/classes/c6;->a:Lcom/android/internal/util/danda/classes/e1;

    iget-object v9, v9, Lcom/android/internal/util/danda/classes/e1;->n:Lcom/android/internal/util/danda/classes/s5;

    iget-object v9, v9, Lcom/android/internal/util/danda/classes/s5;->o:Lcom/android/internal/util/danda/classes/k;

    invoke-virtual {v9}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v11

    iget-object v9, v5, Lcom/android/internal/util/danda/classes/c6;->a:Lcom/android/internal/util/danda/classes/e1;

    iget-object v9, v9, Lcom/android/internal/util/danda/classes/e1;->n:Lcom/android/internal/util/danda/classes/s5;

    iget-object v9, v9, Lcom/android/internal/util/danda/classes/s5;->p:Lcom/android/internal/util/danda/classes/u5;

    invoke-virtual {v9}, Lcom/android/internal/util/danda/classes/u5;->g()Ljava/util/Date;

    move-result-object v12

    iget-object v9, v5, Lcom/android/internal/util/danda/classes/c6;->a:Lcom/android/internal/util/danda/classes/e1;

    iget-object v9, v9, Lcom/android/internal/util/danda/classes/e1;->n:Lcom/android/internal/util/danda/classes/s5;

    iget-object v9, v9, Lcom/android/internal/util/danda/classes/s5;->q:Lcom/android/internal/util/danda/classes/u5;

    invoke-virtual {v9}, Lcom/android/internal/util/danda/classes/u5;->g()Ljava/util/Date;

    move-result-object v13

    iget-object v9, v5, Lcom/android/internal/util/danda/classes/c6;->a:Lcom/android/internal/util/danda/classes/e1;

    iget-object v9, v9, Lcom/android/internal/util/danda/classes/e1;->n:Lcom/android/internal/util/danda/classes/s5;

    iget-object v9, v9, Lcom/android/internal/util/danda/classes/s5;->r:Lcom/android/internal/util/danda/classes/x5;

    invoke-static {v9}, Lcom/android/internal/util/danda/classes/x5;->g(Lcom/android/internal/util/danda/classes/e;)Lcom/android/internal/util/danda/classes/x5;

    move-result-object v14

    invoke-virtual {v4}, Ljava/security/cert/Certificate;->getPublicKey()Ljava/security/PublicKey;

    move-result-object v4

    invoke-interface {v4}, Ljava/security/Key;->getEncoded()[B

    move-result-object v4

    invoke-static {v4}, Lcom/android/internal/util/danda/classes/q5;->g(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/q5;

    move-result-object v4

    move-object v9, v8

    move v3, v15

    move-object v15, v4

    invoke-direct/range {v9 .. v15}, Lcom/android/internal/util/danda/classes/y5;-><init>(Lcom/android/internal/util/danda/classes/x5;Ljava/math/BigInteger;Ljava/util/Date;Ljava/util/Date;Lcom/android/internal/util/danda/classes/x5;Lcom/android/internal/util/danda/classes/q5;)V

    iget-object v4, v5, Lcom/android/internal/util/danda/classes/c6;->b:Lcom/android/internal/util/danda/classes/g3;

    if-eqz v4, :cond_203

    iget-object v4, v4, Lcom/android/internal/util/danda/classes/g3;->n:Ljava/util/Vector;

    invoke-virtual {v4}, Ljava/util/Vector;->size()I

    move-result v10

    new-array v11, v10, [Lcom/android/internal/util/danda/classes/o;

    move v15, v3

    :goto_b3
    if-eq v15, v10, :cond_c0

    invoke-virtual {v4, v15}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lcom/android/internal/util/danda/classes/o;

    aput-object v12, v11, v15

    add-int/lit8 v15, v15, 0x1

    goto :goto_b3

    :cond_c0
    move v15, v3

    :goto_c1
    if-ge v15, v10, :cond_203

    aget-object v4, v11, v15

    invoke-virtual {v2, v4}, Lcom/android/internal/util/danda/classes/t;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_1e9

    iget-object v4, v5, Lcom/android/internal/util/danda/classes/c6;->b:Lcom/android/internal/util/danda/classes/g3;

    if-eqz v4, :cond_d8

    iget-object v4, v4, Lcom/android/internal/util/danda/classes/g3;->m:Ljava/util/Hashtable;

    invoke-virtual {v4, v2}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/internal/util/danda/classes/f3;

    goto :goto_d9

    :cond_d8
    const/4 v4, 0x0

    :goto_d9
    iget-object v4, v4, Lcom/android/internal/util/danda/classes/f3;->o:Lcom/android/internal/util/danda/classes/p;

    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/p;->o()[B

    move-result-object v4

    invoke-static {v4}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object v4

    invoke-virtual {v4}, Lcom/android/internal/util/danda/classes/u;->s()[Lcom/android/internal/util/danda/classes/e;

    move-result-object v4

    const/4 v12, 0x7

    aget-object v13, v4, v12

    check-cast v13, Lcom/android/internal/util/danda/classes/u;

    new-instance v14, Lcom/android/internal/util/danda/classes/f;

    invoke-direct {v14, v3}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    invoke-virtual {v13}, Lcom/android/internal/util/danda/classes/u;->iterator()Ljava/util/Iterator;

    move-result-object v13

    const/16 v16, 0x0

    :goto_f7
    move-object/from16 v17, v13

    check-cast v17, Lcom/android/internal/util/danda/classes/e0;

    invoke-virtual/range {v17 .. v17}, Lcom/android/internal/util/danda/classes/e0;->hasNext()Z

    move-result v18

    const/16 v12, 0x2c0

    if-eqz v18, :cond_132

    invoke-virtual/range {v17 .. v17}, Lcom/android/internal/util/danda/classes/e0;->next()Ljava/lang/Object;

    move-result-object v17

    move-object/from16 v9, v17

    check-cast v9, Lcom/android/internal/util/danda/classes/e;

    move-object v3, v9

    check-cast v3, Lcom/android/internal/util/danda/classes/a0;

    move/from16 v19, v10

    iget v10, v3, Lcom/android/internal/util/danda/classes/a0;->m:I

    if-ne v10, v12, :cond_121

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object v3

    move-object/from16 v16, v3

    check-cast v16, Lcom/android/internal/util/danda/classes/u;

    :cond_11c
    :goto_11c
    move/from16 v10, v19

    const/4 v3, 0x0

    const/4 v12, 0x7

    goto :goto_f7

    :cond_121
    const/16 v3, 0x2c2

    if-eq v10, v3, :cond_11c

    const/16 v3, 0x2ce

    if-eq v10, v3, :cond_11c

    const/16 v3, 0x2cf

    if-ne v10, v3, :cond_12e

    goto :goto_11c

    :cond_12e
    invoke-virtual {v14, v9}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    goto :goto_11c

    :cond_132
    move/from16 v19, v10

    const/4 v3, 0x1

    if-eqz v16, :cond_17f

    const/16 v9, 0x20

    new-array v10, v9, [B

    invoke-static {}, Ljava/util/concurrent/ThreadLocalRandom;->current()Ljava/util/concurrent/ThreadLocalRandom;

    move-result-object v13

    invoke-virtual {v13, v10}, Ljava/util/Random;->nextBytes([B)V

    invoke-static {}, Lcom/android/internal/util/danda/classes/m5;->e()[B

    move-result-object v13

    if-nez v13, :cond_151

    new-array v13, v9, [B

    invoke-static {}, Ljava/util/concurrent/ThreadLocalRandom;->current()Ljava/util/concurrent/ThreadLocalRandom;

    move-result-object v9

    invoke-virtual {v9, v13}, Ljava/util/Random;->nextBytes([B)V

    :cond_151
    const/4 v9, 0x4

    new-array v9, v9, [Lcom/android/internal/util/danda/classes/e;

    new-instance v12, Lcom/android/internal/util/danda/classes/a2;

    invoke-direct {v12, v10}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    const/4 v10, 0x0

    aput-object v12, v9, v10

    sget-object v12, Lcom/android/internal/util/danda/classes/c;->q:Lcom/android/internal/util/danda/classes/c;

    aput-object v12, v9, v3

    new-instance v12, Lcom/android/internal/util/danda/classes/g;

    invoke-direct {v12, v10}, Lcom/android/internal/util/danda/classes/g;-><init>(I)V

    const/4 v10, 0x2

    aput-object v12, v9, v10

    new-instance v10, Lcom/android/internal/util/danda/classes/a2;

    invoke-direct {v10, v13}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    const/4 v12, 0x3

    aput-object v10, v9, v12

    new-instance v10, Lcom/android/internal/util/danda/classes/g2;

    new-instance v12, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v12, v9}, Lcom/android/internal/util/danda/classes/d2;-><init>([Lcom/android/internal/util/danda/classes/e;)V

    const/16 v9, 0x2c0

    invoke-direct {v10, v3, v9, v12}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v14, v10}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    :cond_17f
    new-instance v9, Lcom/android/internal/util/danda/classes/g2;

    new-instance v10, Lcom/android/internal/util/danda/classes/k;

    sget v12, Lcom/android/internal/util/danda/classes/m5;->a:I

    invoke-static {v1}, Landroid/os/SystemProperties;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    move-object/from16 v16, v4

    const/4 v13, 0x0

    invoke-static {v12, v13}, Lcom/android/internal/util/danda/classes/m5;->a(Ljava/lang/String;Z)J

    move-result-wide v3

    invoke-direct {v10, v3, v4}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    const/16 v3, 0x2c2

    const/4 v4, 0x1

    invoke-direct {v9, v4, v3, v10}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v14, v9}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v3, Lcom/android/internal/util/danda/classes/g2;

    new-instance v9, Lcom/android/internal/util/danda/classes/k;

    invoke-static {v1}, Landroid/os/SystemProperties;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10, v4}, Lcom/android/internal/util/danda/classes/m5;->a(Ljava/lang/String;Z)J

    move-result-wide v12

    invoke-direct {v9, v12, v13}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    const/16 v10, 0x2ce

    invoke-direct {v3, v4, v10, v9}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v14, v3}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v3, Lcom/android/internal/util/danda/classes/g2;

    new-instance v9, Lcom/android/internal/util/danda/classes/k;

    invoke-static {v1}, Landroid/os/SystemProperties;->get(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10, v4}, Lcom/android/internal/util/danda/classes/m5;->a(Ljava/lang/String;Z)J

    move-result-wide v12

    invoke-direct {v9, v12, v13}, Lcom/android/internal/util/danda/classes/k;-><init>(J)V

    const/16 v10, 0x2cf

    invoke-direct {v3, v4, v10, v9}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v14, v3}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v3, Lcom/android/internal/util/danda/classes/d2;

    const/4 v4, 0x0

    invoke-direct {v3, v4, v14}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    const/4 v4, 0x7

    aput-object v3, v16, v4

    new-instance v3, Lcom/android/internal/util/danda/classes/a2;

    new-instance v4, Lcom/android/internal/util/danda/classes/d2;

    move-object/from16 v9, v16

    invoke-direct {v4, v9}, Lcom/android/internal/util/danda/classes/d2;-><init>([Lcom/android/internal/util/danda/classes/e;)V

    invoke-direct {v3, v4}, Lcom/android/internal/util/danda/classes/a2;-><init>(Lcom/android/internal/util/danda/classes/d2;)V

    new-instance v4, Lcom/android/internal/util/danda/classes/f3;

    const/4 v9, 0x0

    invoke-direct {v4, v2, v9, v3}, Lcom/android/internal/util/danda/classes/f3;-><init>(Lcom/android/internal/util/danda/classes/o;ZLcom/android/internal/util/danda/classes/a2;)V

    invoke-virtual {v8, v4}, Lcom/android/internal/util/danda/classes/y5;->a(Lcom/android/internal/util/danda/classes/f3;)V

    goto :goto_1fc

    :cond_1e9
    move/from16 v19, v10

    iget-object v3, v5, Lcom/android/internal/util/danda/classes/c6;->b:Lcom/android/internal/util/danda/classes/g3;

    if-eqz v3, :cond_1f8

    iget-object v3, v3, Lcom/android/internal/util/danda/classes/g3;->m:Ljava/util/Hashtable;

    invoke-virtual {v3, v4}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/internal/util/danda/classes/f3;

    goto :goto_1f9

    :cond_1f8
    const/4 v3, 0x0

    :goto_1f9
    invoke-virtual {v8, v3}, Lcom/android/internal/util/danda/classes/y5;->a(Lcom/android/internal/util/danda/classes/f3;)V

    :goto_1fc
    add-int/lit8 v15, v15, 0x1

    move/from16 v10, v19

    const/4 v3, 0x0

    goto/16 :goto_c1

    :cond_203
    new-instance v1, Lcom/android/internal/util/danda/classes/x3;

    invoke-direct {v1}, Lcom/android/internal/util/danda/classes/x3;-><init>()V

    iget-object v2, v6, Lcom/android/internal/util/danda/classes/o4;->a:Lcom/android/internal/util/danda/classes/b5;

    invoke-virtual {v1, v2}, Lcom/android/internal/util/danda/classes/x3;->b(Lcom/android/internal/util/danda/classes/b5;)Ljava/security/PrivateKey;

    move-result-object v1

    new-instance v2, Lcom/android/internal/util/danda/classes/n4;

    if-eqz v0, :cond_215

    const-string v0, "SHA256withECDSA"

    goto :goto_217

    :cond_215
    const-string v0, "SHA256withRSA"

    :goto_217
    invoke-direct {v2, v0}, Lcom/android/internal/util/danda/classes/n4;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Lcom/android/internal/util/danda/classes/n4;->a(Ljava/security/PrivateKey;)Lcom/android/internal/util/danda/classes/n4;

    move-result-object v0

    new-instance v1, Lcom/android/internal/util/danda/classes/f;

    const/4 v2, 0x2

    invoke-direct {v1, v2}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    invoke-virtual {v8, v0}, Lcom/android/internal/util/danda/classes/y5;->c(Lcom/android/internal/util/danda/classes/n4;)Lcom/android/internal/util/danda/classes/c6;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcom/android/internal/util/danda/classes/f;->c(Lcom/android/internal/util/danda/classes/c6;)Ljava/security/cert/X509Certificate;

    move-result-object v0

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/security/cert/Certificate;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/security/cert/Certificate;
    :try_end_240
    .catchall {:try_start_e .. :try_end_240} :catchall_37

    return-object v0

    :goto_241
    return-object v1

    :goto_242
    const-string v1, "OemPorts10TUtils"

    const-string v2, "Failed to hack cert chain"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v1, 0x0

    :goto_24a
    return-object v1
.end method

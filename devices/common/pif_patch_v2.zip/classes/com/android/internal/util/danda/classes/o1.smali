.class public interface abstract Lcom/android/internal/util/danda/classes/o1;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lcom/android/internal/util/danda/classes/o;

.field public static final b:Lcom/android/internal/util/danda/classes/o;

.field public static final c:Lcom/android/internal/util/danda/classes/o;

.field public static final d:Lcom/android/internal/util/danda/classes/o;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, Lcom/android/internal/util/danda/classes/o;

    const-string v1, "1.2.643.2.2"

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/o;-><init>(Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "9"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/o1;->a:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "10"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "13.0"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "13.1"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "21"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "31.0"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "31.1"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "31.2"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "31.3"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "31.4"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "20"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "19"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/o1;->b:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "4"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/o1;->c:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "3"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    sput-object v1, Lcom/android/internal/util/danda/classes/o1;->d:Lcom/android/internal/util/danda/classes/o;

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "30.1"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "32.2"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "32.3"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "32.4"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "32.5"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "33.1"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "33.2"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "33.3"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "35.1"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "35.2"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "35.3"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "36.0"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v3, "36.1"

    invoke-direct {v1, v0, v3}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    invoke-direct {v1, v0, v3}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "96"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/o;

    const-string v2, "98"

    invoke-direct {v1, v0, v2}, Lcom/android/internal/util/danda/classes/o;-><init>(Lcom/android/internal/util/danda/classes/o;Ljava/lang/String;)V

    return-void
.end method

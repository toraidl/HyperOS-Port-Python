.class public final Lcom/android/internal/util/danda/classes/j3;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:[I


# direct methods
.method public constructor <init>([I)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    array-length v0, p1

    new-array v0, v0, [I

    array-length v1, p1

    const/4 v2, 0x0

    invoke-static {p1, v2, v0, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/j3;->a:[I

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    if-ne p0, p1, :cond_4

    const/4 p1, 0x1

    return p1

    :cond_4
    instance-of v0, p1, Lcom/android/internal/util/danda/classes/j3;

    if-nez v0, :cond_a

    const/4 p1, 0x0

    return p1

    :cond_a
    check-cast p1, Lcom/android/internal/util/danda/classes/j3;

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/j3;->a:[I

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/j3;->a:[I

    invoke-static {v0, p1}, Lcom/android/internal/util/danda/classes/c0;->d([I[I)Z

    move-result p1

    return p1
.end method

.method public final hashCode()I
    .registers 5

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/j3;->a:[I

    if-nez v0, :cond_6

    const/4 v0, 0x0

    goto :goto_14

    :cond_6
    array-length v1, v0

    add-int/lit8 v2, v1, 0x1

    :goto_9
    add-int/lit8 v1, v1, -0x1

    if-ltz v1, :cond_13

    mul-int/lit16 v2, v2, 0x101

    aget v3, v0, v1

    xor-int/2addr v2, v3

    goto :goto_9

    :cond_13
    move v0, v2

    :goto_14
    return v0
.end method

.class public final Lcom/android/internal/util/danda/classes/z3;
.super Ljava/security/cert/CertificateParsingException;
.source "SourceFile"


# instance fields
.field public a:Ljava/lang/Throwable;


# virtual methods
.method public final getCause()Ljava/lang/Throwable;
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/z3;->a:Ljava/lang/Throwable;

    return-object v0
.end method

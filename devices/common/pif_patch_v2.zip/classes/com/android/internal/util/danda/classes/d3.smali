.class public final Lcom/android/internal/util/danda/classes/d3;
.super Lcom/android/internal/util/danda/classes/m;
.source "SourceFile"


# instance fields
.field public m:Lcom/android/internal/util/danda/classes/u;


# virtual methods
.method public final d()Lcom/android/internal/util/danda/classes/t;
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/d3;->m:Lcom/android/internal/util/danda/classes/u;

    return-object v0
.end method

.method public final g(I)Lcom/android/internal/util/danda/classes/t;
    .registers 5

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/d3;->m:Lcom/android/internal/util/danda/classes/u;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/u;->q()Ljava/util/Enumeration;

    move-result-object v0

    :cond_6
    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v1

    if-eqz v1, :cond_24

    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/e;

    instance-of v2, v1, Lcom/android/internal/util/danda/classes/a0;

    if-eqz v2, :cond_6

    check-cast v1, Lcom/android/internal/util/danda/classes/a0;

    iget v2, v1, Lcom/android/internal/util/danda/classes/a0;->m:I

    if-ne v2, p1, :cond_6

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p1

    :cond_24
    const/4 p1, 0x0

    return-object p1
.end method

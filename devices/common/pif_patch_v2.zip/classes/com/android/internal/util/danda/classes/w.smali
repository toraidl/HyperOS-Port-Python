.class public abstract Lcom/android/internal/util/danda/classes/w;
.super Lcom/android/internal/util/danda/classes/t;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Iterable;


# instance fields
.field public m:Ljava/util/Vector;

.field public n:Z


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/internal/util/danda/classes/w;->n:Z

    return-void
.end method

.method public constructor <init>(Lcom/android/internal/util/danda/classes/f;Z)V
    .registers 6

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/internal/util/danda/classes/w;->n:Z

    .line 5
    :goto_d
    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/f;->f()I

    move-result v1

    if-eq v0, v1, :cond_1f

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    .line 6
    invoke-virtual {p1, v0}, Lcom/android/internal/util/danda/classes/f;->b(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_d

    :cond_1f
    if-eqz p2, :cond_24

    .line 7
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/w;->p()V

    :cond_24
    return-void
.end method

.method public constructor <init>(Lcom/android/internal/util/danda/classes/t;)V
    .registers 4

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/android/internal/util/danda/classes/w;->n:Z

    .line 10
    invoke-virtual {v0, p1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    return-void
.end method

.method public constructor <init>([Lcom/android/internal/util/danda/classes/e;Z)V
    .registers 6

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    iput-object v0, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/android/internal/util/danda/classes/w;->n:Z

    .line 13
    :goto_d
    array-length v1, p1

    if-eq v0, v1, :cond_1a

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    .line 14
    aget-object v2, p1, v0

    invoke-virtual {v1, v2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_d

    :cond_1a
    if-eqz p2, :cond_1f

    .line 15
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/w;->p()V

    :cond_1f
    return-void
.end method

.method public static n(Lcom/android/internal/util/danda/classes/a0;)Lcom/android/internal/util/danda/classes/w;
    .registers 3

    iget-boolean v0, p0, Lcom/android/internal/util/danda/classes/a0;->n:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_1d

    instance-of v0, p0, Lcom/android/internal/util/danda/classes/y0;

    if-eqz v0, :cond_13

    new-instance v0, Lcom/android/internal/util/danda/classes/w0;

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object p0

    invoke-direct {v0, p0}, Lcom/android/internal/util/danda/classes/w;-><init>(Lcom/android/internal/util/danda/classes/t;)V

    return-object v0

    :cond_13
    new-instance v0, Lcom/android/internal/util/danda/classes/e2;

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object p0

    invoke-direct {v0, v1, p0}, Lcom/android/internal/util/danda/classes/e2;-><init>(ILcom/android/internal/util/danda/classes/t;)V

    return-object v0

    :cond_1d
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    instance-of v0, v0, Lcom/android/internal/util/danda/classes/w;

    if-eqz v0, :cond_2c

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object p0

    check-cast p0, Lcom/android/internal/util/danda/classes/w;

    return-object p0

    :cond_2c
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    instance-of v0, v0, Lcom/android/internal/util/danda/classes/u;

    if-eqz v0, :cond_53

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    check-cast v0, Lcom/android/internal/util/danda/classes/u;

    instance-of p0, p0, Lcom/android/internal/util/danda/classes/y0;

    if-eqz p0, :cond_49

    new-instance p0, Lcom/android/internal/util/danda/classes/w0;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/u;->s()[Lcom/android/internal/util/danda/classes/e;

    move-result-object v0

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Lcom/android/internal/util/danda/classes/w;-><init>([Lcom/android/internal/util/danda/classes/e;Z)V

    return-object p0

    :cond_49
    new-instance p0, Lcom/android/internal/util/danda/classes/e2;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/u;->s()[Lcom/android/internal/util/danda/classes/e;

    move-result-object v0

    invoke-direct {p0, v0, v1}, Lcom/android/internal/util/danda/classes/e2;-><init>([Lcom/android/internal/util/danda/classes/e;I)V

    return-object p0

    :cond_53
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const-string v1, "unknown object in getInstance: "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/w;
    .registers 4

    if-eqz p0, :cond_66

    instance-of v0, p0, Lcom/android/internal/util/danda/classes/w;

    if-eqz v0, :cond_7

    goto :goto_66

    :cond_7
    instance-of v0, p0, Lcom/android/internal/util/danda/classes/x;

    if-eqz v0, :cond_18

    check-cast p0, Lcom/android/internal/util/danda/classes/x;

    check-cast p0, Lcom/android/internal/util/danda/classes/x0;

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/x0;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object p0

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/w;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/w;

    move-result-object p0

    return-object p0

    :cond_18
    instance-of v0, p0, [B

    if-eqz v0, :cond_40

    :try_start_1c
    check-cast p0, [B

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/t;->j([B)Lcom/android/internal/util/danda/classes/t;

    move-result-object p0

    invoke-static {p0}, Lcom/android/internal/util/danda/classes/w;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/w;

    move-result-object p0
    :try_end_26
    .catch Ljava/io/IOException; {:try_start_1c .. :try_end_26} :catch_27

    return-object p0

    :catch_27
    move-exception p0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "failed to construct set from byte[]: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_40
    instance-of v0, p0, Lcom/android/internal/util/danda/classes/e;

    if-eqz v0, :cond_52

    move-object v0, p0

    check-cast v0, Lcom/android/internal/util/danda/classes/e;

    invoke-interface {v0}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v0

    instance-of v1, v0, Lcom/android/internal/util/danda/classes/w;

    if-eqz v1, :cond_52

    check-cast v0, Lcom/android/internal/util/danda/classes/w;

    return-object v0

    :cond_52
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const-string v1, "unknown object in getInstance: "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_66
    :goto_66
    check-cast p0, Lcom/android/internal/util/danda/classes/w;

    return-object p0
.end method


# virtual methods
.method public final g(Lcom/android/internal/util/danda/classes/t;)Z
    .registers 7

    instance-of v0, p1, Lcom/android/internal/util/danda/classes/w;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return v1

    :cond_6
    check-cast p1, Lcom/android/internal/util/danda/classes/w;

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    iget-object v2, p1, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v2}, Ljava/util/Vector;->size()I

    move-result v2

    if-eq v0, v2, :cond_17

    return v1

    :cond_17
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->elements()Ljava/util/Enumeration;

    move-result-object v0

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {p1}, Ljava/util/Vector;->elements()Ljava/util/Enumeration;

    move-result-object p1

    :cond_23
    :goto_23
    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v2

    if-eqz v2, :cond_50

    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/internal/util/danda/classes/e;

    sget-object v3, Lcom/android/internal/util/danda/classes/y1;->m:Lcom/android/internal/util/danda/classes/y1;

    if-nez v2, :cond_34

    move-object v2, v3

    :cond_34
    invoke-interface {p1}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/internal/util/danda/classes/e;

    if-nez v4, :cond_3d

    goto :goto_3e

    :cond_3d
    move-object v3, v4

    :goto_3e
    invoke-interface {v2}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v2

    invoke-interface {v3}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v3

    if-eq v2, v3, :cond_23

    invoke-virtual {v2, v3}, Lcom/android/internal/util/danda/classes/t;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4f

    goto :goto_23

    :cond_4f
    return v1

    :cond_50
    const/4 p1, 0x1

    return p1
.end method

.method public final hashCode()I
    .registers 4

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->elements()Ljava/util/Enumeration;

    move-result-object v0

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v1}, Ljava/util/Vector;->size()I

    move-result v1

    :goto_c
    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v2

    if-eqz v2, :cond_24

    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/internal/util/danda/classes/e;

    if-nez v2, :cond_1c

    sget-object v2, Lcom/android/internal/util/danda/classes/y1;->m:Lcom/android/internal/util/danda/classes/y1;

    :cond_1c
    mul-int/lit8 v1, v1, 0x11

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    xor-int/2addr v1, v2

    goto :goto_c

    :cond_24
    return v1
.end method

.method public final iterator()Ljava/util/Iterator;
    .registers 5

    new-instance v0, Lcom/android/internal/util/danda/classes/e0;

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v1}, Ljava/util/Vector;->size()I

    move-result v1

    new-array v1, v1, [Lcom/android/internal/util/danda/classes/e;

    const/4 v2, 0x0

    :goto_b
    iget-object v3, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v3}, Ljava/util/Vector;->size()I

    move-result v3

    if-eq v2, v3, :cond_20

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v3, v2}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/android/internal/util/danda/classes/e;

    aput-object v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_b

    :cond_20
    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/e0;-><init>([Ljava/lang/Object;)V

    return-object v0
.end method

.method public final k()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public final l()Lcom/android/internal/util/danda/classes/t;
    .registers 5

    iget-boolean v0, p0, Lcom/android/internal/util/danda/classes/w;->n:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_f

    new-instance v0, Lcom/android/internal/util/danda/classes/e2;

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/e2;-><init>(I)V

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    return-object v0

    :cond_f
    new-instance v0, Ljava/util/Vector;

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    move v2, v1

    :goto_15
    iget-object v3, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v3}, Ljava/util/Vector;->size()I

    move-result v3

    if-eq v2, v3, :cond_29

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v3, v2}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_15

    :cond_29
    new-instance v2, Lcom/android/internal/util/danda/classes/e2;

    invoke-direct {v2, v1}, Lcom/android/internal/util/danda/classes/e2;-><init>(I)V

    iput-object v0, v2, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/w;->p()V

    return-object v2
.end method

.method public final m()Lcom/android/internal/util/danda/classes/t;
    .registers 3

    new-instance v0, Lcom/android/internal/util/danda/classes/e2;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/e2;-><init>(I)V

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    iput-object v1, v0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    return-object v0
.end method

.method public final p()V
    .registers 16

    const-string v0, "cannot encode object added to SET"

    const-string v1, "DER"

    iget-boolean v2, p0, Lcom/android/internal/util/danda/classes/w;->n:Z

    if-nez v2, :cond_8b

    const/4 v2, 0x1

    iput-boolean v2, p0, Lcom/android/internal/util/danda/classes/w;->n:Z

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v3}, Ljava/util/Vector;->size()I

    move-result v3

    if-le v3, v2, :cond_8b

    iget-object v3, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v3}, Ljava/util/Vector;->size()I

    move-result v3

    sub-int/2addr v3, v2

    move v4, v2

    :goto_1b
    if-eqz v4, :cond_8b

    iget-object v4, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/android/internal/util/danda/classes/e;

    :try_start_26
    invoke-interface {v4}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v4

    invoke-virtual {v4, v1}, Lcom/android/internal/util/danda/classes/m;->f(Ljava/lang/String;)[B

    move-result-object v4
    :try_end_2e
    .catch Ljava/io/IOException; {:try_start_26 .. :try_end_2e} :catch_85

    move-object v7, v4

    move v4, v5

    move v6, v4

    move v8, v6

    :goto_32
    if-eq v8, v3, :cond_82

    iget-object v9, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    add-int/lit8 v10, v8, 0x1

    invoke-virtual {v9, v10}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lcom/android/internal/util/danda/classes/e;

    :try_start_3e
    invoke-interface {v9}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v9

    invoke-virtual {v9, v1}, Lcom/android/internal/util/danda/classes/m;->f(Ljava/lang/String;)[B

    move-result-object v9
    :try_end_46
    .catch Ljava/io/IOException; {:try_start_3e .. :try_end_46} :catch_7c

    array-length v11, v7

    array-length v12, v9

    invoke-static {v11, v12}, Ljava/lang/Math;->min(II)I

    move-result v11

    move v12, v5

    :goto_4d
    if-eq v12, v11, :cond_5f

    aget-byte v13, v7, v12

    aget-byte v14, v9, v12

    if-eq v13, v14, :cond_5c

    and-int/lit16 v11, v13, 0xff

    and-int/lit16 v12, v14, 0xff

    if-ge v11, v12, :cond_64

    goto :goto_62

    :cond_5c
    add-int/lit8 v12, v12, 0x1

    goto :goto_4d

    :cond_5f
    array-length v12, v7

    if-ne v11, v12, :cond_64

    :goto_62
    move-object v7, v9

    goto :goto_7a

    :cond_64
    iget-object v4, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v4, v8}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v4

    iget-object v6, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v6, v10}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v6, v9, v8}, Ljava/util/Vector;->setElementAt(Ljava/lang/Object;I)V

    iget-object v6, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v6, v4, v10}, Ljava/util/Vector;->setElementAt(Ljava/lang/Object;I)V

    move v6, v2

    move v4, v8

    :goto_7a
    move v8, v10

    goto :goto_32

    :catch_7c
    new-instance v1, Ljava/lang/IllegalArgumentException;

    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_82
    move v3, v4

    move v4, v6

    goto :goto_1b

    :catch_85
    new-instance v1, Ljava/lang/IllegalArgumentException;

    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_8b
    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

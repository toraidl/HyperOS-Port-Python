.class public final Lcom/android/internal/util/danda/classes/r1;
.super Lcom/android/internal/util/danda/classes/t;
.source "SourceFile"


# instance fields
.field public final m:Lcom/android/internal/util/danda/classes/o;

.field public final n:Lcom/android/internal/util/danda/classes/k;

.field public final o:Lcom/android/internal/util/danda/classes/t;

.field public final p:I

.field public final q:Lcom/android/internal/util/danda/classes/t;


# direct methods
.method public constructor <init>(Lcom/android/internal/util/danda/classes/f;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    invoke-static {v0, p1}, Lcom/android/internal/util/danda/classes/r1;->n(ILcom/android/internal/util/danda/classes/f;)Lcom/android/internal/util/danda/classes/t;

    move-result-object v1

    instance-of v2, v1, Lcom/android/internal/util/danda/classes/o;

    const/4 v3, 0x1

    if-eqz v2, :cond_16

    check-cast v1, Lcom/android/internal/util/danda/classes/o;

    iput-object v1, p0, Lcom/android/internal/util/danda/classes/r1;->m:Lcom/android/internal/util/danda/classes/o;

    invoke-static {v3, p1}, Lcom/android/internal/util/danda/classes/r1;->n(ILcom/android/internal/util/danda/classes/f;)Lcom/android/internal/util/danda/classes/t;

    move-result-object v1

    move v0, v3

    :cond_16
    instance-of v2, v1, Lcom/android/internal/util/danda/classes/k;

    if-eqz v2, :cond_24

    check-cast v1, Lcom/android/internal/util/danda/classes/k;

    iput-object v1, p0, Lcom/android/internal/util/danda/classes/r1;->n:Lcom/android/internal/util/danda/classes/k;

    add-int/lit8 v0, v0, 0x1

    invoke-static {v0, p1}, Lcom/android/internal/util/danda/classes/r1;->n(ILcom/android/internal/util/danda/classes/f;)Lcom/android/internal/util/danda/classes/t;

    move-result-object v1

    :cond_24
    instance-of v2, v1, Lcom/android/internal/util/danda/classes/a0;

    if-nez v2, :cond_30

    iput-object v1, p0, Lcom/android/internal/util/danda/classes/r1;->o:Lcom/android/internal/util/danda/classes/t;

    add-int/lit8 v0, v0, 0x1

    invoke-static {v0, p1}, Lcom/android/internal/util/danda/classes/r1;->n(ILcom/android/internal/util/danda/classes/f;)Lcom/android/internal/util/danda/classes/t;

    move-result-object v1

    :cond_30
    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/f;->f()I

    move-result p1

    add-int/2addr v0, v3

    if-ne p1, v0, :cond_69

    instance-of p1, v1, Lcom/android/internal/util/danda/classes/a0;

    if-eqz p1, :cond_61

    check-cast v1, Lcom/android/internal/util/danda/classes/a0;

    iget p1, v1, Lcom/android/internal/util/danda/classes/a0;->m:I

    if-ltz p1, :cond_4d

    const/4 v0, 0x2

    if-gt p1, v0, :cond_4d

    iput p1, p0, Lcom/android/internal/util/danda/classes/r1;->p:I

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/a0;->o()Lcom/android/internal/util/danda/classes/t;

    move-result-object p1

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/r1;->q:Lcom/android/internal/util/danda/classes/t;

    return-void

    :cond_4d
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "invalid encoding value: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_61
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "No tagged object found in vector. Structure doesn\'t seem to be of type External"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_69
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "input vector too large"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static n(ILcom/android/internal/util/danda/classes/f;)Lcom/android/internal/util/danda/classes/t;
    .registers 3

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/f;->f()I

    move-result v0

    if-le v0, p0, :cond_f

    invoke-virtual {p1, p0}, Lcom/android/internal/util/danda/classes/f;->b(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object p0

    invoke-interface {p0}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object p0

    return-object p0

    :cond_f
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "too few objects in input vector"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public final g(Lcom/android/internal/util/danda/classes/t;)Z
    .registers 5

    instance-of v0, p1, Lcom/android/internal/util/danda/classes/r1;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return v1

    :cond_6
    if-ne p0, p1, :cond_a

    const/4 p1, 0x1

    return p1

    :cond_a
    check-cast p1, Lcom/android/internal/util/danda/classes/r1;

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/r1;->m:Lcom/android/internal/util/danda/classes/o;

    if-eqz v0, :cond_1b

    iget-object v2, p1, Lcom/android/internal/util/danda/classes/r1;->m:Lcom/android/internal/util/danda/classes/o;

    if-eqz v2, :cond_1a

    invoke-virtual {v2, v0}, Lcom/android/internal/util/danda/classes/t;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1b

    :cond_1a
    return v1

    :cond_1b
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/r1;->n:Lcom/android/internal/util/danda/classes/k;

    if-eqz v0, :cond_2a

    iget-object v2, p1, Lcom/android/internal/util/danda/classes/r1;->n:Lcom/android/internal/util/danda/classes/k;

    if-eqz v2, :cond_29

    invoke-virtual {v2, v0}, Lcom/android/internal/util/danda/classes/t;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2a

    :cond_29
    return v1

    :cond_2a
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/r1;->o:Lcom/android/internal/util/danda/classes/t;

    if-eqz v0, :cond_39

    iget-object v2, p1, Lcom/android/internal/util/danda/classes/r1;->o:Lcom/android/internal/util/danda/classes/t;

    if-eqz v2, :cond_38

    invoke-virtual {v2, v0}, Lcom/android/internal/util/danda/classes/t;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_39

    :cond_38
    return v1

    :cond_39
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/r1;->q:Lcom/android/internal/util/danda/classes/t;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/r1;->q:Lcom/android/internal/util/danda/classes/t;

    invoke-virtual {v0, p1}, Lcom/android/internal/util/danda/classes/t;->equals(Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public final h(Lcom/android/internal/util/danda/classes/f;)V
    .registers 8

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/r1;->m:Lcom/android/internal/util/danda/classes/o;

    const-string v2, "DER"

    if-eqz v1, :cond_12

    invoke-virtual {v1, v2}, Lcom/android/internal/util/danda/classes/m;->f(Ljava/lang/String;)[B

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/io/OutputStream;->write([B)V

    :cond_12
    iget-object v1, p0, Lcom/android/internal/util/danda/classes/r1;->n:Lcom/android/internal/util/danda/classes/k;

    if-eqz v1, :cond_1d

    invoke-virtual {v1, v2}, Lcom/android/internal/util/danda/classes/m;->f(Ljava/lang/String;)[B

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/io/OutputStream;->write([B)V

    :cond_1d
    iget-object v1, p0, Lcom/android/internal/util/danda/classes/r1;->o:Lcom/android/internal/util/danda/classes/t;

    if-eqz v1, :cond_28

    invoke-virtual {v1, v2}, Lcom/android/internal/util/danda/classes/m;->f(Ljava/lang/String;)[B

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/io/OutputStream;->write([B)V

    :cond_28
    new-instance v1, Lcom/android/internal/util/danda/classes/g2;

    iget v3, p0, Lcom/android/internal/util/danda/classes/r1;->p:I

    iget-object v4, p0, Lcom/android/internal/util/danda/classes/r1;->q:Lcom/android/internal/util/danda/classes/t;

    const/4 v5, 0x1

    invoke-direct {v1, v5, v3, v4}, Lcom/android/internal/util/danda/classes/a0;-><init>(ZILcom/android/internal/util/danda/classes/e;)V

    invoke-virtual {v1, v2}, Lcom/android/internal/util/danda/classes/m;->f(Ljava/lang/String;)[B

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/io/OutputStream;->write([B)V

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0

    const/16 v1, 0x20

    const/16 v2, 0x8

    invoke-virtual {p1, v1, v2}, Lcom/android/internal/util/danda/classes/f;->l(II)V

    array-length v1, v0

    invoke-virtual {p1, v1}, Lcom/android/internal/util/danda/classes/f;->j(I)V

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/f;->a:Ljava/lang/Object;

    check-cast p1, Ljava/io/OutputStream;

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    return-void
.end method

.method public final hashCode()I
    .registers 3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/r1;->m:Lcom/android/internal/util/danda/classes/o;

    if-eqz v0, :cond_b

    iget-object v0, v0, Lcom/android/internal/util/danda/classes/o;->m:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    goto :goto_c

    :cond_b
    const/4 v0, 0x0

    :goto_c
    iget-object v1, p0, Lcom/android/internal/util/danda/classes/r1;->n:Lcom/android/internal/util/danda/classes/k;

    if-eqz v1, :cond_15

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/k;->hashCode()I

    move-result v1

    xor-int/2addr v0, v1

    :cond_15
    iget-object v1, p0, Lcom/android/internal/util/danda/classes/r1;->o:Lcom/android/internal/util/danda/classes/t;

    if-eqz v1, :cond_1e

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/t;->hashCode()I

    move-result v1

    xor-int/2addr v0, v1

    :cond_1e
    iget-object v1, p0, Lcom/android/internal/util/danda/classes/r1;->q:Lcom/android/internal/util/danda/classes/t;

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/t;->hashCode()I

    move-result v1

    xor-int/2addr v0, v1

    return v0
.end method

.method public final i()I
    .registers 2

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/m;->e()[B

    move-result-object v0

    array-length v0, v0

    return v0
.end method

.method public final k()Z
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

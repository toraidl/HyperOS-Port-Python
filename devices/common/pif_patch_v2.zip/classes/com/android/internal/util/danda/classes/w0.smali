.class public final Lcom/android/internal/util/danda/classes/w0;
.super Lcom/android/internal/util/danda/classes/w;
.source "SourceFile"


# virtual methods
.method public final h(Lcom/android/internal/util/danda/classes/f;)V
    .registers 4

    const/16 v0, 0x31

    invoke-virtual {p1, v0}, Lcom/android/internal/util/danda/classes/f;->g(I)V

    const/16 v0, 0x80

    invoke-virtual {p1, v0}, Lcom/android/internal/util/danda/classes/f;->g(I)V

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->elements()Ljava/util/Enumeration;

    move-result-object v0

    :goto_10
    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v1

    if-eqz v1, :cond_20

    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/e;

    invoke-virtual {p1, v1}, Lcom/android/internal/util/danda/classes/f;->k(Lcom/android/internal/util/danda/classes/e;)V

    goto :goto_10

    :cond_20
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lcom/android/internal/util/danda/classes/f;->g(I)V

    invoke-virtual {p1, v0}, Lcom/android/internal/util/danda/classes/f;->g(I)V

    return-void
.end method

.method public final i()I
    .registers 4

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->elements()Ljava/util/Enumeration;

    move-result-object v0

    const/4 v1, 0x0

    :goto_7
    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v2

    if-eqz v2, :cond_1d

    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/internal/util/danda/classes/e;

    invoke-interface {v2}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/t;->i()I

    move-result v2

    add-int/2addr v1, v2

    goto :goto_7

    :cond_1d
    add-int/lit8 v1, v1, 0x4

    return v1
.end method

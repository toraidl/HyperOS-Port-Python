.class public abstract Lcom/android/internal/util/danda/classes/c3;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final f:[Lcom/android/internal/util/danda/classes/a3;


# instance fields
.field public final a:Lcom/android/internal/util/danda/classes/x2;

.field public final b:Lcom/android/internal/util/danda/classes/a3;

.field public final c:Lcom/android/internal/util/danda/classes/a3;

.field public final d:[Lcom/android/internal/util/danda/classes/a3;

.field public e:Z


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/4 v0, 0x0

    new-array v0, v0, [Lcom/android/internal/util/danda/classes/a3;

    sput-object v0, Lcom/android/internal/util/danda/classes/c3;->f:[Lcom/android/internal/util/danda/classes/a3;

    return-void
.end method

.method public constructor <init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;)V
    .registers 10

    const/4 v0, 0x0

    if-nez p1, :cond_5

    move v1, v0

    goto :goto_7

    .line 2
    :cond_5
    iget v1, p1, Lcom/android/internal/util/danda/classes/x2;->e:I

    :goto_7
    if-eqz v1, :cond_41

    const/4 v2, 0x5

    if-eq v1, v2, :cond_41

    .line 3
    sget-object v2, Lcom/android/internal/util/danda/classes/u2;->b:Ljava/math/BigInteger;

    invoke-virtual {p1, v2}, Lcom/android/internal/util/danda/classes/x2;->d(Ljava/math/BigInteger;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v2

    const/4 v3, 0x1

    if-eq v1, v3, :cond_3c

    const/4 v4, 0x2

    if-eq v1, v4, :cond_3c

    const/4 v5, 0x3

    if-eq v1, v5, :cond_33

    const/4 v5, 0x4

    if-eq v1, v5, :cond_2a

    const/4 v4, 0x6

    if-ne v1, v4, :cond_22

    goto :goto_3c

    .line 4
    :cond_22
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "unknown coordinate system"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2a
    new-array v1, v4, [Lcom/android/internal/util/danda/classes/a3;

    aput-object v2, v1, v0

    .line 5
    iget-object v0, p1, Lcom/android/internal/util/danda/classes/x2;->b:Lcom/android/internal/util/danda/classes/a3;

    aput-object v0, v1, v3

    goto :goto_43

    :cond_33
    new-array v1, v5, [Lcom/android/internal/util/danda/classes/a3;

    aput-object v2, v1, v0

    aput-object v2, v1, v3

    aput-object v2, v1, v4

    goto :goto_43

    :cond_3c
    :goto_3c
    new-array v1, v3, [Lcom/android/internal/util/danda/classes/a3;

    aput-object v2, v1, v0

    goto :goto_43

    :cond_41
    sget-object v1, Lcom/android/internal/util/danda/classes/c3;->f:[Lcom/android/internal/util/danda/classes/a3;

    .line 6
    :goto_43
    invoke-direct {p0, p1, p2, p3, v1}, Lcom/android/internal/util/danda/classes/c3;-><init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;[Lcom/android/internal/util/danda/classes/a3;)V

    return-void
.end method

.method public constructor <init>(Lcom/android/internal/util/danda/classes/x2;Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;[Lcom/android/internal/util/danda/classes/a3;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    iput-object p2, p0, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    iput-object p3, p0, Lcom/android/internal/util/danda/classes/c3;->c:Lcom/android/internal/util/danda/classes/a3;

    iput-object p4, p0, Lcom/android/internal/util/danda/classes/c3;->d:[Lcom/android/internal/util/danda/classes/a3;

    return-void
.end method


# virtual methods
.method public abstract a(Lcom/android/internal/util/danda/classes/c3;)Lcom/android/internal/util/danda/classes/c3;
.end method

.method public final b()I
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    if-nez v0, :cond_6

    const/4 v0, 0x0

    goto :goto_8

    :cond_6
    iget v0, v0, Lcom/android/internal/util/danda/classes/x2;->e:I

    :goto_8
    return v0
.end method

.method public abstract c()Lcom/android/internal/util/danda/classes/a3;
.end method

.method public abstract d()Lcom/android/internal/util/danda/classes/a3;
.end method

.method public final e()Z
    .registers 4

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    if-eqz v0, :cond_16

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/c3;->c:Lcom/android/internal/util/danda/classes/a3;

    if-eqz v0, :cond_16

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/c3;->d:[Lcom/android/internal/util/danda/classes/a3;

    array-length v1, v0

    const/4 v2, 0x0

    if-lez v1, :cond_17

    aget-object v0, v0, v2

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/a3;->h()Z

    move-result v0

    if-eqz v0, :cond_17

    :cond_16
    const/4 v2, 0x1

    :cond_17
    return v2
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 13

    const/4 v0, 0x1

    if-ne p1, p0, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lcom/android/internal/util/danda/classes/c3;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lcom/android/internal/util/danda/classes/c3;

    if-nez p1, :cond_10

    goto/16 :goto_11d

    :cond_10
    iget-object v1, p0, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    if-nez v1, :cond_16

    move v3, v0

    goto :goto_17

    :cond_16
    move v3, v2

    :goto_17
    iget-object v4, p1, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    if-nez v4, :cond_1d

    move v5, v0

    goto :goto_1e

    :cond_1d
    move v5, v2

    :goto_1e
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/c3;->e()Z

    move-result v6

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/c3;->e()Z

    move-result v7

    if-nez v6, :cond_10e

    if-eqz v7, :cond_2c

    goto/16 :goto_10e

    :cond_2c
    if-eqz v3, :cond_33

    if-eqz v5, :cond_33

    :goto_30
    move-object v1, p0

    goto/16 :goto_f2

    :cond_33
    if-eqz v3, :cond_3a

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/c3;->f()Lcom/android/internal/util/danda/classes/c3;

    move-result-object p1

    goto :goto_30

    :cond_3a
    if-eqz v5, :cond_42

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/c3;->f()Lcom/android/internal/util/danda/classes/c3;

    move-result-object v1

    goto/16 :goto_f2

    :cond_42
    invoke-virtual {v1, v4}, Lcom/android/internal/util/danda/classes/x2;->c(Lcom/android/internal/util/danda/classes/x2;)Z

    move-result v3

    if-nez v3, :cond_4a

    goto/16 :goto_11d

    :cond_4a
    const/4 v3, 0x2

    new-array v4, v3, [Lcom/android/internal/util/danda/classes/c3;

    aput-object p0, v4, v2

    invoke-virtual {v1, p1}, Lcom/android/internal/util/danda/classes/x2;->g(Lcom/android/internal/util/danda/classes/c3;)Lcom/android/internal/util/danda/classes/c3;

    move-result-object p1

    aput-object p1, v4, v0

    move p1, v2

    :goto_56
    if-ge p1, v3, :cond_6c

    aget-object v5, v4, p1

    if-eqz v5, :cond_69

    iget-object v5, v5, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    if-ne v1, v5, :cond_61

    goto :goto_69

    :cond_61
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "\'points\' entries must be null or on this curve"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_69
    :goto_69
    add-int/lit8 p1, p1, 0x1

    goto :goto_56

    :cond_6c
    iget p1, v1, Lcom/android/internal/util/danda/classes/x2;->e:I

    if-eqz p1, :cond_ee

    const/4 v1, 0x5

    if-eq p1, v1, :cond_ee

    new-array p1, v3, [Lcom/android/internal/util/danda/classes/a3;

    new-array v5, v3, [I

    move v6, v2

    move v7, v6

    :goto_79
    if-ge v6, v3, :cond_a6

    aget-object v8, v4, v6

    if-eqz v8, :cond_a3

    invoke-virtual {v8}, Lcom/android/internal/util/danda/classes/c3;->b()I

    move-result v9

    if-eqz v9, :cond_a3

    if-eq v9, v1, :cond_a3

    invoke-virtual {v8}, Lcom/android/internal/util/danda/classes/c3;->e()Z

    move-result v9

    if-nez v9, :cond_a3

    iget-object v9, v8, Lcom/android/internal/util/danda/classes/c3;->d:[Lcom/android/internal/util/danda/classes/a3;

    aget-object v9, v9, v2

    invoke-virtual {v9}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v9

    if-eqz v9, :cond_98

    goto :goto_a3

    :cond_98
    invoke-virtual {v8}, Lcom/android/internal/util/danda/classes/c3;->d()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v8

    aput-object v8, p1, v7

    add-int/lit8 v8, v7, 0x1

    aput v6, v5, v7

    move v7, v8

    :cond_a3
    :goto_a3
    add-int/lit8 v6, v6, 0x1

    goto :goto_79

    :cond_a6
    if-nez v7, :cond_a9

    goto :goto_ee

    :cond_a9
    new-array v1, v7, [Lcom/android/internal/util/danda/classes/a3;

    aget-object v3, p1, v2

    aput-object v3, v1, v2

    move v3, v2

    :goto_b0
    add-int/lit8 v6, v3, 0x1

    if-ge v6, v7, :cond_c0

    aget-object v3, v1, v3

    aget-object v8, p1, v6

    invoke-virtual {v3, v8}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v3

    aput-object v3, v1, v6

    move v3, v6

    goto :goto_b0

    :cond_c0
    aget-object v6, v1, v3

    invoke-virtual {v6}, Lcom/android/internal/util/danda/classes/a3;->f()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    :goto_c6
    if-lez v3, :cond_da

    add-int/lit8 v8, v3, -0x1

    aget-object v9, p1, v3

    aget-object v10, v1, v8

    invoke-virtual {v10, v6}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v10

    aput-object v10, p1, v3

    invoke-virtual {v6, v9}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v6

    move v3, v8

    goto :goto_c6

    :cond_da
    aput-object v6, p1, v2

    move v1, v2

    :goto_dd
    if-ge v1, v7, :cond_ee

    aget v3, v5, v1

    aget-object v6, v4, v3

    aget-object v8, p1, v1

    invoke-virtual {v6, v8}, Lcom/android/internal/util/danda/classes/c3;->g(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/c3;

    move-result-object v6

    aput-object v6, v4, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_dd

    :cond_ee
    :goto_ee
    aget-object v1, v4, v2

    aget-object p1, v4, v0

    :goto_f2
    iget-object v3, v1, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    iget-object v4, p1, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_10b

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/c3;->c()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/c3;->c()Lcom/android/internal/util/danda/classes/a3;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_10b

    goto :goto_10c

    :cond_10b
    move v0, v2

    :cond_10c
    :goto_10c
    move v2, v0

    goto :goto_11d

    :cond_10e
    :goto_10e
    if-eqz v6, :cond_10b

    if-eqz v7, :cond_10b

    if-nez v3, :cond_10c

    if-nez v5, :cond_10c

    invoke-virtual {v1, v4}, Lcom/android/internal/util/danda/classes/x2;->c(Lcom/android/internal/util/danda/classes/x2;)Z

    move-result p1

    if-eqz p1, :cond_10b

    goto :goto_10c

    :goto_11d
    return v2
.end method

.method public final f()Lcom/android/internal/util/danda/classes/c3;
    .registers 3

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/c3;->e()Z

    move-result v0

    if-eqz v0, :cond_7

    return-object p0

    :cond_7
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/c3;->b()I

    move-result v0

    if-eqz v0, :cond_24

    const/4 v1, 0x5

    if-eq v0, v1, :cond_24

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/c3;->d()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v0

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/a3;->g()Z

    move-result v1

    if-eqz v1, :cond_1b

    return-object p0

    :cond_1b
    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/a3;->f()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/android/internal/util/danda/classes/c3;->g(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/c3;

    move-result-object v0

    return-object v0

    :cond_24
    return-object p0
.end method

.method public final g(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/c3;
    .registers 5

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/c3;->b()I

    move-result v0

    const/4 v1, 0x1

    if-eq v0, v1, :cond_39

    const/4 v1, 0x2

    if-eq v0, v1, :cond_1c

    const/4 v1, 0x3

    if-eq v0, v1, :cond_1c

    const/4 v1, 0x4

    if-eq v0, v1, :cond_1c

    const/4 v1, 0x6

    if-ne v0, v1, :cond_14

    goto :goto_39

    :cond_14
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "not a projective coordinate system"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1c
    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/a3;->n()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object p1

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v1, v0}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v0

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/c3;->c:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v1, p1}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object p1

    iget-boolean v1, p0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    invoke-virtual {v2, v0, p1, v1}, Lcom/android/internal/util/danda/classes/x2;->b(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Z)Lcom/android/internal/util/danda/classes/b3;

    move-result-object p1

    return-object p1

    :cond_39
    :goto_39
    iget-object v0, p0, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v0, p1}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object v0

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/c3;->c:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v1, p1}, Lcom/android/internal/util/danda/classes/a3;->i(Lcom/android/internal/util/danda/classes/a3;)Lcom/android/internal/util/danda/classes/a3;

    move-result-object p1

    iget-boolean v1, p0, Lcom/android/internal/util/danda/classes/c3;->e:Z

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    invoke-virtual {v2, v0, p1, v1}, Lcom/android/internal/util/danda/classes/x2;->b(Lcom/android/internal/util/danda/classes/a3;Lcom/android/internal/util/danda/classes/a3;Z)Lcom/android/internal/util/danda/classes/b3;

    move-result-object p1

    return-object p1
.end method

.method public abstract h()Lcom/android/internal/util/danda/classes/c3;
.end method

.method public final hashCode()I
    .registers 4

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/c3;->a:Lcom/android/internal/util/danda/classes/x2;

    if-nez v0, :cond_6

    const/4 v0, 0x0

    goto :goto_b

    :cond_6
    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/x2;->hashCode()I

    move-result v0

    not-int v0, v0

    :goto_b
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/c3;->e()Z

    move-result v1

    if-nez v1, :cond_29

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/c3;->f()Lcom/android/internal/util/danda/classes/c3;

    move-result-object v1

    iget-object v2, v1, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    mul-int/lit8 v2, v2, 0x11

    xor-int/2addr v0, v2

    invoke-virtual {v1}, Lcom/android/internal/util/danda/classes/c3;->c()Lcom/android/internal/util/danda/classes/a3;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    mul-int/lit16 v1, v1, 0x101

    xor-int/2addr v0, v1

    :cond_29
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/c3;->e()Z

    move-result v0

    if-eqz v0, :cond_9

    const-string v0, "INF"

    return-object v0

    :cond_9
    new-instance v0, Ljava/lang/StringBuffer;

    const-string v1, "("

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/c3;->b:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/Object;)Ljava/lang/StringBuffer;

    const/16 v1, 0x2c

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    iget-object v2, p0, Lcom/android/internal/util/danda/classes/c3;->c:Lcom/android/internal/util/danda/classes/a3;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/Object;)Ljava/lang/StringBuffer;

    const/4 v2, 0x0

    :goto_20
    iget-object v3, p0, Lcom/android/internal/util/danda/classes/c3;->d:[Lcom/android/internal/util/danda/classes/a3;

    array-length v4, v3

    if-ge v2, v4, :cond_30

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    aget-object v3, v3, v2

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/Object;)Ljava/lang/StringBuffer;

    add-int/lit8 v2, v2, 0x1

    goto :goto_20

    :cond_30
    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

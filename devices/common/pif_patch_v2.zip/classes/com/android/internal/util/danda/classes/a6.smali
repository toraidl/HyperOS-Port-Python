.class public final Lcom/android/internal/util/danda/classes/a6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field public transient a:Lcom/android/internal/util/danda/classes/i0;


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    if-ne p1, p0, :cond_4

    const/4 p1, 0x1

    return p1

    :cond_4
    instance-of v0, p1, Lcom/android/internal/util/danda/classes/a6;

    if-nez v0, :cond_a

    const/4 p1, 0x0

    return p1

    :cond_a
    check-cast p1, Lcom/android/internal/util/danda/classes/a6;

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/a6;->a:Lcom/android/internal/util/danda/classes/i0;

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/a6;->a:Lcom/android/internal/util/danda/classes/i0;

    invoke-virtual {v0, p1}, Lcom/android/internal/util/danda/classes/m;->equals(Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/a6;->a:Lcom/android/internal/util/danda/classes/i0;

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/m;->hashCode()I

    move-result v0

    return v0
.end method

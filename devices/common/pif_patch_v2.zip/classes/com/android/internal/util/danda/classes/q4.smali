.class public final Lcom/android/internal/util/danda/classes/q4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/p4;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 4

    iput p1, p0, Lcom/android/internal/util/danda/classes/q4;->a:I

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-eq p1, v1, :cond_11

    const/4 v1, 0x2

    if-eq p1, v1, :cond_d

    .line 2
    invoke-direct {p0, v0, v0}, Lcom/android/internal/util/danda/classes/q4;-><init>(II)V

    return-void

    .line 3
    :cond_d
    invoke-direct {p0, v1, v0}, Lcom/android/internal/util/danda/classes/q4;-><init>(II)V

    return-void

    .line 4
    :cond_11
    invoke-direct {p0, v1, v0}, Lcom/android/internal/util/danda/classes/q4;-><init>(II)V

    return-void
.end method

.method public synthetic constructor <init>(II)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/android/internal/util/danda/classes/q4;->a:I

    return-void
.end method


# virtual methods
.method public final a([B)Lcom/android/internal/util/danda/classes/o4;
    .registers 15

    const-string v0, "DER"

    const/4 v1, 0x0

    iget v2, p0, Lcom/android/internal/util/danda/classes/q4;->a:I

    const/4 v3, 0x1

    const/4 v4, 0x4

    packed-switch v2, :pswitch_data_186

    :try_start_a
    invoke-static {p1}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object p1

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result v2

    const/16 v3, 0x9

    if-ne v2, v3, :cond_59

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/f5;->g(Lcom/android/internal/util/danda/classes/u;)Lcom/android/internal/util/danda/classes/f5;

    move-result-object p1

    iget-object v2, p1, Lcom/android/internal/util/danda/classes/f5;->n:Ljava/math/BigInteger;

    iget-object v3, p1, Lcom/android/internal/util/danda/classes/f5;->o:Ljava/math/BigInteger;

    new-instance v5, Lcom/android/internal/util/danda/classes/d0;

    sget-object v6, Lcom/android/internal/util/danda/classes/v4;->a:Lcom/android/internal/util/danda/classes/o;

    sget-object v7, Lcom/android/internal/util/danda/classes/y1;->m:Lcom/android/internal/util/danda/classes/y1;

    invoke-direct {v5, v6, v7}, Lcom/android/internal/util/danda/classes/d0;-><init>(Lcom/android/internal/util/danda/classes/o;Lcom/android/internal/util/danda/classes/e;)V

    new-instance v6, Lcom/android/internal/util/danda/classes/o4;

    new-instance v7, Lcom/android/internal/util/danda/classes/q1;

    new-instance v8, Lcom/android/internal/util/danda/classes/f;

    invoke-direct {v8, v1}, Lcom/android/internal/util/danda/classes/f;-><init>(I)V

    new-instance v9, Lcom/android/internal/util/danda/classes/k;

    invoke-direct {v9, v2}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    invoke-virtual {v8, v9}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/k;

    invoke-direct {v2, v3}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    invoke-virtual {v8, v2}, Lcom/android/internal/util/danda/classes/f;->a(Lcom/android/internal/util/danda/classes/e;)V

    new-instance v2, Lcom/android/internal/util/danda/classes/d2;

    invoke-direct {v2, v1, v8}, Lcom/android/internal/util/danda/classes/d2;-><init>(ILcom/android/internal/util/danda/classes/f;)V

    invoke-virtual {v2, v0}, Lcom/android/internal/util/danda/classes/m;->f(Ljava/lang/String;)[B

    move-result-object v0

    invoke-direct {v7, v1, v0}, Lcom/android/internal/util/danda/classes/b;-><init>(I[B)V

    new-instance v0, Lcom/android/internal/util/danda/classes/b5;

    invoke-direct {v0, v5, p1}, Lcom/android/internal/util/danda/classes/b5;-><init>(Lcom/android/internal/util/danda/classes/d0;Lcom/android/internal/util/danda/classes/m;)V

    invoke-direct {v6, v0}, Lcom/android/internal/util/danda/classes/o4;-><init>(Lcom/android/internal/util/danda/classes/b5;)V

    return-object v6

    :catch_55
    move-exception p1

    goto :goto_61

    :catch_57
    move-exception p1

    goto :goto_79

    :cond_59
    new-instance p1, Lcom/android/internal/util/danda/classes/h;

    const-string v0, "malformed sequence in RSA private key"

    invoke-direct {p1, v0, v4}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;I)V

    throw p1
    :try_end_61
    .catch Ljava/io/IOException; {:try_start_a .. :try_end_61} :catch_57
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_61} :catch_55

    :goto_61
    new-instance v0, Lcom/android/internal/util/danda/classes/h;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "problem creating RSA private key: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p1, v4}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v0

    :goto_79
    throw p1

    :pswitch_7a
    :try_start_7a
    invoke-static {p1}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object p1

    instance-of v0, p1, Lcom/android/internal/util/danda/classes/d3;

    if-eqz v0, :cond_85

    check-cast p1, Lcom/android/internal/util/danda/classes/d3;

    goto :goto_95

    :cond_85
    if-eqz p1, :cond_94

    new-instance v0, Lcom/android/internal/util/danda/classes/d3;

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object p1

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object p1, v0, Lcom/android/internal/util/danda/classes/d3;->m:Lcom/android/internal/util/danda/classes/u;

    move-object p1, v0

    goto :goto_95

    :cond_94
    const/4 p1, 0x0

    :goto_95
    new-instance v0, Lcom/android/internal/util/danda/classes/d0;

    sget-object v2, Lcom/android/internal/util/danda/classes/h6;->f:Lcom/android/internal/util/danda/classes/o;

    invoke-virtual {p1, v1}, Lcom/android/internal/util/danda/classes/d3;->g(I)Lcom/android/internal/util/danda/classes/t;

    move-result-object v1

    invoke-direct {v0, v2, v1}, Lcom/android/internal/util/danda/classes/d0;-><init>(Lcom/android/internal/util/danda/classes/o;Lcom/android/internal/util/danda/classes/e;)V

    new-instance v1, Lcom/android/internal/util/danda/classes/b5;

    invoke-direct {v1, v0, p1}, Lcom/android/internal/util/danda/classes/b5;-><init>(Lcom/android/internal/util/danda/classes/d0;Lcom/android/internal/util/danda/classes/m;)V

    invoke-virtual {p1, v3}, Lcom/android/internal/util/danda/classes/d3;->g(I)Lcom/android/internal/util/danda/classes/t;

    move-result-object p1

    check-cast p1, Lcom/android/internal/util/danda/classes/q1;

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/b;->n()[B

    move-result-object p1

    if-eqz p1, :cond_be

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/c0;->g([B)[B

    new-instance p1, Lcom/android/internal/util/danda/classes/o4;

    invoke-direct {p1, v1}, Lcom/android/internal/util/danda/classes/o4;-><init>(Lcom/android/internal/util/danda/classes/b5;)V

    return-object p1

    :catch_ba
    move-exception p1

    goto :goto_c6

    :catch_bc
    move-exception p1

    goto :goto_de

    :cond_be
    new-instance p1, Ljava/lang/NullPointerException;

    const-string v0, "data cannot be null"

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_c6
    .catch Ljava/io/IOException; {:try_start_7a .. :try_end_c6} :catch_bc
    .catch Ljava/lang/Exception; {:try_start_7a .. :try_end_c6} :catch_ba

    :goto_c6
    new-instance v0, Lcom/android/internal/util/danda/classes/h;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "problem creating EC private key: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p1, v4}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v0

    :goto_de
    throw p1

    :pswitch_df
    :try_start_df
    invoke-static {p1}, Lcom/android/internal/util/danda/classes/u;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/u;

    move-result-object p1

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/u;->r()I

    move-result v2

    const/4 v5, 0x6

    if-ne v2, v5, :cond_164

    invoke-virtual {p1, v3}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v2

    invoke-static {v2}, Lcom/android/internal/util/danda/classes/k;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/k;

    move-result-object v2

    const/4 v3, 0x2

    invoke-virtual {p1, v3}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v3

    invoke-static {v3}, Lcom/android/internal/util/danda/classes/k;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/k;

    move-result-object v3

    const/4 v5, 0x3

    invoke-virtual {p1, v5}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v5

    invoke-static {v5}, Lcom/android/internal/util/danda/classes/k;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/k;

    move-result-object v5

    invoke-virtual {p1, v4}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object v6

    invoke-static {v6}, Lcom/android/internal/util/danda/classes/k;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/k;

    move-result-object v6

    const/4 v7, 0x5

    invoke-virtual {p1, v7}, Lcom/android/internal/util/danda/classes/u;->p(I)Lcom/android/internal/util/danda/classes/e;

    move-result-object p1

    invoke-static {p1}, Lcom/android/internal/util/danda/classes/k;->o(Ljava/lang/Object;)Lcom/android/internal/util/danda/classes/k;

    move-result-object p1

    new-instance v7, Lcom/android/internal/util/danda/classes/o4;

    sget-object v8, Lcom/android/internal/util/danda/classes/h6;->k:Lcom/android/internal/util/danda/classes/o;

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v9

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v10

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v11

    new-instance v12, Lcom/android/internal/util/danda/classes/k;

    invoke-direct {v12, v9}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    new-instance v9, Lcom/android/internal/util/danda/classes/k;

    invoke-direct {v9, v10}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    new-instance v9, Lcom/android/internal/util/danda/classes/k;

    invoke-direct {v9, v11}, Lcom/android/internal/util/danda/classes/k;-><init>(Ljava/math/BigInteger;)V

    new-instance v9, Lcom/android/internal/util/danda/classes/q1;

    invoke-interface {v6}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v6

    invoke-virtual {v6, v0}, Lcom/android/internal/util/danda/classes/m;->f(Ljava/lang/String;)[B

    move-result-object v0

    invoke-direct {v9, v1, v0}, Lcom/android/internal/util/danda/classes/b;-><init>(I[B)V

    new-instance v0, Lcom/android/internal/util/danda/classes/b5;

    new-instance v1, Lcom/android/internal/util/danda/classes/d0;

    new-instance v6, Lcom/android/internal/util/danda/classes/o2;

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v2

    invoke-virtual {v3}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v3

    invoke-virtual {v5}, Lcom/android/internal/util/danda/classes/k;->p()Ljava/math/BigInteger;

    move-result-object v5

    invoke-direct {v6, v2, v3, v5}, Lcom/android/internal/util/danda/classes/o2;-><init>(Ljava/math/BigInteger;Ljava/math/BigInteger;Ljava/math/BigInteger;)V

    invoke-direct {v1, v8, v6}, Lcom/android/internal/util/danda/classes/d0;-><init>(Lcom/android/internal/util/danda/classes/o;Lcom/android/internal/util/danda/classes/e;)V

    invoke-direct {v0, v1, p1}, Lcom/android/internal/util/danda/classes/b5;-><init>(Lcom/android/internal/util/danda/classes/d0;Lcom/android/internal/util/danda/classes/m;)V

    invoke-direct {v7, v0}, Lcom/android/internal/util/danda/classes/o4;-><init>(Lcom/android/internal/util/danda/classes/b5;)V

    return-object v7

    :catch_160
    move-exception p1

    goto :goto_16c

    :catch_162
    move-exception p1

    goto :goto_184

    :cond_164
    new-instance p1, Lcom/android/internal/util/danda/classes/h;

    const-string v0, "malformed sequence in DSA private key"

    invoke-direct {p1, v0, v4}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;I)V

    throw p1
    :try_end_16c
    .catch Ljava/io/IOException; {:try_start_df .. :try_end_16c} :catch_162
    .catch Ljava/lang/Exception; {:try_start_df .. :try_end_16c} :catch_160

    :goto_16c
    new-instance v0, Lcom/android/internal/util/danda/classes/h;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "problem creating DSA private key: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, p1, v4}, Lcom/android/internal/util/danda/classes/h;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v0

    :goto_184
    throw p1

    nop

    :pswitch_data_186
    .packed-switch 0x0
        :pswitch_df
        :pswitch_7a
    .end packed-switch
.end method

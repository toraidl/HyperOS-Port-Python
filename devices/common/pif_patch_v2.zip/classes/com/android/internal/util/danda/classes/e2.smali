.class public final Lcom/android/internal/util/danda/classes/e2;
.super Lcom/android/internal/util/danda/classes/w;
.source "SourceFile"


# instance fields
.field public final synthetic o:I

.field public p:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lcom/android/internal/util/danda/classes/e2;->o:I

    .line 1
    invoke-direct {p0}, Lcom/android/internal/util/danda/classes/w;-><init>()V

    const/4 p1, -0x1

    iput p1, p0, Lcom/android/internal/util/danda/classes/e2;->p:I

    return-void
.end method

.method public constructor <init>(ILcom/android/internal/util/danda/classes/f;)V
    .registers 5

    iput p1, p0, Lcom/android/internal/util/danda/classes/e2;->o:I

    const/4 v0, -0x1

    const/4 v1, 0x1

    if-eq p1, v1, :cond_c

    .line 3
    invoke-direct {p0, p2, v1}, Lcom/android/internal/util/danda/classes/w;-><init>(Lcom/android/internal/util/danda/classes/f;Z)V

    iput v0, p0, Lcom/android/internal/util/danda/classes/e2;->p:I

    return-void

    :cond_c
    const/4 p1, 0x0

    .line 4
    invoke-direct {p0, p2, p1}, Lcom/android/internal/util/danda/classes/w;-><init>(Lcom/android/internal/util/danda/classes/f;Z)V

    iput v0, p0, Lcom/android/internal/util/danda/classes/e2;->p:I

    return-void
.end method

.method public synthetic constructor <init>(ILcom/android/internal/util/danda/classes/t;)V
    .registers 3

    iput p1, p0, Lcom/android/internal/util/danda/classes/e2;->o:I

    .line 2
    invoke-direct {p0, p2}, Lcom/android/internal/util/danda/classes/w;-><init>(Lcom/android/internal/util/danda/classes/t;)V

    const/4 p1, -0x1

    iput p1, p0, Lcom/android/internal/util/danda/classes/e2;->p:I

    return-void
.end method

.method public constructor <init>(Lcom/android/internal/util/danda/classes/f;)V
    .registers 3

    const/4 v0, 0x0

    iput v0, p0, Lcom/android/internal/util/danda/classes/e2;->o:I

    .line 7
    invoke-direct {p0, p1, v0}, Lcom/android/internal/util/danda/classes/w;-><init>(Lcom/android/internal/util/danda/classes/f;Z)V

    const/4 p1, -0x1

    iput p1, p0, Lcom/android/internal/util/danda/classes/e2;->p:I

    return-void
.end method

.method public constructor <init>([Lcom/android/internal/util/danda/classes/e;I)V
    .registers 5

    iput p2, p0, Lcom/android/internal/util/danda/classes/e2;->o:I

    const/4 v0, -0x1

    const/4 v1, 0x1

    if-eq p2, v1, :cond_c

    .line 5
    invoke-direct {p0, p1, v1}, Lcom/android/internal/util/danda/classes/w;-><init>([Lcom/android/internal/util/danda/classes/e;Z)V

    iput v0, p0, Lcom/android/internal/util/danda/classes/e2;->p:I

    return-void

    :cond_c
    const/4 p2, 0x0

    .line 6
    invoke-direct {p0, p1, p2}, Lcom/android/internal/util/danda/classes/w;-><init>([Lcom/android/internal/util/danda/classes/e;Z)V

    iput v0, p0, Lcom/android/internal/util/danda/classes/e2;->p:I

    return-void
.end method


# virtual methods
.method public final h(Lcom/android/internal/util/danda/classes/f;)V
    .registers 5

    iget v0, p0, Lcom/android/internal/util/danda/classes/e2;->o:I

    const/16 v1, 0x31

    packed-switch v0, :pswitch_data_52

    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/f;->e()Lcom/android/internal/util/danda/classes/b2;

    move-result-object v0

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/e2;->r()I

    move-result v2

    invoke-virtual {p1, v1}, Lcom/android/internal/util/danda/classes/f;->g(I)V

    invoke-virtual {p1, v2}, Lcom/android/internal/util/danda/classes/f;->j(I)V

    iget-object p1, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {p1}, Ljava/util/Vector;->elements()Ljava/util/Enumeration;

    move-result-object p1

    :goto_1b
    invoke-interface {p1}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v1

    if-eqz v1, :cond_2b

    invoke-interface {p1}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/e;

    invoke-virtual {v0, v1}, Lcom/android/internal/util/danda/classes/b2;->k(Lcom/android/internal/util/danda/classes/e;)V

    goto :goto_1b

    :cond_2b
    return-void

    :pswitch_2c
    invoke-virtual {p1}, Lcom/android/internal/util/danda/classes/f;->d()Lcom/android/internal/util/danda/classes/b2;

    move-result-object v0

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/e2;->q()I

    move-result v2

    invoke-virtual {p1, v1}, Lcom/android/internal/util/danda/classes/f;->g(I)V

    invoke-virtual {p1, v2}, Lcom/android/internal/util/danda/classes/f;->j(I)V

    iget-object p1, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {p1}, Ljava/util/Vector;->elements()Ljava/util/Enumeration;

    move-result-object p1

    :goto_40
    invoke-interface {p1}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v1

    if-eqz v1, :cond_50

    invoke-interface {p1}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/internal/util/danda/classes/e;

    invoke-virtual {v0, v1}, Lcom/android/internal/util/danda/classes/b2;->k(Lcom/android/internal/util/danda/classes/e;)V

    goto :goto_40

    :cond_50
    return-void

    nop

    :pswitch_data_52
    .packed-switch 0x0
        :pswitch_2c
    .end packed-switch
.end method

.method public final i()I
    .registers 3

    iget v0, p0, Lcom/android/internal/util/danda/classes/e2;->o:I

    packed-switch v0, :pswitch_data_1e

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/e2;->r()I

    move-result v0

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/n5;->a(I)I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    add-int/2addr v1, v0

    return v1

    :pswitch_11
    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/e2;->q()I

    move-result v0

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/n5;->a(I)I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    add-int/2addr v1, v0

    return v1

    nop

    :pswitch_data_1e
    .packed-switch 0x0
        :pswitch_11
    .end packed-switch
.end method

.method public final q()I
    .registers 4

    iget v0, p0, Lcom/android/internal/util/danda/classes/e2;->p:I

    if-gez v0, :cond_27

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->elements()Ljava/util/Enumeration;

    move-result-object v0

    const/4 v1, 0x0

    :goto_b
    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v2

    if-eqz v2, :cond_25

    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/internal/util/danda/classes/e;

    invoke-interface {v2}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/t;->l()Lcom/android/internal/util/danda/classes/t;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/t;->i()I

    move-result v2

    add-int/2addr v1, v2

    goto :goto_b

    :cond_25
    iput v1, p0, Lcom/android/internal/util/danda/classes/e2;->p:I

    :cond_27
    iget v0, p0, Lcom/android/internal/util/danda/classes/e2;->p:I

    return v0
.end method

.method public final r()I
    .registers 4

    iget v0, p0, Lcom/android/internal/util/danda/classes/e2;->p:I

    if-gez v0, :cond_27

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/w;->m:Ljava/util/Vector;

    invoke-virtual {v0}, Ljava/util/Vector;->elements()Ljava/util/Enumeration;

    move-result-object v0

    const/4 v1, 0x0

    :goto_b
    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v2

    if-eqz v2, :cond_25

    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/internal/util/danda/classes/e;

    invoke-interface {v2}, Lcom/android/internal/util/danda/classes/e;->d()Lcom/android/internal/util/danda/classes/t;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/t;->m()Lcom/android/internal/util/danda/classes/t;

    move-result-object v2

    invoke-virtual {v2}, Lcom/android/internal/util/danda/classes/t;->i()I

    move-result v2

    add-int/2addr v1, v2

    goto :goto_b

    :cond_25
    iput v1, p0, Lcom/android/internal/util/danda/classes/e2;->p:I

    :cond_27
    iget v0, p0, Lcom/android/internal/util/danda/classes/e2;->p:I

    return v0
.end method

.class public final Lcom/android/internal/util/danda/classes/g1;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:I

.field public b:[B

.field public c:[B

.field public d:I

.field public e:I

.field public f:I

.field public g:Ljava/util/ArrayList;

.field public h:Ljava/util/ArrayList;

.field public i:J

.field public j:J

.field public k:J

.field public l:J

.field public m:I

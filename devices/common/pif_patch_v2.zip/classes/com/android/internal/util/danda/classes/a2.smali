.class public final Lcom/android/internal/util/danda/classes/a2;
.super Lcom/android/internal/util/danda/classes/p;
.source "SourceFile"


# direct methods
.method public constructor <init>(Lcom/android/internal/util/danda/classes/d2;)V
    .registers 3

    const-string v0, "DER"

    invoke-virtual {p1, v0}, Lcom/android/internal/util/danda/classes/m;->f(Ljava/lang/String;)[B

    move-result-object p1

    invoke-direct {p0, p1}, Lcom/android/internal/util/danda/classes/p;-><init>([B)V

    return-void
.end method


# virtual methods
.method public final h(Lcom/android/internal/util/danda/classes/f;)V
    .registers 4

    const/4 v0, 0x4

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/p;->m:[B

    invoke-virtual {p1, v0, v1}, Lcom/android/internal/util/danda/classes/f;->h(I[B)V

    return-void
.end method

.method public final i()I
    .registers 3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/p;->m:[B

    array-length v1, v0

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/n5;->a(I)I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    array-length v0, v0

    add-int/2addr v1, v0

    return v1
.end method

.method public final k()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

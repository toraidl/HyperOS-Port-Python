.class public abstract Lcom/android/internal/util/danda/classes/t1;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lcom/android/internal/util/danda/classes/d2;

.field public static final b:Lcom/android/internal/util/danda/classes/e2;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/android/internal/util/danda/classes/d2;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/d2;-><init>(I)V

    sput-object v0, Lcom/android/internal/util/danda/classes/t1;->a:Lcom/android/internal/util/danda/classes/d2;

    new-instance v0, Lcom/android/internal/util/danda/classes/e2;

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/e2;-><init>(I)V

    sput-object v0, Lcom/android/internal/util/danda/classes/t1;->b:Lcom/android/internal/util/danda/classes/e2;

    return-void
.end method

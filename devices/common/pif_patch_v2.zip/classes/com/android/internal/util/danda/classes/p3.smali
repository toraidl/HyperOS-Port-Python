.class public abstract Lcom/android/internal/util/danda/classes/p3;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lcom/android/internal/util/danda/classes/y5;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/android/internal/util/danda/classes/y5;

    const/4 v1, 0x4

    invoke-direct {v0, v1}, Lcom/android/internal/util/danda/classes/y5;-><init>(I)V

    sput-object v0, Lcom/android/internal/util/danda/classes/p3;->a:Lcom/android/internal/util/danda/classes/y5;

    return-void
.end method

.method public static a(Ljava/lang/String;)[B
    .registers 8

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    :try_start_5
    sget-object v1, Lcom/android/internal/util/danda/classes/p3;->a:Lcom/android/internal/util/danda/classes/y5;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    :goto_e
    if-lez v2, :cond_20

    add-int/lit8 v3, v2, -0x1

    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    invoke-static {v3}, Lcom/android/internal/util/danda/classes/y5;->d(C)Z

    move-result v3

    if-nez v3, :cond_1d

    goto :goto_20

    :cond_1d
    add-int/lit8 v2, v2, -0x1

    goto :goto_e

    :cond_20
    :goto_20
    const/4 v3, 0x0

    :goto_21
    if-ge v3, v2, :cond_6d

    :goto_23
    if-ge v3, v2, :cond_32

    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v4

    invoke-static {v4}, Lcom/android/internal/util/danda/classes/y5;->d(C)Z

    move-result v4

    if-eqz v4, :cond_32

    add-int/lit8 v3, v3, 0x1

    goto :goto_23

    :cond_32
    iget-object v4, v1, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    check-cast v4, [B

    add-int/lit8 v5, v3, 0x1

    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    aget-byte v3, v4, v3

    :goto_3e
    if-ge v5, v2, :cond_4d

    invoke-virtual {p0, v5}, Ljava/lang/String;->charAt(I)C

    move-result v4

    invoke-static {v4}, Lcom/android/internal/util/danda/classes/y5;->d(C)Z

    move-result v4

    if-eqz v4, :cond_4d

    add-int/lit8 v5, v5, 0x1

    goto :goto_3e

    :cond_4d
    iget-object v4, v1, Lcom/android/internal/util/danda/classes/y5;->a:Ljava/lang/Object;

    check-cast v4, [B

    add-int/lit8 v6, v5, 0x1

    invoke-virtual {p0, v5}, Ljava/lang/String;->charAt(I)C

    move-result v5

    aget-byte v4, v4, v5

    or-int v5, v3, v4

    if-ltz v5, :cond_65

    shl-int/lit8 v3, v3, 0x4

    or-int/2addr v3, v4

    invoke-virtual {v0, v3}, Ljava/io/OutputStream;->write(I)V

    move v3, v6

    goto :goto_21

    :cond_65
    new-instance p0, Ljava/io/IOException;

    const-string v0, "invalid characters encountered in Hex string"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_6d
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_6d} :catch_72

    :cond_6d
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0

    return-object p0

    :catch_72
    move-exception p0

    new-instance v0, Lcom/android/internal/util/danda/classes/s;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "exception decoding Hex string: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    invoke-direct {v0, v1, p0, v2}, Lcom/android/internal/util/danda/classes/s;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw v0
.end method

.method public static b([BI)[B
    .registers 8

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    :try_start_5
    sget-object v1, Lcom/android/internal/util/danda/classes/p3;->a:Lcom/android/internal/util/danda/classes/y5;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x0

    :goto_b
    if-ge v2, p1, :cond_2a

    aget-byte v3, p0, v2

    and-int/lit16 v4, v3, 0xff

    iget-object v5, v1, Lcom/android/internal/util/danda/classes/y5;->b:Ljava/lang/Object;

    check-cast v5, [B

    ushr-int/lit8 v4, v4, 0x4

    aget-byte v4, v5, v4

    invoke-virtual {v0, v4}, Ljava/io/OutputStream;->write(I)V

    iget-object v4, v1, Lcom/android/internal/util/danda/classes/y5;->b:Ljava/lang/Object;

    check-cast v4, [B

    and-int/lit8 v3, v3, 0xf

    aget-byte v3, v4, v3

    invoke-virtual {v0, v3}, Ljava/io/OutputStream;->write(I)V
    :try_end_27
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_27} :catch_2f

    add-int/lit8 v2, v2, 0x1

    goto :goto_b

    :cond_2a
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0

    return-object p0

    :catch_2f
    move-exception p0

    new-instance p1, Lcom/android/internal/util/danda/classes/s;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "exception encoding Hex string: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x2

    invoke-direct {p1, v0, p0, v1}, Lcom/android/internal/util/danda/classes/s;-><init>(Ljava/lang/String;Ljava/lang/Exception;I)V

    throw p1
.end method

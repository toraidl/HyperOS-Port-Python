.class public final Lcom/android/internal/util/danda/classes/i2;
.super Lcom/android/internal/util/danda/classes/t;
.source "SourceFile"

# interfaces
.implements Lcom/android/internal/util/danda/classes/z;


# instance fields
.field public final m:[B


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    sget-object v0, Lcom/android/internal/util/danda/classes/p5;->a:Ljava/lang/String;

    .line 3
    invoke-virtual {p1}, Ljava/lang/String;->toCharArray()[C

    move-result-object p1

    .line 4
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 5
    :try_start_e
    invoke-static {p1, v0}, Lcom/android/internal/util/danda/classes/p5;->d([CLjava/io/ByteArrayOutputStream;)V
    :try_end_11
    .catch Ljava/io/IOException; {:try_start_e .. :try_end_11} :catch_18

    .line 6
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p1

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/i2;->m:[B

    return-void

    .line 7
    :catch_18
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "cannot encode string to byte array!"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public constructor <init>([B)V
    .registers 2

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/android/internal/util/danda/classes/i2;->m:[B

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 11

    sget-object v0, Lcom/android/internal/util/danda/classes/p5;->a:Ljava/lang/String;

    const/4 v0, 0x0

    move v1, v0

    move v2, v1

    :goto_5
    iget-object v3, p0, Lcom/android/internal/util/danda/classes/i2;->m:[B

    array-length v4, v3

    const/16 v5, 0xf0

    const/16 v6, 0xe0

    const/16 v7, 0xc0

    if-ge v1, v4, :cond_2f

    add-int/lit8 v4, v2, 0x1

    aget-byte v3, v3, v1

    and-int/lit16 v8, v3, 0xf0

    if-ne v8, v5, :cond_1d

    add-int/lit8 v2, v2, 0x2

    add-int/lit8 v1, v1, 0x4

    goto :goto_5

    :cond_1d
    and-int/lit16 v2, v3, 0xe0

    if-ne v2, v6, :cond_25

    add-int/lit8 v1, v1, 0x3

    :goto_23
    move v2, v4

    goto :goto_5

    :cond_25
    and-int/lit16 v2, v3, 0xc0

    if-ne v2, v7, :cond_2c

    add-int/lit8 v1, v1, 0x2

    goto :goto_23

    :cond_2c
    add-int/lit8 v1, v1, 0x1

    goto :goto_23

    :cond_2f
    new-array v1, v2, [C

    move v2, v0

    :goto_32
    array-length v4, v3

    if-ge v0, v4, :cond_bb

    aget-byte v4, v3, v0

    and-int/lit16 v8, v4, 0xf0

    if-ne v8, v5, :cond_71

    and-int/lit8 v4, v4, 0x3

    shl-int/lit8 v4, v4, 0x12

    add-int/lit8 v8, v0, 0x1

    aget-byte v8, v3, v8

    and-int/lit8 v8, v8, 0x3f

    shl-int/lit8 v8, v8, 0xc

    or-int/2addr v4, v8

    add-int/lit8 v8, v0, 0x2

    aget-byte v8, v3, v8

    and-int/lit8 v8, v8, 0x3f

    shl-int/lit8 v8, v8, 0x6

    or-int/2addr v4, v8

    add-int/lit8 v8, v0, 0x3

    aget-byte v8, v3, v8

    and-int/lit8 v8, v8, 0x3f

    or-int/2addr v4, v8

    const/high16 v8, 0x10000

    sub-int/2addr v4, v8

    shr-int/lit8 v8, v4, 0xa

    const v9, 0xd800

    or-int/2addr v8, v9

    int-to-char v8, v8

    and-int/lit16 v4, v4, 0x3ff

    const v9, 0xdc00

    or-int/2addr v4, v9

    int-to-char v4, v4

    add-int/lit8 v9, v2, 0x1

    aput-char v8, v1, v2

    add-int/lit8 v0, v0, 0x4

    move v2, v9

    goto :goto_b4

    :cond_71
    and-int/lit16 v8, v4, 0xe0

    if-ne v8, v6, :cond_8d

    and-int/lit8 v4, v4, 0xf

    shl-int/lit8 v4, v4, 0xc

    add-int/lit8 v8, v0, 0x1

    aget-byte v8, v3, v8

    and-int/lit8 v8, v8, 0x3f

    shl-int/lit8 v8, v8, 0x6

    or-int/2addr v4, v8

    add-int/lit8 v8, v0, 0x2

    aget-byte v8, v3, v8

    and-int/lit8 v8, v8, 0x3f

    or-int/2addr v4, v8

    int-to-char v4, v4

    add-int/lit8 v0, v0, 0x3

    goto :goto_b4

    :cond_8d
    and-int/lit16 v8, v4, 0xd0

    const/16 v9, 0xd0

    if-ne v8, v9, :cond_a2

    and-int/lit8 v4, v4, 0x1f

    shl-int/lit8 v4, v4, 0x6

    add-int/lit8 v8, v0, 0x1

    aget-byte v8, v3, v8

    :goto_9b
    and-int/lit8 v8, v8, 0x3f

    or-int/2addr v4, v8

    int-to-char v4, v4

    add-int/lit8 v0, v0, 0x2

    goto :goto_b4

    :cond_a2
    and-int/lit16 v8, v4, 0xc0

    if-ne v8, v7, :cond_af

    and-int/lit8 v4, v4, 0x1f

    shl-int/lit8 v4, v4, 0x6

    add-int/lit8 v8, v0, 0x1

    aget-byte v8, v3, v8

    goto :goto_9b

    :cond_af
    and-int/lit16 v4, v4, 0xff

    int-to-char v4, v4

    add-int/lit8 v0, v0, 0x1

    :goto_b4
    add-int/lit8 v8, v2, 0x1

    aput-char v4, v1, v2

    move v2, v8

    goto/16 :goto_32

    :cond_bb
    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, v1}, Ljava/lang/String;-><init>([C)V

    return-object v0
.end method

.method public final g(Lcom/android/internal/util/danda/classes/t;)Z
    .registers 3

    instance-of v0, p1, Lcom/android/internal/util/danda/classes/i2;

    if-nez v0, :cond_6

    const/4 p1, 0x0

    return p1

    :cond_6
    check-cast p1, Lcom/android/internal/util/danda/classes/i2;

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/i2;->m:[B

    iget-object p1, p1, Lcom/android/internal/util/danda/classes/i2;->m:[B

    invoke-static {v0, p1}, Lcom/android/internal/util/danda/classes/c0;->c([B[B)Z

    move-result p1

    return p1
.end method

.method public final h(Lcom/android/internal/util/danda/classes/f;)V
    .registers 4

    const/16 v0, 0xc

    iget-object v1, p0, Lcom/android/internal/util/danda/classes/i2;->m:[B

    invoke-virtual {p1, v0, v1}, Lcom/android/internal/util/danda/classes/f;->h(I[B)V

    return-void
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/i2;->m:[B

    invoke-static {v0}, Lcom/android/internal/util/danda/classes/c0;->j([B)I

    move-result v0

    return v0
.end method

.method public final i()I
    .registers 3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/i2;->m:[B

    array-length v1, v0

    invoke-static {v1}, Lcom/android/internal/util/danda/classes/n5;->a(I)I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    array-length v0, v0

    add-int/2addr v1, v0

    return v1
.end method

.method public final k()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 2

    invoke-virtual {p0}, Lcom/android/internal/util/danda/classes/i2;->a()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

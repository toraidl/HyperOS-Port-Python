.class public abstract Lcom/android/internal/util/danda/classes/e4;
.super Ljava/io/InputStream;
.source "SourceFile"


# instance fields
.field public final a:Ljava/io/InputStream;

.field public final b:I


# direct methods
.method public constructor <init>(ILjava/io/InputStream;)V
    .registers 3

    invoke-direct {p0}, Ljava/io/InputStream;-><init>()V

    iput-object p2, p0, Lcom/android/internal/util/danda/classes/e4;->a:Ljava/io/InputStream;

    iput p1, p0, Lcom/android/internal/util/danda/classes/e4;->b:I

    return-void
.end method


# virtual methods
.method public a()I
    .registers 2

    iget v0, p0, Lcom/android/internal/util/danda/classes/e4;->b:I

    return v0
.end method

.method public final b()V
    .registers 3

    iget-object v0, p0, Lcom/android/internal/util/danda/classes/e4;->a:Ljava/io/InputStream;

    instance-of v1, v0, Lcom/android/internal/util/danda/classes/t3;

    if-eqz v1, :cond_e

    check-cast v0, Lcom/android/internal/util/danda/classes/t3;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lcom/android/internal/util/danda/classes/t3;->f:Z

    invoke-virtual {v0}, Lcom/android/internal/util/danda/classes/t3;->c()Z

    :cond_e
    return-void
.end method
